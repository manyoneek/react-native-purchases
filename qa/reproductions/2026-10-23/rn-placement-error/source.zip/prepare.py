from pathlib import Path
import os,json,subprocess,sys,shutil
r=Path(__file__).resolve().parent;variant=sys.argv[1];assert variant in ('before','fixed')
api_key=os.environ.get('RC_TEST_STORE_API_KEY')
if not api_key:raise SystemExit('Set RC_TEST_STORE_API_KEY to the dedicated Test Store public SDK key.')
(r/'app/qa-config.json').write_text(json.dumps(dict(apiKey=api_key,projectId='proj602cc762')))
(r/'sdk/ios/RNPurchases.m').write_bytes((r/(variant+'-RNPurchases.m')).read_bytes())
def run(args,cwd):subprocess.run(args,cwd=r/cwd,check=True)
run(['corepack','yarn','install','--immutable'],'sdk')
run(['corepack','yarn','build'],'sdk')
run(['npm','ci','--ignore-scripts','--no-audit','--no-fund'],'app')
# Keep the archived package integrity and lockfile; replace the implementation with this source build.
shutil.copytree(r/'sdk/dist',r/'app/node_modules/react-native-purchases/dist',dirs_exist_ok=True)
(r/'app/node_modules/react-native-purchases/ios/RNPurchases.m').write_bytes((r/(variant+'-RNPurchases.m')).read_bytes())
run(['pod','install'],'app/ios')
print('Build app/ios/RCBugReporter.xcworkspace, scheme QAReproduction, on an installed iOS simulator.')
