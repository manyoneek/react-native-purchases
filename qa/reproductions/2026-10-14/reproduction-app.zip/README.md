# RevenueCat SDK Bug Reporter — minimal apps

Dedicated project: `SDK Bug Reporter` (`proj602cc762`). Only synthetic Test Store users are created. The checked-in SDK key is a public Test Store client key, not an administrative key. Never ship these demos to an app store.

## React Native iOS

```sh
cd react-native-app
npm ci
cd ios && pod install && cd ..
FORCE_BUNDLING=1 xcodebuild -workspace ios/RCBugReporter.xcworkspace \
  -scheme QAReproduction -configuration Debug \
  -destination 'platform=iOS Simulator,name=iPhone Duo' \
  -derivedDataPath build CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES build-for-testing
xcodebuild -workspace ios/RCBugReporter.xcworkspace -scheme QAReproduction \
  -configuration Debug -destination 'platform=iOS Simulator,name=iPhone Duo' \
  -derivedDataPath build CODE_SIGNING_ALLOWED=NO test-without-building
```
Requires Xcode 27 and an iOS 27+ simulator. Choose an available simulator if its name differs. Test Store requires **Debug**, not Release. Native code and JS are bundled in the simulator app; Metro is not required after building.

Manual flow: install and launch the built `RCBugReporter.app`. Choose one case per launch. Tap Subscribe on the native paywall, then **Test failed purchase** for the error-code case or **Test valid purchase** for the transaction case. The latter supplies custom purchase logic, executes a real SDK Test Store purchase, returns success, and observes the native callback. The app catches the consumer's TypeError so the evidence remains visible.

Locally packed `react-native-purchases` and `react-native-purchases-ui` 10.13.0 come from commit `dffdb082054c9d9d71287e72a6565c422485a3d8`. Podfile.lock pins shared 19.11.0 and iOS 5.95.0. SDK callbacks are not injected.

## Flutter web

```sh
cd flutter-app
flutter pub get
flutter build web --no-web-resources-cdn
python3 -m http.server 8877 --bind 127.0.0.1 --directory build/web
```
Open http://127.0.0.1:8877 in Chrome.

- **Proxy:** Before configuration, click **Run proxy case**. Calls the actual public `Purchases.setProxyURL`.
- **Attribute promises:** Reload. Click **Initialize Test Store** while online. In Chrome DevTools Network, select **Offline**. Click **Run attribute setters**. Compare public Future results with the browser's unhandled promise rejections. Restore Online afterward.

`vendor/purchases_flutter` contains the reviewed production source at commit `2b4b1976cfd08607c0384f5d619672e99e762c32` (10.15.2), including its real vendored JavaScript. No SDK operation or method channel is mocked. The browser rejection observer does not intercept or fabricate errors.

## Suggested solutions

1. Flutter proxy: accept `setProxyURLString` in the web dispatcher and invoke the synchronous JavaScript `setProxyUrl` without coercing its void return to a Promise.
2. Flutter attributes: await and convert the JavaScript Promise for all four setters, mapping rejection through the existing error conversion.
3. React Native error callbacks: normalize native numeric error codes to the SDK's public string enum before calling purchase/restore error callbacks. Cover full and footer paywalls.
4. React Native custom-purchase transaction: make `storeTransaction` optional in both callback declarations and guard consumers. Do not fabricate a transaction for native paths that legitimately have none.

See the English per-finding reports and actual captured evidence for the precise results and limitations. Apps, screenshots and videos do not establish Android, Wasm, physical-device or real-store behavior.

## Before / after validation

The source apps in this archive are restored to the **original affected SDK behavior**. Two menu choices in the iOS app and two actions in the web app isolate the four findings.

- Native baseline: `npx tsc --noEmit` succeeds despite the unsafe transaction access. The two XCTest characterization tests assert the observed bugs and pass.
- Corrected declaration: the same unsafe consumer fails with TS18048. Adding the included guard makes type checking pass.
- Flutter regression: `cd flutter-app && flutter test --platform chrome test/local_boundary/web_boundary_test.dart` gives **4 passed / 10 failed** on original code; **14 passed** with the proposed patch. These focused regression tests use controlled downstream operations; the demo app and its videos use real SDK calls/networking.

### Try the proposed fixes locally

From this archive's root, after `npm ci` in `react-native-app`:

```sh
cd react-native-app/node_modules
patch -p1 < ../../fixes/combined-proposed-fixes.patch
cd ../..
cp fixes/index.fixed.d.ts react-native-app/node_modules/react-native-purchases-ui/lib/typescript/src/index.d.ts
cp fixes/App.fixed.tsx react-native-app/App.tsx
cp fixes/ReproductionTests.fixed.swift react-native-app/ios/RCBugReporterUITests/ReproductionTests.swift
```
Rebuild with the native commands above, then run the two updated assertions. The fixed declaration file was generated from the patched SDK source; it is included to avoid requiring SDK build tooling just to try the app.

For Flutter, from the archive root:

```sh
cd flutter-app/vendor/purchases_flutter
patch -p1 < ../../../fixes/flutter-web.patch
cd ../..
flutter test --platform chrome test/local_boundary/web_boundary_test.dart
flutter build web --no-web-resources-cdn
```

### Capture and tool limitations

`record-native.py` and `record-web*.cjs` are the actual capture scripts for this Mac. Native script uses `simulator-id.txt`, the `../native-derived` build directory and display 1 of the multi-display iPhone Duo; adapt those to your simulator. Browser script requires Playwright Core, ffmpeg and an existing Chrome CDP connection on port18800, with the local original/fixed apps on ports8877/8878.

Native videos are actual simulator recordings cropped to the app display, resized, with the **last recorded result frame held for six seconds** for readability. No callback/value is generated for the video. Original native screenshots were captured during XCTest assertions, not after teardown; fixed native PNGs are extracted from the actual recorded result frames. Flutter videos are real Chrome rendered-frame recordings.

Xcode27/iOS27.1 printed debugger/version warnings. Some XCTest invocations printed both tests passed and then stalled during runner shutdown; those processes were terminated and are not represented as successful command exits. Build/typecheck logs and test assertion logs are preserved separately. No physical iPhone, Android runtime, Wasm, App Store or Google Play purchase was tested. Delivery is runnable source, not an IPA/TestFlight distribution.

Final fixed iOS run: **2 tests passed, xcodebuild exit 0**. The original recorded run printed both assertions passed but stalled during runner shutdown and was terminated. A prior original clean run also completed successfully. Source restoration does not alter the captured fixed build evidence.
