import { type StyleProp, type ViewStyle } from "react-native";
import { type CustomerInfo, type PaywallInteractionEvent, PAYWALL_RESULT, type PurchasesError, type PurchasesOffering, type PurchasesPackage, type PurchasesStoreTransaction, REFUND_REQUEST_STATUS } from "@revenuecat/purchases-typescript-internal";
import React, { type ReactNode } from "react";
import { type CustomVariables } from "./customVariables";
export { PAYWALL_RESULT, type PaywallInteractionEvent } from "@revenuecat/purchases-typescript-internal";
export { CustomVariableValue, type CustomVariables } from "./customVariables";
export { convertCustomVariablesToNativeMap, convertCustomVariablesToStringMap, transformOptionsForNative } from "./customVariables";
/**
 * The result of a purchase or restore operation performed by custom app-based logic.
 * Used when `purchasesAreCompletedBy` is set to `MY_APP`.
 * @readonly
 * @enum {string}
 */
export declare enum PURCHASE_LOGIC_RESULT {
    /** The purchase or restore was successful. */
    SUCCESS = "SUCCESS",
    /** The purchase was cancelled by the user. */
    CANCELLATION = "CANCELLATION",
    /** An error occurred during the purchase or restore. */
    ERROR = "ERROR"
}
/**
 * The result of a purchase or restore operation performed by custom purchase logic.
 * Uses a discriminated union to allow structured error information.
 */
export type PurchaseLogicResult = {
    result: PURCHASE_LOGIC_RESULT.SUCCESS;
} | {
    result: PURCHASE_LOGIC_RESULT.CANCELLATION;
} | {
    result: PURCHASE_LOGIC_RESULT.ERROR;
    error?: PurchasesError;
};
/**
 * Interface for handling purchases and restores within paywalls when
 * `purchasesAreCompletedBy` is set to `MY_APP`.
 *
 * When provided, the paywall will call these functions instead of using
 * RevenueCat's default purchase/restore behavior.
 */
export interface PurchaseLogic {
    /**
     * Called when the paywall wants to perform a purchase.
     * Implement this to execute your custom purchase logic.
     *
     * @param args.packageToPurchase - The package the user wants to purchase.
     * @returns A promise resolving to a PurchaseLogicResult indicating the outcome.
     */
    performPurchase: (args: {
        packageToPurchase: PurchasesPackage;
    }) => Promise<PurchaseLogicResult>;
    /**
     * Called when the paywall wants to perform a restore.
     * Implement this to execute your custom restore logic.
     *
     * @returns A promise resolving to a PurchaseLogicResult indicating the outcome.
     */
    performRestore: () => Promise<PurchaseLogicResult>;
}
export interface PresentPaywallParams {
    /**
     * Whether to display the close button or not.
     * Only available for original template paywalls. Ignored for V2 Paywalls and web.
     */
    displayCloseButton?: boolean;
    /**
     * The offering to load the paywall with. This will be the "current" offering by default.
     */
    offering?: PurchasesOffering;
    /**
     * The fontFamily name to use in the Paywall. In order to add a font family, add it in the react native app and make
     * sure to run `npx react-native-asset` so it's added to the native components.
     * Supported font types are `.ttf` and `.otf`.
     * Make sure the file names follow the convention:
     * - Regular: MyFont.ttf/MyFont.otf
     * - Bold: MyFont_bold.ttf/MyFont_bold.otf
     * - Italic: MyFont_italic.ttf/MyFont_italic.otf
     * - Bold and Italic: MyFont_bold_italic.ttf/MyFont_bold_italic.otf
     * Only available for original template paywalls. Ignored for V2 Paywalls and web.
     */
    fontFamily?: string | null;
    /**
     * Custom variables to pass to the paywall for text substitution.
     * Use `{{ custom.variable_name }}` syntax in your paywall text to reference these values.
     * Keys must start with a letter and can only contain letters, numbers, and underscores.
     * Only available for V2 Paywalls.
     *
     * @example
     * ```typescript
     * customVariables: {
     *   'player_name': CustomVariableValue.string('John'),
     *   'level': CustomVariableValue.number(42),
     *   'is_premium': CustomVariableValue.boolean(true),
     * }
     * ```
     */
    customVariables?: CustomVariables;
    /**
     * Callbacks for paywall events while the paywall is presented. The same events as
     * {@link RevenueCatUI.Paywall} receives, except `onDismiss`: the returned promise resolves on dismissal.
     */
    callbacks?: PaywallCallbacks;
}
export type PresentPaywallIfNeededParams = PresentPaywallParams & {
    /**
     * The paywall will only be presented if this entitlement is not active.
     */
    requiredEntitlementIdentifier: string;
};
export interface PaywallViewOptions {
    /**
     * The offering to load the paywall with. This will be the "current" offering by default.
     */
    offering?: PurchasesOffering | null;
    /**
     * The fontFamily name to use in the Paywall. In order to add a font family, add it in the react native app and make
     * sure to run `npx react-native-asset` so it's added to the native components.
     * Supported font types are `.ttf` and `.otf`.
     * Make sure the file names follow the convention:
     * - Regular: MyFont.ttf/MyFont.otf
     * - Bold: MyFont_bold.ttf/MyFont_bold.otf
     * - Italic: MyFont_italic.ttf/MyFont_italic.otf
     * - Bold and Italic: MyFont_bold_italic.ttf/MyFont_bold_italic.otf
     * Only available for original template paywalls. Ignored for V2 Paywalls.
     */
    fontFamily?: string | null;
    /**
     * Custom variables to pass to the paywall for text substitution.
     * Use `{{ custom.variable_name }}` syntax in your paywall text to reference these values.
     * Keys must start with a letter and can only contain letters, numbers, and underscores.
     * Only available for V2 Paywalls.
     *
     * @example
     * ```typescript
     * customVariables: {
     *   'player_name': CustomVariableValue.string('John'),
     *   'level': CustomVariableValue.number(42),
     *   'is_premium': CustomVariableValue.boolean(true),
     * }
     * ```
     */
    customVariables?: CustomVariables;
}
export interface FullScreenPaywallViewOptions extends PaywallViewOptions {
    /**
     * Whether to display the close button or not.
     * Only available for original template paywalls. Ignored for V2 Paywalls.
     */
    displayCloseButton?: boolean | false;
}
export interface FooterPaywallViewOptions extends PaywallViewOptions {
}
/**
 * Callbacks for paywall events, shared by {@link RevenueCatUI.Paywall} and
 * {@link RevenueCatUI.presentPaywall}.
 */
export interface PaywallCallbacks {
    onPurchaseStarted?: ({ packageBeingPurchased }: {
        packageBeingPurchased: PurchasesPackage;
    }) => void;
    onPurchaseCompleted?: ({ customerInfo, storeTransaction }: {
        customerInfo: CustomerInfo;
        storeTransaction?: PurchasesStoreTransaction;
    }) => void;
    onPurchaseError?: ({ error }: {
        error: PurchasesError;
    }) => void;
    onPurchaseCancelled?: () => void;
    onRestoreStarted?: () => void;
    onRestoreCompleted?: ({ customerInfo }: {
        customerInfo: CustomerInfo;
    }) => void;
    onRestoreError?: ({ error }: {
        error: PurchasesError;
    }) => void;
    /**
     * Called before a purchase starts, so the app can run its own checks first. The purchase does not
     * proceed until `resume` is called: `resume(true)` continues it and `resume(false)` stops it.
     */
    onPurchasePackageInitiated?: ({ packageBeingPurchased, resume }: {
        packageBeingPurchased: PurchasesPackage;
        resume: (shouldResume: boolean) => void;
    }) => void;
    onWebCheckoutOpened?: () => void;
    onUrlOpened?: (url: string) => void;
    /** See https://rev.cat/paywall-interaction-events for the keys each component type sends. */
    onInteraction?: (event: PaywallInteractionEvent) => void;
}
type FullScreenPaywallViewProps = PaywallCallbacks & {
    style?: StyleProp<ViewStyle>;
    children?: ReactNode;
    options?: FullScreenPaywallViewOptions;
    purchaseLogic?: PurchaseLogic;
    onDismiss?: () => void;
};
type FooterPaywallViewProps = {
    style?: StyleProp<ViewStyle>;
    children?: ReactNode;
    options?: FooterPaywallViewOptions;
    onPurchaseStarted?: ({ packageBeingPurchased }: {
        packageBeingPurchased: PurchasesPackage;
    }) => void;
    onPurchaseCompleted?: ({ customerInfo, storeTransaction }: {
        customerInfo: CustomerInfo;
        storeTransaction?: PurchasesStoreTransaction;
    }) => void;
    onPurchaseError?: ({ error }: {
        error: PurchasesError;
    }) => void;
    onPurchaseCancelled?: () => void;
    onRestoreStarted?: () => void;
    onRestoreCompleted?: ({ customerInfo }: {
        customerInfo: CustomerInfo;
    }) => void;
    onRestoreError?: ({ error }: {
        error: PurchasesError;
    }) => void;
    onDismiss?: () => void;
};
export interface CustomerCenterViewProps extends CustomerCenterCallbacks {
    style?: StyleProp<ViewStyle>;
    onDismiss?: () => void;
    /**
     * Whether to show the close button in the customer center.
     *
     * When `true`, displays a close button that can be used to dismiss the customer center.
     * When `false`, hides the internal close button - typically used for push navigation where
     * the navigation bar provides the back button.
     *
     * @default true
     */
    shouldShowCloseButton?: boolean;
}
export type CustomerCenterManagementOption = 'cancel' | 'custom_url' | 'missing_purchase' | 'refund_request' | 'change_plans' | 'unknown' | string;
export type CustomerCenterManagementOptionEvent = {
    option: 'custom_url';
    url: string;
} | {
    option: Exclude<CustomerCenterManagementOption, 'custom_url'>;
    url: null;
};
export interface CustomerCenterCallbacks {
    /**
     * Called when a feedback survey is completed with the selected option ID.
     */
    onFeedbackSurveyCompleted?: ({ feedbackSurveyOptionId }: {
        feedbackSurveyOptionId: string;
    }) => void;
    /**
     * Called when the manage subscriptions section is being shown.
     */
    onShowingManageSubscriptions?: () => void;
    /**
     * Called when a restore operation is completed successfully.
     */
    onRestoreCompleted?: ({ customerInfo }: {
        customerInfo: CustomerInfo;
    }) => void;
    /**
     * Called when a restore operation fails.
     */
    onRestoreFailed?: ({ error }: {
        error: PurchasesError;
    }) => void;
    /**
     * Called when a restore operation starts.
     */
    onRestoreStarted?: () => void;
    /**
     * Called when a refund request starts with the product identifier.
     *
     * **iOS only** - This callback will never be called on Android as refund requests are not supported on that platform.
     */
    onRefundRequestStarted?: ({ productIdentifier }: {
        productIdentifier: string;
    }) => void;
    /**
     * Called when a refund request completes with status information.
     *
     * **iOS only** - This callback will never be called on Android as refund requests are not supported on that platform.
     */
    onRefundRequestCompleted?: ({ productIdentifier, refundRequestStatus }: {
        productIdentifier: string;
        refundRequestStatus: REFUND_REQUEST_STATUS;
    }) => void;
    /**
     * Called when a customer center management option is selected.
     * For 'custom_url' options, the url parameter will contain the URL.
     * For all other options, the url parameter will be null.
     */
    onManagementOptionSelected?: (event: CustomerCenterManagementOptionEvent) => void;
    /**
     * Called when a custom action is selected in the customer center.
     */
    onCustomActionSelected?: ({ actionId, purchaseIdentifier }: {
        actionId: string;
        purchaseIdentifier: string | null;
    }) => void;
    /**
     * Called when a promotional offer purchase completes successfully in the customer center.
     */
    onPromotionalOfferSucceeded?: ({ customerInfo, transaction, offerId }: {
        customerInfo: CustomerInfo;
        transaction: PurchasesStoreTransaction;
        offerId: string;
    }) => void;
}
export interface PresentCustomerCenterParams {
    /**
     * Optional callbacks for customer center events.
     */
    callbacks?: CustomerCenterCallbacks;
}
export default class RevenueCatUI {
    private static Defaults;
    /**
     * The result of presenting a paywall. This will be the last situation the user experienced before the paywall closed.
     * @readonly
     * @enum {string}
     */
    static PAYWALL_RESULT: typeof PAYWALL_RESULT;
    /**
     * Presents a paywall to the user with optional customization.
     *
     * This method allows for presenting a specific offering's paywall to the user. The caller
     * can decide whether to display a close button on the paywall through the `displayCloseButton`
     * parameter. By default, the close button is displayed.
     *
     * @param {PresentPaywallParams} params - The options for presenting the paywall.
     * @returns {Promise<PAYWALL_RESULT>} A promise that resolves with the result of the paywall presentation.
     */
    static presentPaywall({ offering, displayCloseButton, fontFamily, customVariables, callbacks, }?: PresentPaywallParams): Promise<PAYWALL_RESULT>;
    /**
     * Presents a paywall to the user if a specific entitlement is not already owned.
     *
     * This method evaluates whether the user already owns the specified entitlement.
     * If the entitlement is not owned, it presents a paywall for the specified offering (if provided), or the
     * default offering (if no offering is provided), to the user. The paywall will be presented
     * allowing the user the opportunity to purchase the offering. The caller
     * can decide whether to display a close button on the paywall through the `displayCloseButton`
     * parameter. By default, the close button is displayed.
     *
     * @param {PresentPaywallIfNeededParams} params - The parameters for presenting the paywall.
     * @returns {Promise<PAYWALL_RESULT>} A promise that resolves with the result of the paywall presentation.
     */
    static presentPaywallIfNeeded({ requiredEntitlementIdentifier, offering, displayCloseButton, fontFamily, customVariables, callbacks, }: PresentPaywallIfNeededParams): Promise<PAYWALL_RESULT>;
    private static presentWithCallbacks;
    static Paywall: React.FC<FullScreenPaywallViewProps>;
    static OriginalTemplatePaywallFooterContainerView: React.FC<FooterPaywallViewProps>;
    /**
     * A React component for embedding the Customer Center directly in your UI.
     *
     * This component renders the RevenueCat Customer Center as a native view that can be
     * embedded within your existing React Native screens. Unlike `presentCustomerCenter()`,
     * which presents the Customer Center modally, this component gives you full control
     * over layout and presentation.
     *
     * The Customer Center allows users to manage their subscriptions, view purchase history,
     * request refunds (iOS only), and access support options - all configured through the
     * RevenueCat dashboard.
     *
     * @param style - Optional style prop to customize the appearance and layout
     * @param onDismiss - Callback fired when the user dismisses the Customer Center (e.g., taps a close button)
     *
     * @example
     * ```tsx
     * import RevenueCatUI from 'react-native-purchases-ui';
     *
     * function MyScreen() {
     *   return (
     *     <View style={{ flex: 1 }}>
     *       <RevenueCatUI.CustomerCenterView
     *         style={{ flex: 1 }}
     *         onDismiss={() => navigation.goBack()}
     *       />
     *     </View>
     *   );
     * }
     * ```
     */
    static CustomerCenterView: React.FC<CustomerCenterViewProps>;
    /**
     * Presents the customer center to the user.
     *
     * @param {PresentCustomerCenterParams} params - Optional parameters for presenting the customer center.
     * @returns {Promise<void>} A promise that resolves when the customer center is presented.
     */
    static presentCustomerCenter(params?: PresentCustomerCenterParams): Promise<void>;
    /**
     * @deprecated, Use {@link OriginalTemplatePaywallFooterContainerView} instead
     */
    static PaywallFooterContainerView: React.FC<FooterPaywallViewProps>;
    private static logWarningIfPreviewAPIMode;
}
//# sourceMappingURL=index.d.ts.map