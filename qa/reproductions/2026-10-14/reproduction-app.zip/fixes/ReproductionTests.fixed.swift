import XCTest
final class ReproductionTests: XCTestCase {
    let app = XCUIApplication()
    override func setUpWithError() throws { continueAfterFailure = false }
    func attach(_ name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
        print("QA_TREE \(name): \(app.debugDescription)")
    }
    func testErrorCallback() throws {
        app.launch()
        XCTAssertTrue(app.buttons["1. Error callback types"].waitForExistence(timeout: 30))
        app.buttons["1. Error callback types"].tap()
        // First run inspection records the actual paywall and Test Store controls.
        let buy = app.buttons.matching(NSPredicate(format: "label CONTAINS[c] 'Subscribe' OR label CONTAINS[c] 'Continue'")).firstMatch
        XCTAssertTrue(buy.waitForExistence(timeout: 45), app.debugDescription)
        attach("error-paywall")
        buy.tap()
        attach("error-test-store-dialog")
        let fail = app.buttons["Test failed purchase"]
        XCTAssertTrue(fail.waitForExistence(timeout: 10), app.debugDescription)
        fail.tap()
        XCTAssertTrue(app.staticTexts["Observed result"].waitForExistence(timeout: 20), app.debugDescription)
        let output = app.staticTexts.matching(NSPredicate(format: "label CONTAINS 'onPurchaseError code=' AND label CONTAINS 'Strict equality:'")).firstMatch
        XCTAssertTrue(output.exists)
        XCTAssertTrue(output.label.contains("typeof=string"))
        XCTAssertTrue(output.label.contains("Strict equality: true"))
        attach("error-callback-result")
        Thread.sleep(forTimeInterval: 5) // Hold the real result screen for video capture.
    }
    func testMissingTransaction() throws {
        app.launch()
        XCTAssertTrue(app.buttons["2. Missing transaction"].waitForExistence(timeout: 30))
        app.buttons["2. Missing transaction"].tap()
        let buy = app.buttons.matching(NSPredicate(format: "label CONTAINS[c] 'Subscribe' OR label CONTAINS[c] 'Continue'")).firstMatch
        XCTAssertTrue(buy.waitForExistence(timeout: 45), app.debugDescription)
        attach("transaction-paywall")
        buy.tap()
        let success = app.buttons["Test valid purchase"]
        XCTAssertTrue(success.waitForExistence(timeout: 10), app.debugDescription)
        attach("transaction-test-store-dialog")
        success.tap()
        XCTAssertTrue(app.staticTexts["Observed result"].waitForExistence(timeout: 30), app.debugDescription)
        let output = app.staticTexts.matching(NSPredicate(format: "label CONTAINS 'storeTransaction = undefined' AND label CONTAINS 'No transaction supplied; handled safely.'")).firstMatch
        XCTAssertTrue(output.exists)
        XCTAssertTrue(output.label.contains("entitlement active=true"))
        XCTAssertFalse(output.label.contains("TypeError"))
        attach("missing-transaction-result")
        Thread.sleep(forTimeInterval: 5) // Hold the real result screen for video capture.
    }
}
