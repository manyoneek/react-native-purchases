import React, {useState} from 'react';
import {SafeAreaView, ScrollView, Text, View, Button, StyleSheet, LogBox} from 'react-native';
import Purchases, {PURCHASES_ERROR_CODE, PURCHASES_ARE_COMPLETED_BY_TYPE, STOREKIT_VERSION, PurchasesOffering} from 'react-native-purchases';
import RevenueCatUI, {PURCHASE_LOGIC_RESULT} from 'react-native-purchases-ui';
import config from './qa-config.json';

LogBox.ignoreAllLogs(true); // Keep QA results visible; native/JS logs remain captured.
type Mode = 'error' | 'transaction';
export default function App() {
  const [mode,setMode] = useState<Mode>();
  const [offering,setOffering] = useState<PurchasesOffering>();
  const [events,setEvents] = useState<string[]>([]);
  const [done,setDone] = useState(false);
  const log = (s:string) => { console.log('[QA]',s); setEvents(old=>[...old,s]); };
  async function start(next:Mode) {
    setMode(next);
    try {
      const user = `bug-reporter-rn-${next}-${Date.now()}`;
      Purchases.configure({apiKey:config.apiKey,appUserID:user,purchasesAreCompletedBy: next==='transaction' ? {type:PURCHASES_ARE_COMPLETED_BY_TYPE.MY_APP,storeKitVersion:STOREKIT_VERSION.STOREKIT_2} : PURCHASES_ARE_COMPLETED_BY_TYPE.REVENUECAT});
      log(`Real Test Store user: ${user}`);
      const result = await Purchases.getOfferings();
      if (!result.current) throw new Error('No current offering');
      setOffering(result.current);
      log(`Offering ready: ${result.current.identifier}`);
    } catch(e) { log(`SETUP ERROR: ${String(e)}`); }
  }
  return <SafeAreaView style={s.root}>
    {(!offering || done) && <View style={s.header}>
      <Text style={s.title}>RevenueCat Bug Reporter</Text>
      <Text style={s.subtitle}>React Native 10.13.0 · dffdb082054c</Text>
      {!mode && <>
        <Text style={s.description}>Choose one case per launch. Uses real native paywalls and Test Store purchases.</Text>
        <Button title="1. Error callback types" onPress={()=>start('error')}/>
        <Button title="2. Missing transaction" onPress={()=>start('transaction')}/>
      </>}
      {mode && <Text style={s.description}>{mode==='error' ? 'Tap Subscribe, then Test failed purchase in the Test Store dialog.' : 'Tap Subscribe, then Test valid purchase. Custom purchase logic completes the real test purchase.'}</Text>}
    </View>}
    {offering && !done && <View style={{flex:1}}><RevenueCatUI.Paywall
      options={{offering,displayCloseButton:false}}
      purchaseLogic={mode==='transaction' ? {
        performPurchase: async ({packageToPurchase}) => {
          log('Custom purchase logic: calling real Purchases.purchasePackage');
          const result = await Purchases.purchasePackage(packageToPurchase);
          log(`Real purchase completed. Entitlements: ${Object.keys(result.customerInfo.entitlements.active).join(',')}`);
          return {result:PURCHASE_LOGIC_RESULT.SUCCESS};
        },
        performRestore: async () => { await Purchases.restorePurchases(); return {result:PURCHASE_LOGIC_RESULT.SUCCESS}; },
      } : undefined}
      onPurchaseError={({error})=>{
        log(`onPurchaseError code=${JSON.stringify(error.code)}; typeof=${typeof error.code}`);
        const matches = Object.values(PURCHASES_ERROR_CODE).filter(c=>String(c)===String(error.code));
        log(`Matching public enum: ${JSON.stringify(matches[0])}; typeof=${typeof matches[0]}`);
        log(`Strict equality: ${error.code===matches[0]} (expected true)`);
        log(`Message: ${error.message}`);
        setDone(true);
      }}
      onRestoreError={({error})=>{ log(`onRestoreError code=${JSON.stringify(error.code)}; typeof=${typeof error.code}`); setDone(true); }}
      onPurchaseCompleted={({customerInfo,storeTransaction})=>{
        log(`onPurchaseCompleted: entitlement active=${!!customerInfo.entitlements.active.qa_premium}`);
        log(`storeTransaction = ${String(storeTransaction)}`);
        try { log(`Transaction ID: ${storeTransaction.transactionIdentifier}`); }
        catch(e) { log(`Type-accepted consumer FAILED: ${String(e)}`); }
        setDone(true);
      }}
    /></View>}
    {(!offering || done) && <ScrollView style={[s.results,done && {flex:1}]} accessibilityLabel="QA results">
      <Text style={s.resultTitle}>{done ? 'Observed result' : 'Event log'}</Text>
      <Text selectable style={s.log}>{events.join('\n\n') || 'Ready'}</Text>
      {done && <Text style={s.solution}>{mode==='error' ? 'Suggested fix: normalize the native code to String before invoking JS error callbacks.' : 'Suggested fix: declare storeTransaction optional and require a null check before reading it.'}</Text>}
      <Text style={s.footer}>Dedicated Test Store · synthetic user · no real charge{done ? '\nForce-quit and reopen to run another case.' : ''}</Text>
    </ScrollView>}
  </SafeAreaView>;
}
const s = StyleSheet.create({root:{flex:1,backgroundColor:'#101523'},header:{padding:18},title:{fontSize:23,fontWeight:'700',color:'#fff'},subtitle:{color:'#a9b8d5',fontSize:13,marginTop:5},description:{color:'#d5def0',fontSize:14,marginVertical:12},results:{padding:18,backgroundColor:'#1d2638'},resultTitle:{fontSize:20,fontWeight:'700',color:'#fff',marginBottom:12},log:{fontFamily:'Menlo',fontSize:13,color:'#fff',lineHeight:19},solution:{fontSize:16,color:'#ffcc75',marginTop:22},footer:{fontSize:12,color:'#a9b8d5',marginTop:16,marginBottom:28}});
