"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PurchasesAdTracker = exports.AdCaptureMethod = exports.AdRevenuePrecision = exports.AdFormat = exports.AdMediatorName = exports.WebPurchaseRedemptionResultType = exports.STOREKIT_VERSION = exports.LOG_LEVEL = exports.REFUND_REQUEST_STATUS = exports.BILLING_FEATURE = exports.PURCHASES_ARE_COMPLETED_BY_TYPE = exports.PURCHASE_TYPE = void 0;
var react_native_1 = require("react-native");
var purchases_typescript_internal_1 = require("@revenuecat/purchases-typescript-internal");
var normalizingRejections_1 = require("./normalizingRejections");
var environment_1 = require("./utils/environment");
var nativeModule_1 = require("./browser/nativeModule");
// This export is kept to keep backwards compatibility to any possible users using this file directly
var purchases_typescript_internal_2 = require("@revenuecat/purchases-typescript-internal");
Object.defineProperty(exports, "PURCHASE_TYPE", { enumerable: true, get: function () { return purchases_typescript_internal_2.PURCHASE_TYPE; } });
Object.defineProperty(exports, "PURCHASES_ARE_COMPLETED_BY_TYPE", { enumerable: true, get: function () { return purchases_typescript_internal_2.PURCHASES_ARE_COMPLETED_BY_TYPE; } });
Object.defineProperty(exports, "BILLING_FEATURE", { enumerable: true, get: function () { return purchases_typescript_internal_2.BILLING_FEATURE; } });
Object.defineProperty(exports, "REFUND_REQUEST_STATUS", { enumerable: true, get: function () { return purchases_typescript_internal_2.REFUND_REQUEST_STATUS; } });
Object.defineProperty(exports, "LOG_LEVEL", { enumerable: true, get: function () { return purchases_typescript_internal_2.LOG_LEVEL; } });
Object.defineProperty(exports, "STOREKIT_VERSION", { enumerable: true, get: function () { return purchases_typescript_internal_2.STOREKIT_VERSION; } });
Object.defineProperty(exports, "WebPurchaseRedemptionResultType", { enumerable: true, get: function () { return purchases_typescript_internal_2.WebPurchaseRedemptionResultType; } });
var react_native_2 = require("react-native");
var NATIVE_MODULE_ERROR = "[RevenueCat] Native module (RNPurchases) not found. This can happen if:\n\n" +
    "- You are running in an environment where native modules are unavailable\n" +
    "- The native module failed to initialize\n" +
    "- The package is not properly linked\n\n" +
    "To fix this:\n" +
    "- If using Expo Go, the SDK works in preview mode but native modules are not available. " +
    "For full functionality, create a development build: https://docs.expo.dev/develop/development-builds/create-a-build/\n" +
    "- If using bare React Native, run 'pod install' and rebuild the app\n" +
    "- Check that you have rebuilt the app after installing the package\n";
// Get the native module or use the browser implementation
var usingBrowserMode = (0, environment_1.shouldUseBrowserMode)();
var nativeModule = usingBrowserMode ? nativeModule_1.browserNativeModuleRNPurchases : react_native_1.NativeModules.RNPurchases;
var RNPurchases = nativeModule ? (0, normalizingRejections_1.normalizingRejections)(nativeModule) : nativeModule;
// Only create event emitter if native module is available to avoid crash on import
//
// React Native 0.79+ requires native modules to implement addListener() and removeListeners()
// methods for NativeEventEmitter to work. Both iOS and Android native modules now have these.
// See: https://github.com/RevenueCat/react-native-purchases/issues/1298
// See: https://reactnative.dev/blog/2025/04/08/react-native-0.79 (Breaking Changes section)
var eventEmitter = !usingBrowserMode && nativeModule ? new react_native_1.NativeEventEmitter(nativeModule) : null;
// Helper function to check if native module is available - provides better error message than "Cannot read property X of null"
function throwIfNativeModuleNotAvailable() {
    if (!RNPurchases) {
        throw new Error(NATIVE_MODULE_ERROR);
    }
}
var customerInfoUpdateListeners = [];
var shouldPurchasePromoProductListeners = [];
var customLogHandler;
var trackedEventListeners = [];
/**
 * Predefined mediator name constants. Use these or pass any string for unlisted networks.
 */
exports.AdMediatorName = {
    adMob: "AdMob",
    appLovin: "AppLovin",
};
/**
 * Predefined ad format constants. Use these or pass any string for unlisted formats.
 */
exports.AdFormat = {
    other: "other",
    banner: "banner",
    interstitial: "interstitial",
    rewarded: "rewarded",
    rewardedInterstitial: "rewarded_interstitial",
    nativeAd: "native",
    appOpen: "app_open",
};
/**
 * Predefined precision constants for ad revenue. Use these or pass any string for unlisted values.
 */
exports.AdRevenuePrecision = {
    exact: "exact",
    publisherDefined: "publisher_defined",
    estimated: "estimated",
    unknown: "unknown",
};
/**
 * Identifies the integration that emitted an ad event. Reserved for the
 * official RevenueCat ad-network adapters (for example
 * `react-native-purchases-admob`); leave it unset when tracking manually.
 */
exports.AdCaptureMethod = {
    reactNativeAdMobAdapter: "react_native_admob_adapter",
};
var debugEventListeners = [];
eventEmitter === null || eventEmitter === void 0 ? void 0 : eventEmitter.addListener("Purchases-CustomerInfoUpdated", function (event) {
    var customerInfo = event;
    customerInfoUpdateListeners.forEach(function (listener) { return listener(customerInfo); });
});
eventEmitter === null || eventEmitter === void 0 ? void 0 : eventEmitter.addListener("Purchases-ShouldPurchasePromoProduct", function (event) {
    var callbackID = event.callbackID;
    shouldPurchasePromoProductListeners.forEach(function (listener) {
        return listener(function () { return RNPurchases.makeDeferredPurchase(callbackID); });
    });
});
eventEmitter === null || eventEmitter === void 0 ? void 0 : eventEmitter.addListener("Purchases-LogHandlerEvent", function (event) {
    var _a = event, logLevel = _a.logLevel, message = _a.message;
    if (customLogHandler) {
        var logLevelEnum = purchases_typescript_internal_1.LOG_LEVEL[logLevel];
        customLogHandler(logLevelEnum, message);
    }
});
eventEmitter === null || eventEmitter === void 0 ? void 0 : eventEmitter.addListener("Purchases-TrackedEvent", function (event) {
    var eventDictionary = event;
    trackedEventListeners.forEach(function (listener) { return listener({ eventDictionary: eventDictionary }); });
});
eventEmitter === null || eventEmitter === void 0 ? void 0 : eventEmitter.addListener("Purchases-DebugEvent", function (event) {
    var eventDictionary = event;
    debugEventListeners.forEach(function (listener) { return listener({ eventDictionary: eventDictionary }); });
});
function throwIfNotConfigured() {
    return __awaiter(this, void 0, void 0, function () {
        var isConfigured;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, Purchases.isConfigured()];
                case 1:
                    isConfigured = _a.sent();
                    if (!isConfigured) {
                        throw new purchases_typescript_internal_1.UninitializedPurchasesError();
                    }
                    return [2 /*return*/];
            }
        });
    });
}
var Purchases = /** @class */ (function () {
    function Purchases() {
    }
    /**
     * Sets up Purchases with your API key and an app user id.
     * @param {String} apiKey RevenueCat API Key. Needs to be a String
     * @param {String?} appUserID An optional unique id for identifying the user. Needs to be a string.
     * @param {PurchasesAreCompletedBy} [purchasesAreCompletedBy=PURCHASES_ARE_COMPLETED_BY_TYPE.REVENUECAT] Set this to an instance of PurchasesAreCompletedByMyApp if you have your own IAP implementation and want to use only RevenueCat's backend. Default is PURCHASES_ARE_COMPLETED_BY_TYPE.REVENUECAT.
     * @param {STOREKIT_VERSION} [storeKitVersion=DEFAULT] iOS-only. Defaults to STOREKIT_2. StoreKit 2 is only available on iOS 16+. StoreKit 1 will be used for previous iOS versions regardless of this setting.
     * @param {ENTITLEMENT_VERIFICATION_MODE} [entitlementVerificationMode=ENTITLEMENT_VERIFICATION_MODE.DISABLED] Sets the entitlement verifciation mode to use. For more details, check https://rev.cat/trusted-entitlements
     * @param {boolean} [useAmazon=false] An optional boolean. Android-only. Set this to true to enable Amazon on compatible devices.
     * @param {String?} userDefaultsSuiteName An optional string. iOS-only, will be ignored for Android.
     * Set this if you would like the RevenueCat SDK to store its preferences in a different NSUserDefaults suite, otherwise it will use standardUserDefaults.
     * Default is null, which will make the SDK use standardUserDefaults.
     * @param {boolean} [pendingTransactionsForPrepaidPlansEnabled=false] An optional boolean. Android-only. Set this to true to enable pending transactions for prepaid subscriptions in Google Play.
     * @param {boolean} [diagnosticsEnabled=false] An optional boolean. Set this to true to enable SDK diagnostics.
     * @param {boolean} [automaticDeviceIdentifierCollectionEnabled=true] An optional boolean. Set this to true to allow the collection of identifiers when setting the identifier for an attribution network.
     * @param {String?} [preferredUILocaleOverride] An optional string. Set this to the preferred UI locale to use for RevenueCat UI components.
     * @param {boolean} [useExternalPurchaseCustomLinks=false] Experimental. An optional boolean. iOS-only. Set this to true to make web purchase buttons that open in the external browser go through Apple's external purchase custom link flow.
     * @param {boolean} [enableExternalPurchasesInSimulator=true] Experimental. An optional boolean. iOS-only. Set this to false to make the simulator behave as a device does for a customer who is not eligible for external purchases.
     *
     * @warning If you use purchasesAreCompletedBy=PurchasesAreCompletedByMyApp, you must also provide a value for storeKitVersion.
     */
    Purchases.configure = function (configuration) {
        var apiKey = configuration.apiKey, _a = configuration.appUserID, appUserID = _a === void 0 ? null : _a, _b = configuration.purchasesAreCompletedBy, purchasesAreCompletedBy = _b === void 0 ? purchases_typescript_internal_1.PURCHASES_ARE_COMPLETED_BY_TYPE.REVENUECAT : _b, userDefaultsSuiteName = configuration.userDefaultsSuiteName, _c = configuration.storeKitVersion, storeKitVersion = _c === void 0 ? purchases_typescript_internal_1.STOREKIT_VERSION.DEFAULT : _c, _d = configuration.useAmazon, useAmazon = _d === void 0 ? false : _d, _e = configuration.shouldShowInAppMessagesAutomatically, shouldShowInAppMessagesAutomatically = _e === void 0 ? true : _e, _f = configuration.entitlementVerificationMode, entitlementVerificationMode = _f === void 0 ? purchases_typescript_internal_1.ENTITLEMENT_VERIFICATION_MODE.DISABLED : _f, _g = configuration.pendingTransactionsForPrepaidPlansEnabled, pendingTransactionsForPrepaidPlansEnabled = _g === void 0 ? false : _g, _h = configuration.diagnosticsEnabled, diagnosticsEnabled = _h === void 0 ? false : _h, _j = configuration.automaticDeviceIdentifierCollectionEnabled, automaticDeviceIdentifierCollectionEnabled = _j === void 0 ? true : _j, preferredUILocaleOverride = configuration.preferredUILocaleOverride, _k = configuration.useExternalPurchaseCustomLinks, useExternalPurchaseCustomLinks = _k === void 0 ? false : _k, _l = configuration.enableExternalPurchasesInSimulator, enableExternalPurchasesInSimulator = _l === void 0 ? true : _l;
        var _m = configuration, store = _m.store, galaxyBillingMode = _m.galaxyBillingMode;
        throwIfNativeModuleNotAvailable();
        if (!customLogHandler) {
            this.setLogHandler(function (logLevel, message) {
                switch (logLevel) {
                    case purchases_typescript_internal_1.LOG_LEVEL.DEBUG:
                        // tslint:disable-next-line:no-console
                        console.debug("[RevenueCat] ".concat(message));
                        break;
                    case purchases_typescript_internal_1.LOG_LEVEL.INFO:
                        // tslint:disable-next-line:no-console
                        console.info("[RevenueCat] ".concat(message));
                        break;
                    case purchases_typescript_internal_1.LOG_LEVEL.WARN:
                        // tslint:disable-next-line:no-console
                        console.warn("[RevenueCat] ".concat(message));
                        break;
                    case purchases_typescript_internal_1.LOG_LEVEL.ERROR:
                        // tslint:disable-next-line:no-console
                        console.error("[RevenueCat] ".concat(message));
                        break;
                    default:
                        // tslint:disable-next-line:no-console
                        console.log("[RevenueCat] ".concat(message));
                }
            });
        }
        if (apiKey === undefined || typeof apiKey !== "string") {
            throw new Error('Invalid API key. It must be called with an Object: configure({apiKey: "key"})');
        }
        if (appUserID !== null &&
            typeof appUserID !== "undefined" &&
            typeof appUserID !== "string") {
            throw new Error("appUserID needs to be a string");
        }
        var purchasesCompletedByToUse = purchases_typescript_internal_1.PURCHASES_ARE_COMPLETED_BY_TYPE.REVENUECAT;
        var storeKitVersionToUse = storeKitVersion;
        if (Purchases.isPurchasesAreCompletedByMyApp(purchasesAreCompletedBy)) {
            purchasesCompletedByToUse = purchases_typescript_internal_1.PURCHASES_ARE_COMPLETED_BY_TYPE.MY_APP;
            storeKitVersionToUse = purchasesAreCompletedBy.storeKitVersion;
            if (storeKitVersion !== purchases_typescript_internal_1.STOREKIT_VERSION.DEFAULT &&
                storeKitVersionToUse !== storeKitVersion) {
                // Typically, console messages aren't used in TS libraries, but in this case it's worth calling out the difference in
                // StoreKit versions, and since the difference isn't possible farther down the call chain, we should go ahead
                // and log it here.
                // tslint:disable-next-line:no-console
                console.warn("Warning: The storeKitVersion in purchasesAreCompletedBy does not match the function's storeKitVersion parameter. We will use the value found in purchasesAreCompletedBy.");
            }
            if (storeKitVersionToUse === purchases_typescript_internal_1.STOREKIT_VERSION.DEFAULT) {
                // tslint:disable-next-line:no-console
                console.warn("Warning: You should provide the specific StoreKit version you're using in your implementation when configuring PURCHASES_ARE_COMPLETED_BY_TYPE.MY_APP, and not rely on the DEFAULT.");
            }
        }
        RNPurchases.setupPurchases(apiKey, appUserID, purchasesCompletedByToUse, userDefaultsSuiteName, storeKitVersionToUse, useAmazon, store, galaxyBillingMode, shouldShowInAppMessagesAutomatically, entitlementVerificationMode, pendingTransactionsForPrepaidPlansEnabled, diagnosticsEnabled, automaticDeviceIdentifierCollectionEnabled, preferredUILocaleOverride, useExternalPurchaseCustomLinks, enableExternalPurchasesInSimulator);
    };
    /**
     * @deprecated, configure behavior through the RevenueCat dashboard (app.revenuecat.com) instead.
     * If an user tries to purchase a product that is active on the current app store account,
     * we will treat it as a restore and alias the new ID with the previous id.
     * If you have configured the Legacy restore behavior in the RevenueCat dashboard
     * and are currently setting this to true, keep this setting active.
     * @param {boolean} allowSharing Set this to true if you are passing in an appUserID but it is anonymous,
     * this is true by default if you didn't pass an appUserID
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet.
     */
    Purchases.setAllowSharingStoreAccount = function (allowSharing) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setAllowSharingStoreAccount(allowSharing);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * iOS only.
     * @param {boolean} simulatesAskToBuyInSandbox Set this property to true *only* when testing the ask-to-buy / SCA
     * purchases flow. More information: http://errors.rev.cat/ask-to-buy
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet.
     */
    Purchases.setSimulatesAskToBuyInSandbox = function (simulatesAskToBuyInSandbox) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                if (react_native_2.Platform.OS === "ios") {
                    RNPurchases.setSimulatesAskToBuyInSandbox(simulatesAskToBuyInSandbox);
                }
                return [2 /*return*/];
            });
        });
    };
    /**
     * Sets a function to be called on updated customer info
     * @param {CustomerInfoUpdateListener} customerInfoUpdateListener CustomerInfo update listener
     */
    Purchases.addCustomerInfoUpdateListener = function (customerInfoUpdateListener) {
        if (typeof customerInfoUpdateListener !== "function") {
            throw new Error("addCustomerInfoUpdateListener needs a function");
        }
        customerInfoUpdateListeners.push(customerInfoUpdateListener);
    };
    /**
     * Removes a given CustomerInfoUpdateListener
     * @param {CustomerInfoUpdateListener} listenerToRemove CustomerInfoUpdateListener reference of the listener to remove
     * @returns {boolean} True if listener was removed, false otherwise
     */
    Purchases.removeCustomerInfoUpdateListener = function (listenerToRemove) {
        if (customerInfoUpdateListeners.includes(listenerToRemove)) {
            customerInfoUpdateListeners = customerInfoUpdateListeners.filter(function (listener) { return listenerToRemove !== listener; });
            return true;
        }
        return false;
    };
    /**
     * Sets a function to be called on purchases initiated on the Apple App Store. This is only used in iOS.
     * @param {ShouldPurchasePromoProductListener} shouldPurchasePromoProductListener Called when a user initiates a
     * promotional in-app purchase from the App Store. If your app is able to handle a purchase at the current time, run
     * the deferredPurchase function. If the app is not in a state to make a purchase: cache the deferredPurchase, then
     * call the deferredPurchase when the app is ready to make the promotional purchase.
     * If the purchase should never be made, you don't need to ever call the deferredPurchase and the app will not
     * proceed with promotional purchases.
     */
    Purchases.addShouldPurchasePromoProductListener = function (shouldPurchasePromoProductListener) {
        if (typeof shouldPurchasePromoProductListener !== "function") {
            throw new Error("addShouldPurchasePromoProductListener needs a function");
        }
        shouldPurchasePromoProductListeners.push(shouldPurchasePromoProductListener);
    };
    /**
     * Removes a given ShouldPurchasePromoProductListener
     * @param {ShouldPurchasePromoProductListener} listenerToRemove ShouldPurchasePromoProductListener reference of
     * the listener to remove
     * @returns {boolean} True if listener was removed, false otherwise
     */
    Purchases.removeShouldPurchasePromoProductListener = function (listenerToRemove) {
        if (shouldPurchasePromoProductListeners.includes(listenerToRemove)) {
            shouldPurchasePromoProductListeners =
                shouldPurchasePromoProductListeners.filter(function (listener) { return listenerToRemove !== listener; });
            return true;
        }
        return false;
    };
    /**
     * Gets the map of entitlements -> offerings -> products
     * @returns {Promise<PurchasesOfferings>} Promise of entitlements structure. The promise will be rejected if configure
     * has not been called yet.
     */
    Purchases.getOfferings = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, RNPurchases.getOfferings()];
                }
            });
        });
    };
    /**
     * Retrieves a current offering for a placement identifier, use this to access offerings defined by targeting
     * placements configured in the RevenueCat dashboard.
     * @param {String} placementIdentifier The placement identifier to fetch a current offeringn for
     * @returns {Promise<PurchasesOffering | null>} Promise of an optional offering. The promise will be rejected if configure
     * has not been called yet.
     */
    Purchases.getCurrentOfferingForPlacement = function (placementIdentifier) {
        return __awaiter(this, void 0, void 0, function () {
            var offering;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, RNPurchases.getCurrentOfferingForPlacement(placementIdentifier)];
                    case 2:
                        offering = _a.sent();
                        return [2 /*return*/, offering !== null && offering !== void 0 ? offering : null];
                }
            });
        });
    };
    /**
     * Syncs subscriber attributes and then fetches the configured offerings for this user. This method is intended to
     * be called when using Targeting Rules with Custom Attributes. Any subscriber attributes should be set before
     * calling this method to ensure the returned offerings are applied with the latest subscriber attributes.
     * @returns {Promise<PurchasesOfferings>} Promise of entitlements structure. The promise will be rejected if configure
     * has not been called yet.
     */
    Purchases.syncAttributesAndOfferingsIfNeeded = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, RNPurchases.syncAttributesAndOfferingsIfNeeded()];
                }
            });
        });
    };
    /**
     * Sets attribution data from Appstack's attribution params, then syncs subscriber attributes and fetches
     * fresh offerings so that Appstack-based targeting is applied before the promise resolves.
     *
     * Pass the object received from the Appstack Attribution SDK's `getAttributionParams()` directly.
     * The SDK extracts relevant attribution info and sets the appropriate subscriber attributes.
     *
     * @param {object} data The attribution params from the Appstack Attribution SDK.
     * @returns {Promise<PurchasesOfferings>} Promise of offerings targeted with Appstack data.
     */
    Purchases.setAppstackAttributionParams = function (data) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, RNPurchases.setAppstackAttributionParams(data)];
                }
            });
        });
    };
    /**
     * Fetch the product info
     * @param {String[]} productIdentifiers Array of product identifiers
     * @param {String} type Optional type of products to fetch, can be SUBSCRIPTION or NON_SUBSCRIPTION. SUBSCRIPTION by default
     * @returns {Promise<PurchasesStoreProduct[]>} A promise containing an array of products. The promise will be rejected
     * if the products are not properly configured in RevenueCat or if there is another error retrieving them.
     * Rejections return an error code, and a userInfo object with more information. The promise will also be rejected
     * if configure has not been called yet.
     */
    Purchases.getProducts = function (productIdentifiers_1) {
        return __awaiter(this, arguments, void 0, function (productIdentifiers, type) {
            if (type === void 0) { type = purchases_typescript_internal_1.PRODUCT_CATEGORY.SUBSCRIPTION; }
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, RNPurchases.getProductInfo(productIdentifiers, type)];
                }
            });
        });
    };
    /**
     * Make a purchase
     *
     * @param {String} productIdentifier The product identifier of the product you want to purchase
     * @param {UpgradeInfo} upgradeInfo Android only. Optional UpgradeInfo you wish to upgrade from containing the oldSKU
     * and the optional prorationMode.
     * @param {String} type Optional type of product, can be inapp or subs. Subs by default
     * @deprecated, use purchaseStoreProduct instead
     */
    Purchases.purchaseProduct = function (productIdentifier_1, upgradeInfo_1) {
        return __awaiter(this, arguments, void 0, function (productIdentifier, upgradeInfo, type) {
            if (type === void 0) { type = purchases_typescript_internal_1.PURCHASE_TYPE.SUBS; }
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, RNPurchases.purchaseProduct(productIdentifier, upgradeInfo, type, null, null, null)];
                }
            });
        });
    };
    /**
     * Make a purchase
     *
     * @param {PurchasesStoreProduct} product The product you want to purchase
     * @param {GoogleProductChangeInfo | StoreProductChangeInfo} productChangeInfo Android only. Optional product change info you
     * wish to upgrade from containing the oldProductIdentifier and the optional prorationMode or replacementMode.
     * @param {boolean} googleIsPersonalizedPrice Android and Google only. Optional boolean indicates personalized pricing on products available for purchase in the EU.
     * For compliance with EU regulations. User will see "This price has been customized for you" in the purchase dialog when true.
     * See https://developer.android.com/google/play/billing/integrate#personalized-price for more info.
     * @returns {Promise<{ productIdentifier: string, customerInfo:CustomerInfo }>} A promise of an object containing
     * a customer info object and a product identifier. Rejections return an error code,
     * a boolean indicating if the user cancelled the purchase, and an object with more information. The promise will
     * also be rejected if configure has not been called yet.
     */
    Purchases.purchaseStoreProduct = function (product, productChangeInfo, googleIsPersonalizedPrice) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, RNPurchases.purchaseProduct(product.identifier, productChangeInfo, product.productCategory, null, googleIsPersonalizedPrice == null
                                ? null
                                : { isPersonalizedPrice: googleIsPersonalizedPrice }, product.presentedOfferingContext)];
                }
            });
        });
    };
    /**
     * iOS only. Purchase a product applying a given discount.
     *
     * @param {PurchasesStoreProduct} product The product you want to purchase
     * @param {PurchasesPromotionalOffer} discount Discount to apply to this package. Retrieve this discount using getPromotionalOffer.
     * @param {boolean} googleIsPersonalizedPrice Android and Google only. Optional boolean indicates personalized pricing on products available for purchase in the EU.
     * For compliance with EU regulations. User will see "This price has been customize for you" in the purchase dialog when true.
     * See https://developer.android.com/google/play/billing/integrate#personalized-price for more info.
     * @returns {Promise<{ productIdentifier: string, customerInfo:CustomerInfo }>} A promise of an object containing
     * a customer info object and a product identifier. Rejections return an error code,
     * a boolean indicating if the user cancelled the purchase, and an object with more information. The promise will be
     * rejected if configure has not been called yet.
     */
    Purchases.purchaseDiscountedProduct = function (product, discount) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        if (typeof discount === "undefined" || discount == null) {
                            throw new Error("A discount is required");
                        }
                        return [2 /*return*/, RNPurchases.purchaseProduct(product.identifier, null, null, discount.timestamp.toString(), null, product.presentedOfferingContext)];
                }
            });
        });
    };
    /**
     * Make a purchase
     *
     * @param {PurchasesPackage} aPackage The Package you wish to purchase. You can get the Packages by calling getOfferings
     * @param {UpgradeInfo} upgradeInfo DEPRECATED. Use productChangeInfo.
     * @param {GoogleProductChangeInfo | StoreProductChangeInfo} productChangeInfo Android only. Optional product change info you
     * wish to upgrade from containing the oldProductIdentifier and the optional prorationMode or replacementMode.
     * @param {boolean} googleIsPersonalizedPrice Android and Google only. Optional boolean indicates personalized pricing on products available for purchase in the EU.
     * For compliance with EU regulations. User will see "This price has been customized for you" in the purchase dialog when true.
     * See https://developer.android.com/google/play/billing/integrate#personalized-price for more info.
     * @returns {Promise<{ productIdentifier: string, customerInfo: CustomerInfo }>} A promise of an object containing
     * a customer info object and a product identifier. Rejections return an error code, a boolean indicating if the
     * user cancelled the purchase, and an object with more information. The promise will be also be rejected if configure
     * has not been called yet.
     */
    Purchases.purchasePackage = function (aPackage, upgradeInfo, productChangeInfo, googleIsPersonalizedPrice) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, RNPurchases.purchasePackage(aPackage.identifier, aPackage.presentedOfferingContext, productChangeInfo || upgradeInfo, null, googleIsPersonalizedPrice == null
                                ? null
                                : { isPersonalizedPrice: googleIsPersonalizedPrice })];
                }
            });
        });
    };
    /**
     * Google only. Make a purchase of a subscriptionOption
     *
     * @param {SubscriptionOption} subscriptionOption The SubscriptionOption you wish to purchase. You can get the SubscriptionOption from StoreProducts by calling getOfferings
     * @param {GoogleProductChangeInfo | StoreProductChangeInfo} productChangeInfo Android only. Optional product change info you
     * wish to upgrade from containing the oldProductIdentifier and the optional prorationMode or replacementMode.
     * @param {boolean} googleIsPersonalizedPrice Android and Google only. Optional boolean indicates personalized pricing on products available for purchase in the EU.
     * For compliance with EU regulations. User will see "This price has been customized for you" in the purchase dialog when true.
     * See https://developer.android.com/google/play/billing/integrate#personalized-price for more info.
     * @returns {Promise<{ productIdentifier: string, customerInfo: CustomerInfo }>} A promise of an object containing
     * a customer info object and a product identifier. Rejections return an error code, a boolean indicating if the
     * user cancelled the purchase, and an object with more information. The promise will be also be rejected if configure
     * has not been called yet.
     */
    Purchases.purchaseSubscriptionOption = function (subscriptionOption, productChangeInfo, googleIsPersonalizedPrice) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, Purchases.throwIfIOSPlatform()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/, RNPurchases.purchaseSubscriptionOption(subscriptionOption.productId, subscriptionOption.id, productChangeInfo, null, googleIsPersonalizedPrice == null
                                ? null
                                : { isPersonalizedPrice: googleIsPersonalizedPrice }, subscriptionOption.presentedOfferingContext)];
                }
            });
        });
    };
    /**
     * iOS only. Purchase a package applying a given discount.
     *
     * @param {PurchasesPackage} aPackage The Package you wish to purchase. You can get the Packages by calling getOfferings
     * @param {PurchasesPromotionalOffer} discount Discount to apply to this package. Retrieve this discount using getPromotionalOffer.
     * @returns {Promise<{ productIdentifier: string, customerInfo: CustomerInfo }>} A promise of an object containing
     * a customer info object and a product identifier. Rejections return an error code, a boolean indicating if the
     * user cancelled the purchase, and an object with more information. The promise will be also be rejected if configure
     * has not been called yet.
     */
    Purchases.purchaseDiscountedPackage = function (aPackage, discount) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        if (typeof discount === "undefined" || discount == null) {
                            throw new Error("A discount is required");
                        }
                        return [2 /*return*/, RNPurchases.purchasePackage(aPackage.identifier, aPackage.presentedOfferingContext, null, discount.timestamp.toString(), null)];
                }
            });
        });
    };
    /**
     * Restores a user's previous purchases and links their appUserIDs to any user's also using those purchases.
     * @returns {Promise<CustomerInfo>} A promise of a customer info object. Rejections return an error code, and an
     * userInfo object with more information. The promise will be also be rejected if configure has not been called yet.
     */
    Purchases.restorePurchases = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, RNPurchases.restorePurchases()];
                }
            });
        });
    };
    /**
     * Get the appUserID
     * @returns {Promise<string>} The app user id in a promise
     */
    Purchases.getAppUserID = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, RNPurchases.getAppUserID()];
                }
            });
        });
    };
    /**
     * Gets the storefront for the current store account.
     * @returns {Promise<Storefront | null>} The storefront for the current store account, or null if the storefront is not available.
     */
    Purchases.getStorefront = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, RNPurchases.getStorefront()];
                }
            });
        });
    };
    /**
     * This function will logIn the current user with an appUserID. Typically this would be used after a log in
     * to identify a user without calling configure.
     * @param {String} appUserID The appUserID that should be linked to the currently user
     * @returns {Promise<LogInResult>} A promise of an object that contains the customerInfo after logging in, as well
     * as a boolean indicating whether the user has just been created for the first time in the RevenueCat backend. The
     * promise will be rejected if configure has not been called yet or if there's an issue logging in.
     */
    Purchases.logIn = function (appUserID) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        // noinspection SuspiciousTypeOfGuard
                        if (typeof appUserID !== "string") {
                            throw new Error("appUserID needs to be a string");
                        }
                        return [2 /*return*/, RNPurchases.logIn(appUserID)];
                }
            });
        });
    };
    /**
     * Logs out the Purchases client clearing the saved appUserID. This will generate a random user id and save it in the cache.
     * @returns {Promise<CustomerInfo>} A promise of a customer info object. Rejections return an error code,
     * and a userInfo object with more information. The promise will be rejected if configure has not been called yet or if
     * there's an issue logging out.
     */
    Purchases.logOut = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, RNPurchases.logOut()];
                }
            });
        });
    };
    /**
     * Enables/Disables debugs logs
     * @param {boolean} enabled Enable or not debug logs
     * @deprecated, use setLogLevel instead
     */
    Purchases.setDebugLogsEnabled = function (enabled) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                RNPurchases.setDebugLogsEnabled(enabled);
                return [2 /*return*/];
            });
        });
    };
    /**
     * Used to set the log level. Useful for debugging issues with the lovely team @RevenueCat.
     * The default is {LOG_LEVEL.INFO} in release builds and {LOG_LEVEL.DEBUG} in debug builds.
     * @param {LOG_LEVEL} level
     */
    Purchases.setLogLevel = function (level) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                RNPurchases.setLogLevel(level);
                return [2 /*return*/];
            });
        });
    };
    /**
     * Set a custom log handler for redirecting logs to your own logging system.
     * By default, this sends info, warning, and error messages.
     * If you wish to receive Debug level messages, see [setLogLevel].
     * @param {LogHandler} logHandler It will get called for each log event.
     * Use this function to redirect the log to your own logging system
     */
    Purchases.setLogHandler = function (logHandler) {
        customLogHandler = logHandler;
        if (usingBrowserMode) {
            RNPurchases.setLogHandler(logHandler);
        }
        else {
            RNPurchases.setLogHandler();
        }
    };
    /**
     * Sets a function to be called when a feature event is tracked by RevenueCatUI.
     * This is a debug API for monitoring paywall and customer center events not meant for public use.
     * Currently only works on Android and iOS.
     * @internal
     * @param {TrackedEventListener} trackedEventListener TrackedEvent listener
     */
    Purchases.addTrackedEventListener = function (trackedEventListener) {
        return __awaiter(this, void 0, void 0, function () {
            var isFirstListener;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        if (react_native_2.Platform.OS === "android" || react_native_2.Platform.OS === "ios") {
                            if (typeof trackedEventListener !== "function") {
                                throw new Error("addTrackedEventListener needs a function");
                            }
                            isFirstListener = trackedEventListeners.length === 0;
                            trackedEventListeners.push(trackedEventListener);
                            if (isFirstListener && !usingBrowserMode) {
                                RNPurchases.setTrackedEventListener();
                            }
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Removes a given TrackedEventListener.
     * This is a debug API not meant for public use.
     * @internal
     * @param trackedEventListener TrackedEvent listener to remove
     */
    Purchases.removeTrackedEventListener = function (trackedEventListener) {
        trackedEventListeners = trackedEventListeners.filter(function (listener) { return listener !== trackedEventListener; });
    };
    /**
     * Sets a function to be called when a debug event is tracked by RevenueCat.
     * This is a debug API for monitoring debug events not meant for public use.
     * Currently only works on Android.
     * @internal
     * @param {DebugEventListener} debugEventListener DebugEvent listener
     */
    Purchases.addDebugEventListener = function (debugEventListener) {
        return __awaiter(this, void 0, void 0, function () {
            var isFirstListener;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        if (react_native_2.Platform.OS === "android") {
                            if (typeof debugEventListener !== "function") {
                                throw new Error("addDebugEventListener needs a function");
                            }
                            isFirstListener = debugEventListeners.length === 0;
                            debugEventListeners.push(debugEventListener);
                            if (isFirstListener && !usingBrowserMode) {
                                RNPurchases.setDebugEventListener();
                            }
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Removes a given DebugEventListener.
     * This is a debug API not meant for public use.
     * @internal
     * @param debugEventListener DebugEventListener listener to remove
     */
    Purchases.removeDebugEventListener = function (debugEventListener) {
        debugEventListeners = debugEventListeners.filter(function (listener) { return listener !== debugEventListener; });
    };
    /**
     * Gets current customer info
     * @returns {Promise<CustomerInfo>} A promise of a customer info object. Rejections return an error code, and an
     * userInfo object with more information. The promise will be rejected if configure has not been called yet or if
     * there's an issue getting the customer information.
     */
    Purchases.getCustomerInfo = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, RNPurchases.getCustomerInfo()];
                }
            });
        });
    };
    /**
     * This method will send all the purchases to the RevenueCat backend. Call this when using your own implementation
     * for subscriptions anytime a sync is needed, like after a successful purchase.
     *
     * @deprecated Use {@link syncPurchasesForResult} instead, which returns the updated CustomerInfo.
     * @warning This function should only be called if you're not calling purchaseProduct/purchaseStoreProduct/purchasePackage/purchaseSubscriptionOption.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * syncing purchases.
     */
    Purchases.syncPurchases = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.syncPurchases();
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * This method will send all the purchases to the RevenueCat backend. Call this when using your own implementation
     * for subscriptions anytime a sync is needed, like after a successful purchase.
     *
     * @warning This function should only be called if you're not calling purchaseProduct/purchaseStoreProduct/purchasePackage/purchaseSubscriptionOption.
     * @returns {Promise<SyncPurchasesResult>} A promise containing the sync result with customer info. The promise will
     * be rejected if configure has not been called yet or if there's an error syncing purchases.
     */
    Purchases.syncPurchasesForResult = function () {
        return __awaiter(this, void 0, void 0, function () {
            var customerInfo;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, RNPurchases.syncPurchasesForResult()];
                    case 2:
                        customerInfo = _a.sent();
                        return [2 /*return*/, { customerInfo: customerInfo }];
                }
            });
        });
    };
    /**
     * This method will send a purchase to the RevenueCat backend. This function should only be called if you are
     * in Amazon observer mode or performing a client side migration of your current users to RevenueCat.
     *
     * The receipt IDs are cached if successfully posted so they are not posted more than once.
     *
     * @param {string} productID Product ID associated to the purchase.
     * @param {string} receiptID ReceiptId that represents the Amazon purchase.
     * @param {string} amazonUserID Amazon's userID. This parameter will be ignored when syncing a Google purchase.
     * @param {(string|null|undefined)} isoCurrencyCode Product's currency code in ISO 4217 format.
     * @param {(number|null|undefined)} price Product's price.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * syncing purchases.
     */
    Purchases.syncAmazonPurchase = function (productID, receiptID, amazonUserID, isoCurrencyCode, price) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, Purchases.throwIfIOSPlatform()];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, throwIfNotConfigured()];
                    case 2:
                        _a.sent();
                        RNPurchases.syncAmazonPurchase(productID, receiptID, amazonUserID, isoCurrencyCode, price);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * @deprecated, use syncAmazonPurchase instead.
     *
     * This method will send a purchase to the RevenueCat backend. This function should only be called if you are
     * in Amazon observer mode or performing a client side migration of your current users to RevenueCat.
     *
     * The receipt IDs are cached if successfully posted so they are not posted more than once.
     *
     * @param {string} productID Product ID associated to the purchase.
     * @param {string} receiptID ReceiptId that represents the Amazon purchase.
     * @param {string} amazonUserID Amazon's userID. This parameter will be ignored when syncing a Google purchase.
     * @param {(string|null|undefined)} isoCurrencyCode Product's currency code in ISO 4217 format.
     * @param {(number|null|undefined)} price Product's price.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * syncing purchases.
     */
    Purchases.syncObserverModeAmazonPurchase = function (productID, receiptID, amazonUserID, isoCurrencyCode, price) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, Purchases.throwIfIOSPlatform()];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, throwIfNotConfigured()];
                    case 2:
                        _a.sent();
                        RNPurchases.syncObserverModeAmazonPurchase(productID, receiptID, amazonUserID, isoCurrencyCode, price);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * iOS only. Always returns an error on iOS < 15.
     *
     * Use this method only if you already have your own IAP implementation using StoreKit 2 and want to use
     * RevenueCat's backend. If you are using StoreKit 1 for your implementation, you do not need this method.
     *
     * You only need to use this method with *new* purchases. Subscription updates are observed automatically.
     *
     * Important: This should only be used if you have set PurchasesAreCompletedBy to MY_APP during SDK configuration.
     *
     * @warning You need to finish the transaction yourself after calling this method.
     *
     * @param {string} productID Product ID that was just purchased
     * @returns {Promise<PurchasesStoreTransaction>} If there was a transacton found and handled for the provided product ID.
     */
    Purchases.recordPurchase = function (productID) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, Purchases.throwIfAndroidPlatform()];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, throwIfNotConfigured()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/, RNPurchases.recordPurchaseForProductID(productID)];
                }
            });
        });
    };
    /**
     * Enable automatic collection of Apple Search Ad attribution on iOS. Disabled by default
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet.
     */
    Purchases.enableAdServicesAttributionTokenCollection = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!(react_native_2.Platform.OS === "ios")) return [3 /*break*/, 2];
                        return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.enableAdServicesAttributionTokenCollection();
                        _a.label = 2;
                    case 2: return [2 /*return*/];
                }
            });
        });
    };
    /**
     * @returns { Promise<boolean> } If the `appUserID` has been generated by RevenueCat or not.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet.
     */
    Purchases.isAnonymous = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, RNPurchases.isAnonymous()];
                }
            });
        });
    };
    /**
     * iOS only. Computes whether or not a user is eligible for the introductory pricing period of a given product.
     * You should use this method to determine whether or not you show the user the normal product price or the
     * introductory price. This also applies to trials (trials are considered a type of introductory pricing).
     *
     * @note Subscription groups are automatically collected for determining eligibility. If RevenueCat can't
     * definitively compute the eligibility, most likely because of missing group information, it will return
     * `INTRO_ELIGIBILITY_STATUS_UNKNOWN`. The best course of action on unknown status is to display the non-intro
     * pricing, to not create a misleading situation. To avoid this, make sure you are testing with the latest version of
     * iOS so that the subscription group can be collected by the SDK. Android always returns INTRO_ELIGIBILITY_STATUS_UNKNOWN.
     *
     * @param productIdentifiers Array of product identifiers for which you want to compute eligibility
     * @returns { Promise<[productId: string]: IntroEligibility> } A map of IntroEligility per productId. The promise
     * will be rejected if configure has not been called yet or if there's in an error checking eligibility.
     */
    Purchases.checkTrialOrIntroductoryPriceEligibility = function (productIdentifiers) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, RNPurchases.checkTrialOrIntroductoryPriceEligibility(productIdentifiers)];
                }
            });
        });
    };
    /**
     * iOS only. Use this function to retrieve the `PurchasesPromotionalOffer` for a given `PurchasesPackage`.
     *
     * @param product The `PurchasesStoreProduct` the user intends to purchase.
     * @param discount The `PurchasesStoreProductDiscount` to apply to the product.
     * @returns { Promise<PurchasesPromotionalOffer> } Returns when the `PurchasesPaymentDiscount` is returned.
     * Null is returned for Android and incompatible iOS versions. The promise will be rejected if configure has not been
     * called yet or if there's an error getting the payment discount.
     */
    Purchases.getPromotionalOffer = function (product, discount) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        if (react_native_2.Platform.OS === "android") {
                            return [2 /*return*/, Promise.resolve(undefined)];
                        }
                        if (typeof discount === "undefined" || discount == null) {
                            throw new Error("A discount is required");
                        }
                        return [2 /*return*/, RNPurchases.getPromotionalOffer(product.identifier, discount.identifier)];
                }
            });
        });
    };
    /**
     * iOS only. Use this function to retrieve the eligible `PurchasesWinBackOffer`s that a subscriber
     * is eligible for for a given `PurchasesProduct`.
     *
     * @param product The `PurchasesStoreProduct` the user intends to purchase.
     * @returns { Promise<[PurchasesWinBackOffer]> } Returns an array of win-back offers that the subscriber is eligible for.
     * Null is returned for Android and incompatible iOS versions. The promise will be rejected if configure has not been
     * called yet or if there's an error getting the payment discount.
     */
    Purchases.getEligibleWinBackOffersForProduct = function (product) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        if (react_native_2.Platform.OS === "android") {
                            return [2 /*return*/, Promise.resolve(undefined)];
                        }
                        return [2 /*return*/, RNPurchases.eligibleWinBackOffersForProductIdentifier(product.identifier)];
                }
            });
        });
    };
    /**
     * iOS only. Use this function to retrieve the eligible `PurchasesWinBackOffer`s that a subscriber
     * is eligible for for a given `PurchasesPackage`.
     *
     * @param aPackage The `PurchasesPackage` the user intends to purchase.
     * @returns { Promise<[PurchasesWinBackOffer]> } Returns an array of win-back offers that the subscriber is eligible for.
     * Null is returned for Android and incompatible iOS versions. The promise will be rejected if configure has not been
     * called yet or if there's an error getting the payment discount.
     */
    Purchases.getEligibleWinBackOffersForPackage = function (aPackage) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        if (react_native_2.Platform.OS === "android") {
                            return [2 /*return*/, Promise.resolve(undefined)];
                        }
                        return [2 /*return*/, RNPurchases.eligibleWinBackOffersForProductIdentifier(aPackage.product.identifier)];
                }
            });
        });
    };
    /**
     * iOS only. Purchase a product applying a given win-back offer.
     *
     * Only available on iOS 18.0+ when StoreKit 2 is enabled.
     *
     * @param {PurchasesStoreProduct} product The product you want to purchase
     * @param {PurchasesWinBackOffer} winBackOffer Win-back offer to apply to this package. Retrieve this offer using getEligibleWinBackOffers.
     * @returns {Promise<{ productIdentifier: string, customerInfo:CustomerInfo }>} A promise of an object containing
     * a customer info object and a product identifier. Rejections return an error code,
     * a boolean indicating if the user cancelled the purchase, and an object with more information. The promise will be
     * rejected if configure has not been called yet.
     */
    Purchases.purchaseProductWithWinBackOffer = function (product, winBackOffer) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        if (typeof winBackOffer === "undefined" || winBackOffer == null) {
                            throw new Error("A win-back offer is required");
                        }
                        if (react_native_2.Platform.OS === "android") {
                            throw new purchases_typescript_internal_1.UnsupportedPlatformError();
                        }
                        return [2 /*return*/, RNPurchases.purchaseProductWithWinBackOffer(product.identifier, winBackOffer.identifier)];
                }
            });
        });
    };
    /**
     * iOS only. Purchase a package applying a given win-back offer.
     *
     * Only available on iOS 18.0+ when StoreKit 2 is enabled.
     *
     * @param {PurchasesStoreProduct} product The product you want to purchase
     * @param {PurchasesWinBackOffer} winBackOffer Win-back offer to apply to this package. Retrieve this offer using getEligibleWinBackOffers.
     * @returns {Promise<{ productIdentifier: string, customerInfo:CustomerInfo }>} A promise of an object containing
     * a customer info object and a product identifier. Rejections return an error code,
     * a boolean indicating if the user cancelled the purchase, and an object with more information. The promise will be
     * rejected if configure has not been called yet.
     */
    Purchases.purchasePackageWithWinBackOffer = function (aPackage, winBackOffer) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        if (typeof winBackOffer === "undefined" || winBackOffer == null) {
                            throw new Error("A win-back offer is required");
                        }
                        if (react_native_2.Platform.OS === "android") {
                            throw new purchases_typescript_internal_1.UnsupportedPlatformError();
                        }
                        return [2 /*return*/, RNPurchases.purchasePackageWithWinBackOffer(aPackage.identifier, aPackage.presentedOfferingContext, winBackOffer.identifier)];
                }
            });
        });
    };
    /**
     * Invalidates the cache for customer information.
     *
     * Most apps will not need to use this method; invalidating the cache can leave your app in an invalid state.
     * Refer to https://docs.revenuecat.com/docs/customer-info#section-get-user-information for more information on
     * using the cache properly.
     *
     * This is useful for cases where customer information might have been updated outside of the app, like if a
     * promotional subscription is granted through the RevenueCat dashboard.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or there's an error
     * invalidating the customer info cache.
     */
    Purchases.invalidateCustomerInfoCache = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.invalidateCustomerInfoCache();
                        return [2 /*return*/];
                }
            });
        });
    };
    /** iOS only. Presents a code redemption sheet, useful for redeeming offer codes
     * Refer to https://docs.revenuecat.com/docs/ios-subscription-offers#offer-codes for more information on how
     * to configure and use offer codes
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or there's an error
     * presenting the code redemption sheet.
     */
    Purchases.presentCodeRedemptionSheet = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!(react_native_2.Platform.OS === "ios")) return [3 /*break*/, 2];
                        return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.presentCodeRedemptionSheet();
                        _a.label = 2;
                    case 2: return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attributes are useful for storing additional, structured information on a user.
     * Since attributes are writable using a public key they should not be used for
     * managing secure or sensitive information such as subscription status, coins, etc.
     *
     * Key names starting with "$" are reserved names used by RevenueCat. For a full list of key
     * restrictions refer to our guide: https://docs.revenuecat.com/docs/subscriber-attributes
     *
     * @param attributes Map of attributes by key. Set the value as an empty string to delete an attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or there's an error
     * setting the subscriber attributes.
     */
    Purchases.setAttributes = function (attributes) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setAttributes(attributes);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the email address for the user
     *
     * @param email Empty String or null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting the email.
     */
    Purchases.setEmail = function (email) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setEmail(email);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the phone number for the user
     *
     * @param phoneNumber Empty String or null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting the phone number.
     */
    Purchases.setPhoneNumber = function (phoneNumber) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setPhoneNumber(phoneNumber);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the display name for the user
     *
     * @param displayName Empty String or null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting the display name.
     */
    Purchases.setDisplayName = function (displayName) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setDisplayName(displayName);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the push token for the user
     *
     * @param pushToken null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting the push token.
     */
    Purchases.setPushToken = function (pushToken) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setPushToken(pushToken);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Set this property to your proxy URL before configuring Purchases *only* if you've received a proxy key value
     * from your RevenueCat contact.
     * @returns {Promise<void>} The promise to be returned after setting the proxy has been completed.
     */
    Purchases.setProxyURL = function (url) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, RNPurchases.setProxyURLString(url)];
            });
        });
    };
    /**
     * Automatically collect subscriber attributes associated with the device identifiers.
     * $idfa, $idfv, $ip on iOS
     * $gpsAdId, $androidId, $ip on Android
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting collecting the device identifiers.
     */
    Purchases.collectDeviceIdentifiers = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.collectDeviceIdentifiers();
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the Adjust Id for the user
     * Required for the RevenueCat Adjust integration
     *
     * @param adjustID Adjust ID to use in Adjust integration. Empty String or null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting Adjust ID.
     */
    Purchases.setAdjustID = function (adjustID) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setAdjustID(adjustID);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the AppsFlyer Id for the user
     * Required for the RevenueCat AppsFlyer integration
     * @param appsflyerID Appsflyer ID to use in Appsflyer integration. Empty String or null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting the Appsflyer ID.
     */
    Purchases.setAppsflyerID = function (appsflyerID) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setAppsflyerID(appsflyerID);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the Facebook SDK Anonymous Id for the user
     * Recommended for the RevenueCat Facebook integration
     *
     * @param fbAnonymousID Facebook Anonymous ID to use in Mparticle integration. Empty String or null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting the Facebook Anonymous ID.
     */
    Purchases.setFBAnonymousID = function (fbAnonymousID) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setFBAnonymousID(fbAnonymousID);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the mParticle Id for the user
     * Recommended for the RevenueCat mParticle integration
     *
     * @param mparticleID Mparticle ID to use in Mparticle integration. Empty String or null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting the Mparticle ID.
     */
    Purchases.setMparticleID = function (mparticleID) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setMparticleID(mparticleID);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the CleverTap Id for the user
     * Required for the RevenueCat CleverTap integration
     *
     * @param cleverTapID CleverTap user ID to use in CleverTap integration. Empty String or null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting the CleverTap ID.
     */
    Purchases.setCleverTapID = function (cleverTapID) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setCleverTapID(cleverTapID);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the Mixpanel Distinct Id for the user
     * Required for the RevenueCat Mixpanel integration
     *
     * @param mixpanelDistinctID Mixpanel Distinct ID to use in Mixpanel integration. Empty String or null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting the Mixpanel Distinct ID.
     */
    Purchases.setMixpanelDistinctID = function (mixpanelDistinctID) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setMixpanelDistinctID(mixpanelDistinctID);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the Firebase App Instance ID for the user
     * Required for the RevenueCat Firebase integration
     *
     * @param firebaseAppInstanceID Firebase App Instance ID to use in Firebase integration. Empty String or null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting the Firebase App Instance ID.
     */
    Purchases.setFirebaseAppInstanceID = function (firebaseAppInstanceID) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setFirebaseAppInstanceID(firebaseAppInstanceID);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the Tenjin Analytics Installation ID for the user.
     * Required for the RevenueCat Tenjin integration.
     *
     * @param tenjinAnalyticsInstallationID Tenjin analytics installation ID to use in the Tenjin integration. Empty String or null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting the Tenjin Analytics Installation ID.
     */
    Purchases.setTenjinAnalyticsInstallationID = function (tenjinAnalyticsInstallationID) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setTenjinAnalyticsInstallationID(tenjinAnalyticsInstallationID);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the Kochava Device ID for the user.
     * Required for the RevenueCat Kochava integration.
     *
     * @param kochavaDeviceID Kochava device ID to use in the Kochava integration. Empty String or null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting the Kochava Device ID.
     */
    Purchases.setKochavaDeviceID = function (kochavaDeviceID) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setKochavaDeviceID(kochavaDeviceID);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the Singular Device ID (SDID) for the user.
     * Required for the RevenueCat Singular integration when using Singular's Event
     * Endpoint V2.
     *
     * The SDID is generated by the Singular SDK and cannot be collected by
     * collectDeviceIdentifiers, so it has to be forwarded by the app.
     *
     * @param singularDeviceID Singular device ID to use in the Singular integration. Empty String or null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting the Singular Device ID.
     */
    Purchases.setSingularDeviceID = function (singularDeviceID) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setSingularDeviceID(singularDeviceID);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the OneSignal Player Id for the user
     * Required for the RevenueCat OneSignal integration with OneSignal SDK v4.0 and below
     * (OneSignal API v9). For OneSignal SDK v5.0 and above, use {@link setOnesignalUserID} instead.
     *
     * @param onesignalID OneSignal Player ID to use in OneSignal integration. Empty String or null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting the OneSignal ID.
     */
    Purchases.setOnesignalID = function (onesignalID) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setOnesignalID(onesignalID);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the OneSignal User ID for the user
     * Required for the RevenueCat OneSignal integration with OneSignal SDK v5.0
     * and above (OneSignal API v11+).
     *
     * @param onesignalUserID OneSignal User ID to use in OneSignal integration. Empty String or null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting the OneSignal user ID.
     */
    Purchases.setOnesignalUserID = function (onesignalUserID) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setOnesignalUserID(onesignalUserID);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the Airship Channel Id for the user
     * Required for the RevenueCat Airship integration
     *
     * @param airshipChannelID Airship Channel ID to use in Airship integration. Empty String or null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting the Airship Channel ID.
     */
    Purchases.setAirshipChannelID = function (airshipChannelID) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setAirshipChannelID(airshipChannelID);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the install media source for the user
     *
     * @param mediaSource Empty String or null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting the media source.
     */
    Purchases.setMediaSource = function (mediaSource) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setMediaSource(mediaSource);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the install campaign for the user
     *
     * @param campaign Empty String or null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting the campaign.
     */
    Purchases.setCampaign = function (campaign) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setCampaign(campaign);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the install ad group for the user
     *
     * @param adGroup Empty String or null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting ad group.
     */
    Purchases.setAdGroup = function (adGroup) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setAdGroup(adGroup);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the install ad for the user
     *
     * @param ad Empty String or null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting the ad subscriber attribute.
     */
    Purchases.setAd = function (ad) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setAd(ad);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the install keyword for the user
     *
     * @param keyword Empty String or null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting the keyword.
     */
    Purchases.setKeyword = function (keyword) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setKeyword(keyword);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Subscriber attribute associated with the install ad creative for the user
     *
     * @param creative Empty String or null will delete the subscriber attribute.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
     * setting the creative subscriber attribute.
     */
    Purchases.setCreative = function (creative) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.setCreative(creative);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Sets conversion data from AppsFlyer's onInstallConversionData callback. This extracts the
     * relevant attribution fields from the AppsFlyer conversion data and sets the corresponding
     * RevenueCat subscriber attributes ($mediaSource, $campaign, $adGroup, $ad, $keyword, $creative).
     * Note that this method will never unset any attributes.
     *
     * Pass the object received in AppsFlyer's onInstallConversionData listener directly; the nested
     * `data` field holds the conversion data that is forwarded to RevenueCat. The data is only
     * forwarded when `status` is `"success"`; otherwise it is ignored.
     *
     * @param conversionData The object from AppsFlyer's onInstallConversionData callback.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet.
     */
    Purchases.setAppsFlyerConversionData = function (conversionData) {
        return __awaiter(this, void 0, void 0, function () {
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _b.sent();
                        if ((conversionData === null || conversionData === void 0 ? void 0 : conversionData.status) !== 'success') {
                            // tslint:disable-next-line:no-console
                            console.warn("[RevenueCat] Ignoring AppsFlyer conversion data with status \"".concat(conversionData === null || conversionData === void 0 ? void 0 : conversionData.status, "\". ") +
                                "Conversion data is only forwarded when status is \"success\".");
                            return [2 /*return*/];
                        }
                        RNPurchases.setAppsFlyerConversionData((_a = conversionData.data) !== null && _a !== void 0 ? _a : null);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Overrides the preferred UI locale used by RevenueCat UI components.
     * Pass null to clear the override and use the device's locale.
     *
     * @param locale A BCP 47 locale identifier (e.g., "en-US") or null to clear.
     * @returns {Promise<void>}
     */
    Purchases.overridePreferredLocale = function (locale) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.overridePreferredLocale(locale);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Check if billing is supported for the current user (meaning IN-APP purchases are supported)
     * and optionally, whether a list of specified feature types are supported.
     *
     * Note: Billing features are only relevant to Google Play Android users.
     * For other stores and platforms, billing features won't be checked.
     *
     * @param features An array of feature types to check for support. Feature types must be one of
     *       [BILLING_FEATURE]. By default, is an empty list and no specific feature support will be checked.
     * @returns {Promise<boolean>} promise with boolean response. True if billing is supported, false otherwise.
     */
    Purchases.canMakePayments = function (features) {
        if (features === void 0) { features = []; }
        if (!RNPurchases) {
            // Native module not available, so payments cannot be made
            return Promise.resolve(false);
        }
        return RNPurchases.canMakePayments(features);
    };
    /**
     * iOS 15+ only. Presents a refund request sheet in the current window scene for
     * the latest transaction associated with the active entitlement.
     *
     * If the request was unsuccessful, no active entitlements could be found for
     * the user, or multiple active entitlements were found for the user,
     * the promise will return an error.
     * If called in an unsupported platform (Android or iOS < 15), an `UnsupportedPlatformException` will be thrown.
     *
     * Important: This method should only be used if your user can only have a single active entitlement at a given time.
     * If a user could have more than one entitlement at a time, use `beginRefundRequestForEntitlement` instead.
     *
     * @returns {Promise<REFUND_REQUEST_STATUS>} Returns REFUND_REQUEST_STATUS: The status of the
     *  refund request. Keep in mind the status could be REFUND_REQUEST_STATUS.USER_CANCELLED
     */
    Purchases.beginRefundRequestForActiveEntitlement = function () {
        return __awaiter(this, void 0, void 0, function () {
            var refundRequestStatusInt;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, Purchases.throwIfAndroidPlatform()];
                    case 2:
                        _a.sent();
                        return [4 /*yield*/, RNPurchases.beginRefundRequestForActiveEntitlement()];
                    case 3:
                        refundRequestStatusInt = _a.sent();
                        if (refundRequestStatusInt == null) {
                            throw new purchases_typescript_internal_1.UnsupportedPlatformError();
                        }
                        return [2 /*return*/, Purchases.convertIntToRefundRequestStatus(refundRequestStatusInt)];
                }
            });
        });
    };
    /**
     * iOS 15+ only. Presents a refund request sheet in the current window scene for
     * the latest transaction associated with the `entitlement`.
     *
     * If the request was unsuccessful, the promise will return an error.
     * If called in an unsupported platform (Android or iOS < 15), an `UnsupportedPlatformException` will be thrown.
     *
     * @param entitlementInfo The entitlement to begin a refund request for.
     * @returns {Promise<REFUND_REQUEST_STATUS>} Returns REFUND_REQUEST_STATUS: The status of the
     *  refund request. Keep in mind the status could be REFUND_REQUEST_STATUS.USER_CANCELLED
     */
    Purchases.beginRefundRequestForEntitlement = function (entitlementInfo) {
        return __awaiter(this, void 0, void 0, function () {
            var refundRequestStatusInt;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, Purchases.throwIfAndroidPlatform()];
                    case 2:
                        _a.sent();
                        return [4 /*yield*/, RNPurchases.beginRefundRequestForEntitlementId(entitlementInfo.identifier)];
                    case 3:
                        refundRequestStatusInt = _a.sent();
                        if (refundRequestStatusInt == null) {
                            throw new purchases_typescript_internal_1.UnsupportedPlatformError();
                        }
                        return [2 /*return*/, Purchases.convertIntToRefundRequestStatus(refundRequestStatusInt)];
                }
            });
        });
    };
    /**
     * iOS 15+ only. Presents a refund request sheet in the current window scene for
     * the latest transaction associated with the `product`.
     *
     * If the request was unsuccessful, the promise will return an error.
     * If called in an unsupported platform (Android or iOS < 15), an `UnsupportedPlatformException` will be thrown.
     *
     * @param storeProduct The StoreProduct to begin a refund request for.
     * @returns {Promise<REFUND_REQUEST_STATUS>} Returns a REFUND_REQUEST_STATUS: The status of the
     *  refund request. Keep in mind the status could be REFUND_REQUEST_STATUS.USER_CANCELLED
     */
    Purchases.beginRefundRequestForProduct = function (storeProduct) {
        return __awaiter(this, void 0, void 0, function () {
            var refundRequestStatusInt;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, Purchases.throwIfAndroidPlatform()];
                    case 2:
                        _a.sent();
                        return [4 /*yield*/, RNPurchases.beginRefundRequestForProductId(storeProduct.identifier)];
                    case 3:
                        refundRequestStatusInt = _a.sent();
                        if (refundRequestStatusInt == null) {
                            throw new purchases_typescript_internal_1.UnsupportedPlatformError();
                        }
                        return [2 /*return*/, Purchases.convertIntToRefundRequestStatus(refundRequestStatusInt)];
                }
            });
        });
    };
    /**
     * Presents the App Store sheet for managing subscriptions. Only available in iOS 13+ devices.
     */
    Purchases.showManageSubscriptions = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, Purchases.throwIfAndroidPlatform()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/, RNPurchases.showManageSubscriptions()];
                }
            });
        });
    };
    /**
     * Shows in-app messages available from the App Store or Google Play. You need to disable messages from showing
     * automatically using [PurchasesConfiguration.shouldShowInAppMessagesAutomatically].
     *
     * Note: In iOS, this requires version 16+. In older versions the promise will be resolved successfully
     * immediately.
     *
     * @param messageTypes An array of message types that the stores can display inside your app. Must be one of
     *       [IN_APP_MESSAGE_TYPE]. By default, is undefined and all message types will be shown.
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet.
     */
    Purchases.showInAppMessages = function (messageTypes) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, RNPurchases.showInAppMessages(messageTypes)];
                }
            });
        });
    };
    /**
     * Parses the given URL into a [WebPurchaseRedemption] object that can be used to redeem web purchases
     * @param urlString The Redemption Link URL as a string
     * @returns {Promise<WebPurchaseRedemption>} A WebPurchaseRedemption object that can be used to redeem the link using [redeemWebPurchase].
     */
    Purchases.parseAsWebPurchaseRedemption = function (urlString) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, RNPurchases.isWebPurchaseRedemptionURL(urlString)];
                    case 1:
                        if (_a.sent()) {
                            return [2 /*return*/, { redemptionLink: urlString }];
                        }
                        return [2 /*return*/, null];
                }
            });
        });
    };
    /**
     * Redeems the web purchase associated with the Redemption Link obtained with [parseAsWebPurchaseRedemption].
     * @param webPurchaseRedemption The WebPurchaseRedemption object obtained from [parseAsWebPurchaseRedemption].
     * @returns {Promise<WebPurchaseRedemptionResult>} The result of the redemption process. Can throw if an invalid
     * WebPurchaseRedemption parameter is passed or Purchases is not configured.
     */
    Purchases.redeemWebPurchase = function (webPurchaseRedemption) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, RNPurchases.redeemWebPurchase(webPurchaseRedemption.redemptionLink)];
                }
            });
        });
    };
    /**
     * Fetches the virtual currencies for the current subscriber.
     *
     * @returns {Promise<PurchasesVirtualCurrencies>} A PurchasesVirtualCurrencies object containing the subscriber's virtual currencies.
     * The promise will be rejected if configure has not been called yet or if an error occurs.
     */
    Purchases.getVirtualCurrencies = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, RNPurchases.getVirtualCurrencies()];
                }
            });
        });
    };
    /**
     * Invalidates the cache for virtual currencies.
     *
     * This is useful for cases where a virtual currency's balance might have been updated
     * outside of the app, like if you decreased a user's balance from the user spending a virtual currency,
     * or if you increased the balance from your backend using the server APIs.
     *
     * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or there's an error
     * invalidating the virtual currencies cache.
     */
    Purchases.invalidateVirtualCurrenciesCache = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.invalidateVirtualCurrenciesCache();
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * The currently cached [PurchasesVirtualCurrencies] if one is available.
     * This value will remain null until virtual currencies have been fetched at
     * least once with [Purchases.getVirtualCurrencies] or an equivalent function.
     *
     * @returns {Promise<PurchasesVirtualCurrencies | null>} The currently cached virtual currencies for the current subscriber.
     * The promise will be rejected if configure has not been called yet or there's an error.
     */
    Purchases.getCachedVirtualCurrencies = function () {
        return __awaiter(this, void 0, void 0, function () {
            var result;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, RNPurchases.getCachedVirtualCurrencies()];
                    case 2:
                        result = _a.sent();
                        return [2 /*return*/, result !== null && result !== void 0 ? result : null];
                }
            });
        });
    };
    /**
     * Check if configure has finished and Purchases has been configured.
     *
     * @returns {Promise<Boolean>} promise with boolean response
     */
    Purchases.isConfigured = function () {
        if (!RNPurchases) {
            // Native module not available, so SDK cannot be configured
            // tslint:disable-next-line:no-console
            console.warn("[RevenueCat] isConfigured() returning false: Native module not available");
            return Promise.resolve(false);
        }
        return RNPurchases.isConfigured();
    };
    Object.defineProperty(Purchases, "adTracker", {
        /**
         * Provides access to ad lifecycle tracking methods.
         */
        get: function () {
            if (!adTrackerSingleton) {
                adTrackerSingleton = new PurchasesAdTracker();
            }
            return adTrackerSingleton;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * Tracks an impression of a custom (non-RevenueCat) paywall.
     * Call this method when your custom paywall is displayed to a user.
     * This enables RevenueCat to track paywall impressions for analytics.
     *
     * @param params - Optional parameters for the impression event.
     * @param params.paywallId - Optional identifier for the custom paywall being shown.
     * @param params.offering - Optional offering associated with the custom paywall.
     * @param params.offeringId - Deprecated. Prefer passing `offering` when available.
     *   Optional identifier for the offering associated with the custom paywall. If not provided,
     *   the SDK will use the current offering identifier from the cache.
     */
    Purchases.trackCustomPaywallImpression = function (params) {
        return __awaiter(this, void 0, void 0, function () {
            var options, presentedOfferingContext, offeringId;
            var _a, _b, _c, _d, _e, _f;
            return __generator(this, function (_g) {
                switch (_g.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _g.sent();
                        options = params !== null && params !== void 0 ? params : {};
                        presentedOfferingContext = (_c = (_b = (_a = options.offering) === null || _a === void 0 ? void 0 : _a.availablePackages) === null || _b === void 0 ? void 0 : _b[0]) === null || _c === void 0 ? void 0 : _c.presentedOfferingContext;
                        offeringId = (_e = (_d = options.offering) === null || _d === void 0 ? void 0 : _d.identifier) !== null && _e !== void 0 ? _e : options.offeringId;
                        RNPurchases.trackCustomPaywallImpression({
                            paywallId: (_f = options.paywallId) !== null && _f !== void 0 ? _f : null,
                            offeringId: offeringId !== null && offeringId !== void 0 ? offeringId : null,
                            presentedOfferingContext: presentedOfferingContext !== null && presentedOfferingContext !== void 0 ? presentedOfferingContext : null,
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Generates a reward verification token for a rewarded ad impression.
     *
     * Pass the returned `clientTransactionId` to the ad network as the
     * server-side verification custom data. After the ad completes, pass the same
     * id to {@link Purchases.pollRewardVerification} to await the reward.
     *
     * @param impressionId - The impression identifier of the rewarded ad.
     * @returns {Promise<RewardVerificationToken>} promise with the generated token.
     */
    Purchases.generateRewardVerificationToken = function (impressionId) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, RNPurchases.generateRewardVerificationToken(impressionId)];
                }
            });
        });
    };
    /**
     * Polls RevenueCat for the reward verification result of a rewarded ad.
     *
     * The returned promise stays pending while the native poller runs (up to
     * ~10-30s) and resolves once verification completes or times out. A timed-out
     * or rejected verification resolves with `failed: true` rather than rejecting.
     *
     * @param clientTransactionId - The `clientTransactionId` from
     *   {@link Purchases.generateRewardVerificationToken}.
     * @param trackingMetadata - Pass to have the SDK automatically track
     *   reward-verification events for the ad it belongs to; omit to poll
     *   without tracking.
     * @returns {Promise<RewardVerificationResult>} promise with the verification result.
     */
    Purchases.pollRewardVerification = function (clientTransactionId, trackingMetadata) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, RNPurchases.pollRewardVerification(clientTransactionId, trackingMetadata)];
                }
            });
        });
    };
    Purchases.throwIfAndroidPlatform = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                if (react_native_2.Platform.OS === "android") {
                    throw new purchases_typescript_internal_1.UnsupportedPlatformError();
                }
                return [2 /*return*/];
            });
        });
    };
    Purchases.throwIfIOSPlatform = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                if (react_native_2.Platform.OS === "ios") {
                    throw new purchases_typescript_internal_1.UnsupportedPlatformError();
                }
                return [2 /*return*/];
            });
        });
    };
    Purchases.isPurchasesAreCompletedByMyApp = function (obj) {
        return (typeof obj === "object" &&
            obj !== null &&
            obj.type ===
                purchases_typescript_internal_1.PURCHASES_ARE_COMPLETED_BY_TYPE.MY_APP);
    };
    Purchases.convertIntToRefundRequestStatus = function (refundRequestStatusInt) {
        switch (refundRequestStatusInt) {
            case 0:
                return purchases_typescript_internal_1.REFUND_REQUEST_STATUS.SUCCESS;
            case 1:
                return purchases_typescript_internal_1.REFUND_REQUEST_STATUS.USER_CANCELLED;
            default:
                return purchases_typescript_internal_1.REFUND_REQUEST_STATUS.ERROR;
        }
    };
    /**
     * Supported SKU types.
     * @readonly
     * @enum {string}
     * @deprecated, use PRODUCT_CATEGORY
     */
    Purchases.PURCHASE_TYPE = purchases_typescript_internal_1.PURCHASE_TYPE;
    /**
     * Supported product categories.
     * @readonly
     * @enum {string}
     */
    Purchases.PRODUCT_CATEGORY = purchases_typescript_internal_1.PRODUCT_CATEGORY;
    /**
     * Enum for billing features.
     * Currently, these are only relevant for Google Play Android users:
     * https://developer.android.com/reference/com/android/billingclient/api/BillingClient.FeatureType
     * @readonly
     * @enum {string}
     */
    Purchases.BILLING_FEATURE = purchases_typescript_internal_1.BILLING_FEATURE;
    /**
     * Enum with possible return states for beginning refund request.
     * @readonly
     * @enum {string}
     */
    Purchases.REFUND_REQUEST_STATUS = purchases_typescript_internal_1.REFUND_REQUEST_STATUS;
    /**
     * Replace SKU's ProrationMode.
     * @readonly
     * @enum {number}
     * @deprecated, use STORE_REPLACEMENT_MODE
     */
    Purchases.PRORATION_MODE = purchases_typescript_internal_1.PRORATION_MODE;
    /**
     * Replacement modes for use when changing products.
     * @readonly
     * @enum {string}
     */
    Purchases.STORE_REPLACEMENT_MODE = purchases_typescript_internal_1.STORE_REPLACEMENT_MODE;
    /**
     * Enumeration of all possible Package types.
     * @readonly
     * @enum {string}
     */
    Purchases.PACKAGE_TYPE = purchases_typescript_internal_1.PACKAGE_TYPE;
    /**
     * Enum of billing plan types for subscriptions with billing plans on iOS.
     * @readonly
     * @enum {string}
     */
    Purchases.BILLING_PLAN_TYPE = purchases_typescript_internal_1.BILLING_PLAN_TYPE;
    /**
     * Enum of different possible states for intro price eligibility status.
     * @readonly
     * @enum {number}
     */
    Purchases.INTRO_ELIGIBILITY_STATUS = purchases_typescript_internal_1.INTRO_ELIGIBILITY_STATUS;
    /**
     * Enum of all error codes the SDK produces.
     * @readonly
     * @enum {string}
     */
    Purchases.PURCHASES_ERROR_CODE = purchases_typescript_internal_1.PURCHASES_ERROR_CODE;
    /**
     * List of valid log levels.
     * @readonly
     * @enum {string}
     */
    Purchases.LOG_LEVEL = purchases_typescript_internal_1.LOG_LEVEL;
    /**
     * List of valid in app message types.
     * @readonly
     * @enum {number}
     */
    Purchases.IN_APP_MESSAGE_TYPE = purchases_typescript_internal_1.IN_APP_MESSAGE_TYPE;
    /**
     * Enum of entitlement verification modes.
     * @readonly
     * @enum {string}
     */
    Purchases.ENTITLEMENT_VERIFICATION_MODE = purchases_typescript_internal_1.ENTITLEMENT_VERIFICATION_MODE;
    /**
     * The result of the verification process.
     * @readonly
     * @enum {string}
     */
    Purchases.VERIFICATION_RESULT = purchases_typescript_internal_1.VERIFICATION_RESULT;
    /**
     * Enum of StoreKit version.
     * @readonly
     * @enum {string}
     */
    Purchases.STOREKIT_VERSION = purchases_typescript_internal_1.STOREKIT_VERSION;
    /**
     * Enum of PurchasesAreCompletedByType.
     * @readonly
     * @enum {string}
     */
    Purchases.PURCHASES_ARE_COMPLETED_BY_TYPE = purchases_typescript_internal_1.PURCHASES_ARE_COMPLETED_BY_TYPE;
    Purchases.UninitializedPurchasesError = purchases_typescript_internal_1.UninitializedPurchasesError;
    Purchases.UnsupportedPlatformError = purchases_typescript_internal_1.UnsupportedPlatformError;
    return Purchases;
}());
exports.default = Purchases;
var adTrackerSingleton;
/**
 * Provides methods for tracking ad lifecycle events.
 * Access via {@link Purchases.adTracker}.
 */
var PurchasesAdTracker = /** @class */ (function () {
    function PurchasesAdTracker() {
    }
    PurchasesAdTracker.prototype.trackAdDisplayed = function (data) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.trackAdDisplayed(data);
                        return [2 /*return*/];
                }
            });
        });
    };
    PurchasesAdTracker.prototype.trackAdOpened = function (data) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.trackAdOpened(data);
                        return [2 /*return*/];
                }
            });
        });
    };
    PurchasesAdTracker.prototype.trackAdLoaded = function (data) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.trackAdLoaded(data);
                        return [2 /*return*/];
                }
            });
        });
    };
    PurchasesAdTracker.prototype.trackAdRevenue = function (data) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.trackAdRevenue(data);
                        return [2 /*return*/];
                }
            });
        });
    };
    PurchasesAdTracker.prototype.trackAdFailedToLoad = function (data) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.trackAdFailedToLoad(data);
                        return [2 /*return*/];
                }
            });
        });
    };
    PurchasesAdTracker.prototype.trackAdRewardEarnedUnverified = function (data) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.trackAdRewardEarnedUnverified(data);
                        return [2 /*return*/];
                }
            });
        });
    };
    PurchasesAdTracker.prototype.trackRewardedAdPromptShown = function (data) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.trackRewardedAdPromptShown(data);
                        return [2 /*return*/];
                }
            });
        });
    };
    PurchasesAdTracker.prototype.trackRewardedAdPromptAccepted = function (data) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, throwIfNotConfigured()];
                    case 1:
                        _a.sent();
                        RNPurchases.trackRewardedAdPromptAccepted(data);
                        return [2 /*return*/];
                }
            });
        });
    };
    return PurchasesAdTracker;
}());
exports.PurchasesAdTracker = PurchasesAdTracker;
