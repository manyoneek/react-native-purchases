#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
variant="${1:-before}"
export LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8
cp package.current.json app/package.json
cp App.before.tsx app/App.tsx
(cd app && npm install --legacy-peer-deps --ignore-scripts)
if [ "$variant" = fixed ]; then
 cp fixes/RNPurchases.fixed.m app/node_modules/react-native-purchases/ios/RNPurchases.m
 cp fixes/purchases.fixed.js app/node_modules/react-native-purchases/dist/purchases.js
fi
(cd app/ios && pod install)
(cd app && FORCE_BUNDLING=1 xcodebuild test -workspace ios/RCBugReporter.xcworkspace -scheme QAReproduction -configuration Debug -destination "platform=iOS Simulator,id=${QA_SIMULATOR:?Set QA_SIMULATOR}" -derivedDataPath ../derived -resultBundlePath "../results-$variant.xcresult" -parallel-testing-enabled NO CODE_SIGNING_ALLOWED=NO)
