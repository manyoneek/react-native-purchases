import XCTest
final class ReproductionTests: XCTestCase {
    let app = XCUIApplication()
    override func setUpWithError() throws { continueAfterFailure = false }
    func run(_ mode: String, name: String) -> String {
        app.launch()
        XCTAssertTrue(app.buttons[mode].waitForExistence(timeout: 40))
        app.buttons[mode].tap()
        XCTAssertTrue(app.staticTexts["Run complete"].waitForExistence(timeout: 80), app.debugDescription)
        let output = app.staticTexts["qa-output"].label
        print("QA_OUTPUT \(name): \(output)")
        print("QA_TREE \(name): \(app.debugDescription)")
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name; attachment.lifetime = .keepAlways; add(attachment)
        Thread.sleep(forTimeInterval: 4)
        return app.debugDescription
    }
    func testOnlineControl() {
        let tree = run("Online control", name: "online-control")
        XCTAssertTrue(tree.contains("Customer info: success"))
        XCTAssertTrue(tree.contains("getOfferings: success"))
        XCTAssertTrue(tree.contains("getCurrentOfferingForPlacement: RESOLVED default"))
        XCTAssertFalse(tree.contains("SETUP FAILED"))
    }
    func testNoOffering() {
        let tree = run("No offering case", name: "no-offering")
        XCTAssertTrue(tree.contains("Customer info: success"))
        XCTAssertTrue(tree.contains("getOfferings: success"))
        XCTAssertTrue(tree.contains("Strict null: true"))
        XCTAssertTrue(tree.contains("Null-guarded consumer: No offering"))
        XCTAssertFalse(tree.contains("consumer THREW"))
    }
    func testNetworkError() {
        let tree = run("Network error case", name: "network-error")
        XCTAssertTrue(tree.contains("getOfferings: REJECTED code=33"))
        // This is the contract assertion: it must fail on the affected SDK.
        XCTAssertTrue(tree.contains("getCurrentOfferingForPlacement: REJECTED code=33"))
        XCTAssertFalse(tree.contains("FAIL: native error"))
    }
}
