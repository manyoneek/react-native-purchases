# Current reproduction source

RevenueCat/react-native-purchases at `c656a4274c6203c1c7d73c7a345307d2c1966a64`. App/client verification performed on October 20, 2026 against this upstream revision and its current pinned SDK dependencies.

Run `bash build-and-run.sh before` and `bash build-and-run.sh fixed` from separate extracted copies. See the linked issue for expected results and reproduction steps. Replace `test_REPLACE_WITH_YOUR_PUBLIC_TEST_STORE_KEY` in the configuration with your dedicated public Test Store SDK key. Native runs require Xcode 27, CocoaPods (except Capacitor/SPM) and a booted iOS simulator; set `QA_SIMULATOR` to its UDID. 
