#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
variant="${1:-before}"
export LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8
cp package.current.json app/package.json
cp App.before.tsx app/App.tsx
(cd app && npm install --legacy-peer-deps --ignore-scripts)
cp ReproductionTests.before.swift app/ios/RCBugReporterUITests/ReproductionTests.swift
if [ "$variant" = fixed ]; then
 (cd app/node_modules/react-native-purchases-ui && patch -p2 < ../../../fixes/ui.patch)
 cp fixes/index.fixed.d.ts app/node_modules/react-native-purchases-ui/lib/typescript/src/index.d.ts
 cp fixes/App.fixed.tsx app/App.tsx
 cp fixes/ReproductionTests.fixed.swift app/ios/RCBugReporterUITests/ReproductionTests.swift
fi
(cd app/ios && pod install)
(cd app && FORCE_BUNDLING=1 xcodebuild test -workspace ios/RCBugReporter.xcworkspace -scheme QAReproduction -configuration Debug -destination "platform=iOS Simulator,id=${QA_SIMULATOR:?Set QA_SIMULATOR}" -derivedDataPath ../derived -resultBundlePath "../results-$variant.xcresult" -parallel-testing-enabled NO CODE_SIGNING_ALLOWED=NO)
