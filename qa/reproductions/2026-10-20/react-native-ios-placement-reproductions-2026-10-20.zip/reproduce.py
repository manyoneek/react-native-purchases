#!/usr/bin/env python3
"""Build and test the actual iOS SDK. No response fixtures or callback injection."""
import pathlib,subprocess,os,json,argparse,shutil,datetime
root=pathlib.Path(__file__).resolve().parent;app=root/'app'
p=argparse.ArgumentParser();p.add_argument('stage',choices=['before','native-fixed','fixed']);p.add_argument('--simulator');p.add_argument('--developer-dir');args=p.parse_args()
env=os.environ.copy();env['FORCE_BUNDLING']='1';env['CI']='true'
if args.developer_dir:env['DEVELOPER_DIR']=args.developer_dir
out=root/'reproduction-output'/(args.stage+'-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'));out.mkdir(parents=True)
results=[]
def run(name,cmd,cwd=app,allow_failure=False):
 with (out/(name+'.log')).open('w') as log:
  proc=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=cmd,exit=proc.returncode));(out/'commands.json').write_text(json.dumps(results,indent=2))
 if proc.returncode and not allow_failure:raise RuntimeError(name+' failed; see '+str(out))
 return proc.returncode
run('npm',['npm','ci','--legacy-peer-deps','--ignore-scripts'])
sdk=app/'node_modules/react-native-purchases'
if args.stage in ['native-fixed','fixed']:
 run('native-patch',['patch','-p1','-N','-i',str(root/'fixes/native-error.patch')],sdk)
 assert 'completionBlock:[self getResponseCompletionBlockWithResolve:resolve' in (sdk/'ios/RNPurchases.m').read_text().split('RCT_EXPORT_METHOD(getCurrentOfferingForPlacement:')[1].split('//syncAttributes')[0]
if args.stage=='fixed':shutil.copy2(root/'fixes/purchases.fixed.js',sdk/'dist/purchases.js')
run('pods',['pod','install'],app/'ios')
if args.simulator:sim=args.simulator
else:
 devices=json.loads(subprocess.check_output(['xcrun','simctl','list','devices','available','-j'],env=env,text=True))['devices']
 ios=[d for runtime,values in devices.items() if '.iOS-' in runtime for d in values]
 if not ios:raise RuntimeError('Install an iOS simulator runtime first')
 sim=next((d['udid'] for d in ios if d['state']=='Booted'),ios[0]['udid'])
 subprocess.run(['xcrun','simctl','boot',sim],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
run('boot',['xcrun','simctl','bootstatus',sim,'-b'])
base=['xcodebuild','-workspace','ios/RCBugReporter.xcworkspace','-scheme','QAReproduction','-configuration','Debug','-destination','platform=iOS Simulator,id='+sim,'-derivedDataPath',str(root/'reproduction-output/derived'),'CODE_SIGNING_ALLOWED=NO']
run('build',base+['build-for-testing'])
code=run('tests',base+['test-without-building','-parallel-testing-enabled','NO','-resultBundlePath',str(out/'results.xcresult')],allow_failure=True)
run('screenshots',['xcrun','xcresulttool','export','attachments','--path',str(out/'results.xcresult'),'--output-path',str(out/'attachments')],allow_failure=True)
print('Test exit:',code,'Expected:',65 if args.stage!='fixed' else 0,'Logs:',out)
raise SystemExit(code)
