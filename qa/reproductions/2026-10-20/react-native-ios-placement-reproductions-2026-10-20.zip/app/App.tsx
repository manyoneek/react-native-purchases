import React, {useState, useEffect} from 'react';
import {SafeAreaView, Text, Button, StyleSheet, LogBox, View} from 'react-native';
import Purchases from 'react-native-purchases';
import config from './qa-config.json';
LogBox.ignoreAllLogs(true);
export default function App() {
  const [lines, setLines] = useState<string[]>([]);
  const [started, setStarted] = useState(false);
  const [done, setDone] = useState(false);
  const [tick, setTick] = useState(0);
  useEffect(() => { const timer = setInterval(() => setTick(x => x + 1), 500); return () => clearInterval(timer); }, []);
  const log = (s: string) => { console.log('[QA]', s); setLines(v => [...v, s]); };
  async function run(mode: 'offline' | 'online' | 'none') {
    const offline = mode === 'offline';
    setStarted(true);
    try {
      log(offline ? 'NETWORK ERROR CASE' : mode === 'none' ? 'NO OFFERING CASE' : 'ONLINE CONTROL');
      if (offline) {
        // A closed local port produces a real URLSession connection failure.
        // There is no proxy server, response fixture, or mocked SDK transport.
        await Purchases.setProxyURL('http://127.0.0.1:1');
      }
      Purchases.configure({apiKey: config.apiKey, appUserID: `bug-reporter-placement-${offline ? 'offline' : 'online'}-${Date.now()}`});
      log(`Configured: ${await Purchases.isConfigured()}`);
      if (!offline) {
        await Purchases.getCustomerInfo();
        log('Customer info: success (synthetic Test Store user)');
      }
      try {
        const offerings = await Purchases.getOfferings();
        log(`getOfferings: success (${Object.keys(offerings.all).length} offerings)`);
      } catch (e: any) { log(`getOfferings: REJECTED code=${e.code}`); log(`Native error: ${e.readableErrorCode || e.message}`); }
      try {
        const offering = await Purchases.getCurrentOfferingForPlacement(mode === 'none' ? 'sdk_bug_reporter_none_20261018' : 'qa_network_error_control');
        log(`getCurrentOfferingForPlacement: RESOLVED ${offering == null ? String(offering) : offering.identifier}`);
        if (offline) log('FAIL: native error was swallowed');
        if (mode === 'none') {
          log(`Strict null: ${offering === null} (expected true)`);
          try {
            const label = offering !== null ? offering.identifier : 'No offering';
            log(`Null-guarded consumer: ${label}`);
          } catch (e) { log(`Null-guarded consumer THREW: ${String(e)}`); }
        }
      } catch (e: any) {
        log(`getCurrentOfferingForPlacement: REJECTED code=${e.code}`);
        if (offline) log('PASS: native error reaches the caller');
      }
    } catch(e) { log(`SETUP FAILED: ${String(e)}`); }
    setDone(true);
  }
  return <SafeAreaView style={s.root}>
    <Text style={s.title}>Placement error propagation</Text>
    <Text style={s.sub}>React Native Purchases 10.15.0 · iOS</Text>
    <Text style={s.sub}>SDK Bug Reporter · synthetic Test Store only</Text>
    {!started && <View style={s.buttons}>
      <Button title="Online control" onPress={()=>run('online')}/>
      <Button title="No offering case" onPress={()=>run('none')}/>
      <Button title="Network error case" onPress={()=>run('offline')}/>
    </View>}
    <Text style={s.log} testID="qa-output">{lines.join('\n\n')}</Text>
    {done && <Text style={s.done}>Run complete</Text>}
    <Text style={s.sub}>Live capture · {(tick / 2).toFixed(1)}s</Text>
    <Text style={s.footer}>Offline case: real connection refusal at a closed localhost port. No mocked responses. No purchases.</Text>
  </SafeAreaView>;
}
const s=StyleSheet.create({root:{flex:1,backgroundColor:'#101523',padding:22},title:{color:'white',fontSize:25,fontWeight:'700',marginTop:20},sub:{color:'#afc1e5',fontSize:13,marginTop:8},buttons:{marginTop:24},log:{color:'white',fontFamily:'Menlo',fontSize:14,lineHeight:21,marginTop:24},done:{color:'#ffd77d',fontWeight:'700',fontSize:20,marginTop:20},footer:{color:'#afc1e5',fontSize:13,marginTop:22}});
