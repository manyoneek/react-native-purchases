#import <Foundation/Foundation.h>
@interface Bridge : NSObject
@property NSArray *args;
- (void)enqueueCallback:(id)json args:(NSArray *)args;
@end
@implementation Bridge
- (void)enqueueCallback:(id)json args:(NSArray *)args {self.args=args;}
@end
#define BLOCK_CASE(ARGS, BODY) void (^resolve) ARGS = ^ ARGS BODY
int main(){@autoreleasepool{Bridge *bridge=[Bridge new];id json=@1;
BLOCK_CASE((id result), { [bridge enqueueCallback:json args:result ? @[ result ] : @[]]; });
resolve(nil);NSArray *nilArgs=bridge.args;resolve([NSNull null]);NSArray *nullArgs=bridge.args;
NSData *data=[NSJSONSerialization dataWithJSONObject:@{@"nil":nilArgs,@"NSNull":nullArgs} options:0 error:nil];puts([[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding].UTF8String);
}}
