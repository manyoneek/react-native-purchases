public static async getCurrentOfferingForPlacement(
    placementIdentifier: string
  ): Promise<PurchasesOffering | null> {
    await throwIfNotConfigured();
    return RNPurchases.getCurrentOfferingForPlacement(placementIdentifier);
  }