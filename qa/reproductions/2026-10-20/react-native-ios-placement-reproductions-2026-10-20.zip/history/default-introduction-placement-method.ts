public static async getCurrentOfferingForPlacement(
    placementIdentifier: string
  ): Promise<PurchasesOffering | null> {
    await Purchases.throwIfNotConfigured();
    return RNPurchases.getCurrentOfferingForPlacement(placementIdentifier);
  }