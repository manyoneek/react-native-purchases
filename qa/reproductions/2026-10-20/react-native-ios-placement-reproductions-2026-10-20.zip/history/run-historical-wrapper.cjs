const fs = require('fs');
const ts = require(process.argv[2]);
const method=fs.readFileSync(process.argv[3],'utf8');
const args=JSON.parse(fs.readFileSync(process.argv[4],'utf8'));
const source=`let nativeValue;
const RNPurchases={getCurrentOfferingForPlacement:async()=>nativeValue};
async function throwIfNotConfigured() {}
class Purchases {static async throwIfNotConfigured() {} ${method}}
(async()=>{const rows=[];
for(const [name,wireArgs] of Object.entries(${JSON.stringify(args)})) {
 nativeValue=await new Promise(resolve=>resolve(...wireArgs));
 const value=await Purchases.getCurrentOfferingForPlacement('qa');
 rows.push({name,actual:String(value),strictNull:value===null,expected:'null'});
}
console.log(JSON.stringify(rows,null,2));})();`;
eval(ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2020,module:ts.ModuleKind.CommonJS}}).outputText);
