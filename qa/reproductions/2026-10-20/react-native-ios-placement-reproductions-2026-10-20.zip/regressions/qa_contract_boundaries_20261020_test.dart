import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:purchases_flutter/purchases_flutter.dart';

// Local method-channel regression tests, not native app/backend reproduction.
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const channel = MethodChannel('purchases_flutter');
  final messenger = TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
  final calls = <MethodCall>[];
  dynamic response;
  PlatformException? failure;
  setUp(() {
    calls.clear(); response = null; failure = null;
    messenger.setMockMethodCallHandler(channel, (call) async {
      calls.add(call);
      if (failure != null) throw failure!;
      return response;
    });
  });
  tearDown(() => messenger.setMockMethodCallHandler(channel, null));
  test('No Offering remains strict null and placement id is preserved', () async {
    expect(await Purchases.getCurrentOfferingForPlacement('qa_no_offering'), isNull);
    expect(calls.single.arguments, {'placementIdentifier': 'qa_no_offering'});
  });
  test('placement errors reject instead of becoming no offering', () async {
    failure = PlatformException(code: '10', message: 'network unavailable', details: {'underlyingErrorMessage': 'connection refused'});
    await expectLater(Purchases.getCurrentOfferingForPlacement('qa'), throwsA(isA<PlatformException>().having((e) => e.code, 'code', '10')));
  });
  test('currency cache miss remains null', () async {
    expect(await Purchases.getCachedVirtualCurrencies(), isNull);
  });
  test('empty cached currencies remain a non-null success', () async {
    response = {'all': <String, dynamic>{}};
    final result = await Purchases.getCachedVirtualCurrencies();
    expect(result, isNotNull); expect(result!.all, isEmpty);
  });
  test('currency zero balance and nullable description survive conversion', () async {
    response = {'all': {'ZERO': {'balance': 0, 'name': 'Zero', 'code': 'ZERO', 'serverDescription': null}}};
    final result = await Purchases.getVirtualCurrencies();
    expect(result.all['ZERO']!.balance, 0);
    expect(result.all['ZERO']!.serverDescription, isNull);
  });
  test('currency fetch error remains an error', () async {
    failure = PlatformException(code: '10', message: 'network unavailable');
    await expectLater(Purchases.getVirtualCurrencies(), throwsA(isA<PlatformException>().having((e) => e.code, 'code', '10')));
  });
  test('empty-string attribute deletion is preserved on outgoing native channel', () async {
    await Purchases.setAttributes({'qa_removed': '', 'qa_keep': 'value'});
    expect(calls.single.arguments, {'attributes': {'qa_removed': '', 'qa_keep': 'value'}});
  });
  test('empty-string display-name deletion is preserved on outgoing native channel', () async {
    await Purchases.setDisplayName('');
    expect(calls.single.arguments, {'displayName': ''});
  });
  test('empty offerings retain null current and missing lookup', () async {
    response = {'all': <String, dynamic>{}, 'current': null};
    final offerings = await Purchases.getOfferings();
    expect(offerings.current, isNull); expect(offerings.getOffering('missing'), isNull);
  });
  test('recordPurchase uses the native productIdentifier argument and returns transaction', () async {
    response = {'productIdentifier': 'qa_product', 'transactionIdentifier': 'qa_transaction', 'purchaseDate': '2026-10-20T09:00:00Z'};
    final result = await Purchases.recordPurchase('qa_product');
    expect(calls.single.method, 'recordPurchaseForProductID');
    expect(calls.single.arguments, {'productIdentifier': 'qa_product'});
    expect(result.productIdentifier, 'qa_product');
    expect(result.transactionIdentifier, 'qa_transaction');
  });
}
