# React Native iOS placement reproductions

Affected source: RevenueCat/react-native-purchases `cd5de3d7d78ae9b8b8655b3ae2432953be72e85d` (10.15.0).
The vendored package was built from that exact checkout. It contains the original implementation, not a replacement SDK.

## Run

Requires macOS, Node >=22.11, CocoaPods and Xcode with an iOS simulator. Tested with Xcode 27.1 RC / iOS 27.1, React Native 0.87.1, Hermes/new architecture, PurchasesHybridCommon 19.12.0 and native RevenueCat 5.95.0. Simulator apps are unsigned.

```sh
python3 reproduce.py before --simulator YOUR_SIMULATOR_UDID
python3 reproduce.py native-fixed --simulator YOUR_SIMULATOR_UDID
python3 reproduce.py fixed --simulator YOUR_SIMULATOR_UDID
```

Set `DEVELOPER_DIR` or pass `--developer-dir` if Xcode is not selected. Ensure `pod` and its Ruby are on PATH. Each invocation reinstalls the original SDK from the included local package before applying the requested fixes, then builds and runs the same three XCTest cases. `before` intentionally exits 65 with two failing cases; `native-fixed` exits 65 with only the No Offering case failing; `fixed` exits 0. Logs, exact commands and screenshots are under `reproduction-output/`. Tests do not make purchases.

You can also run the `RCBugReporter` app scheme in Xcode after `npm ci --legacy-peer-deps --ignore-scripts` and `pod install`. Run one button per app launch:

- **Online control:** configure a synthetic user, get customer info, fetch real offerings, resolve an unknown placement to the existing default offering.
- **Network error case:** set the SDK's supported proxy URL to an unreachable local port before configure. `getOfferings` rejects with code 33; affected placement lookup incorrectly resolves undefined. There is no local proxy/server or mocked transport.
- **No offering case:** configure a synthetic user and fetch the real `sdk_bug_reporter_none_20261018` placement. It is explicitly set to No Offering; the affected SDK returns undefined and the documented strict-null consumer guard throws.

## Dedicated setup

Only project **SDK Bug Reporter** (`proj602cc762`), Test Store app `app4ca00b430f`, and generated synthetic users are used. The included `qa-config.json` contains that app's public Test Store SDK key, not an administrative credential. The existing default offering and No Offering targeting rule were reused without modification.

Dashboard: https://app.revenuecat.com/projects/602cc762/apps/app4ca00b430f
Existing targeting rule: https://app.revenuecat.com/projects/602cc762/targeting/tvpeenTzcQ

## Fixes and evidence

`fixes/native-error.patch` routes the placement callback through the existing native error-aware completion helper. `fixes/null-result.patch` awaits and normalizes a successful nullish result to null. `fixes/purchases.fixed.js` is the actual TypeScript compiler output from the second patch, supplied because the npm SDK package distributes compiled JS rather than its TS sources. No patch is published remotely.

The reports, before/after screenshots and videos, regression sources, exact test commands/results, dependency lockfiles and historical boundary evidence are included. Current app flows use actual native SDK code. Historical host regressions use extracted production method bodies and explicit dependency/transport shims; they are not full historical mobile app runs. Android and physical devices were not tested.
