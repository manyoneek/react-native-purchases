# Functional QA — 2026-10-20

## Inventory and scope

Refreshed all public RevenueCat GitHub repositories through the paginated public org endpoint. 77 repositories, 77 verified local clone origins, including 21 forks and 3 archives. No missing clones or inventory failures. Existing clones and prior findings were preserved; fetched default branches into detached review worktrees. Reviewed only SDK source: React Native first, then Flutter. No GitHub writes, support requests, schedule changes or production/customer interactions.

## React Native

RevenueCat/react-native-purchases `cd5de3d7d78ae9b8b8655b3ae2432953be72e85d` (10.15.0). Native/common and TypeScript dependencies pin 19.12.0. Installed with the repository-pinned Yarn 3.6.1 and immutable lockfile; TypeScript build passed before testing.

Reviewed core event dispatch/removal, native promise error normalization, getCurrentOfferingForPlacement, getOfferings, cached virtual currency null/empty behavior, iOS/Android bridge implementations, the iOS completion/rejection helpers, and pinned common-library placement/error contracts. Existing 272 core tests passed. Eight added public-method/transport regressions passed: two currency cache absence cases; empty currency success; nullable placement; rejected placement error normalization; customer-info and promoted-purchase listener self-removal; unconfigured guard.

The ninth regression, native undefined placement result -> documented null, fails on original production source. Full original suite with additions: 280 pass / 1 fail. Temporary null normalization: 281/281 pass; build passes. Source restored and rebuilt. The tests inject transport values, not implementation logic, and are not claimed as native app reproduction.

A separate Foundation host regression compiles the actual extracted Objective-C placement method and existing helpers, with a recording shared-library callback provider and dependency declarations. Original: 3 success controls pass and 3 error cases fail; temporary error-forwarding patch: 6/6 pass. Original source restored in a finally block.

Two distinct findings are confirmed by a real native iOS app:

1. The placement bridge ignores its error parameter and resolves when the native SDK errors. A real closed-localhost connection failure produces API_ENDPOINT_BLOCKED code 33 in getOfferings, but placement incorrectly resolves undefined. A native-only patch makes the placement call reject with code 33.
2. A genuine backend No Offering placement resolves undefined despite Promise<PurchasesOffering | null>; a strictly null-guarded consumer throws. This remains after the native error patch and is corrected by awaiting and null-normalizing the public method result.

The app runs React Native 0.87.1 / Hermes / new architecture, common 19.12.0 and RevenueCat iOS 5.95.0 on the iOS 27.1 simulator. It configures only the SDK Bug Reporter project proj602cc762 / Test Store app app4ca00b430f and generated synthetic users. Online controls fetch real customer info and offerings, and preserve unknown-placement fallback to default. Existing No Offering targeting rule tvpeenTzcQ and placement sdk_bug_reporter_none_20261018 were reused without changes. The error case uses the supported setProxyURL API with an unreachable local port, with no proxy server, mocked transport or injected callback. No purchases were performed.

Actual UI tests: original 1 pass / 2 fail; verified native-only fix 2 pass / 1 fail; both fixes 3/3 pass. Screenshots are XCTest attachments captured while the result was asserted. App source and scoped fix patches are packaged. Native binary/UI evidence is iOS-only; no physical device or Android execution.

## Introduction history

Both problems were present in the initial placement implementation: feature commit 91c21caea7228a4bf8cd8682d0dd5141618f11bd (PR #925), integrated into the default branch by a3d1f06386a6726a83c9cc89372b885a157c16ed (PR #938), 2024-03-13. First containing stable source tag 7.24.0, release published 2024-03-14. Both parents were checked and lack the feature.

Error regression executed the introducing Objective-C method bodies from both revisions: same 3 failing error cases / 3 passing success controls. Original feature callback declaration was NSError; the harness dependency declaration was corrected to match it, without changing the production method body.

The nullable return contract existed in both introducing TypeScript methods. Executed the actual historical React Native 0.73.5 resolve block (that default-branch revision's dev dependency) with a recording bridge: nil -> empty callback args, NSNull -> [null]. The actual historical RevenueCat public method then returns undefined or null respectively. Historical source/package metadata, method bodies, compiler command and results are retained. These are host boundary tests with declaration/provider shims, not full 2024 app builds or proof across all React Native versions.

Read-only public duplicate searches were preserved. Issue #1190 describes an Android first-use placement problem and does not establish either iOS root cause; it is retained as related context. No matching published fix was found in the bounded queries. Existing Capacitor null-placement finding is related but has a different repository/bridge/fingerprint. Prior ten finding records and their lineage are unchanged.

## Flutter

RevenueCat/purchases-flutter `63cdd85246480449b069a75c6ff37fa7506b45e3` (10.17.0); native dependency metadata pins common 19.14.0. Reviewed Dart public-method conversion, nullable offerings/current lookup, cached currency miss versus empty success, zero balances and nullable descriptions, channel errors, attribute deletion forwarding, recordPurchase productIdentifier forwarding, and listener snapshot dispatch. Existing full core suite: 193 pass. Added ten regressions: full core suite 203/203 pass. No new Flutter functional defect confirmed.

Tests execute actual public Dart implementation and model conversion with mocked method-channel transport. They do not execute the native plugin, Android/iOS runtime or real backend. Flutter static analysis exits 1 with 24 pre-existing web unawaited_return_in_try_block warnings. No web app or UI-package test coverage is claimed.

## Harness and verification limitations preserved

- Initial Flutter scaffold passed null to nonnullable Dart parameters and expected the wrong native method name. Corrected to the supported empty-string deletion inputs and recordPurchaseForProductID. Initial compile/expectation failures are preserved and are not SDK defect evidence.
- Initial app observation assumed network code 10 and attempted to dereference an unexpected undefined result. Corrected to observe the actual code 33 and return value without causing the observation itself to throw.
- An initial native fix application used git apply inside a directory whose ancestor was the workspace repository; paths were skipped. The supposed native-only-fixed attempt actually tested unchanged SDK code. Not counted as fix validation. Subsequent app source was copied from the independently tested patch result and SHA-256 verified before compilation; native-fixed-verified is the valid independent-fix run.
- Static simulator videos omitted their final unchanged result frame, despite valid XCTest screenshots. The demo now includes a live timestamp to keep display frames flowing. Final videos are the inspected live-before/live-fixed captures; early incomplete videos remain in the run directory and are excluded from delivery.
- Xcode's optional simulator diagnostic collection emits a simctl-location warning because global xcode-select remains CommandLineTools. Subprocess DEVELOPER_DIR points to Xcode 27.1 RC; all reported builds, UI assertions and screenshot exports executed. No global toolchain configuration was changed.

Reports and evidence are intended only for the existing automation's announced final in Discord channel 1559550752349884437. No direct channel sends were made.

## Final artifact verification

The separately packaged original app was installed with npm ci, resolved through CocoaPods, independently built and run: two expected failures and the online control passed (exit 65). The same portable runner applied both fixes, rebuilt and passed all three UI tests (exit 0). Final before/after recordings were recaptured with the live demo timestamp; their result frames were visually inspected and recordings compressed without cuts or speed changes. Original SDK native and JavaScript files were restored in both app dependency trees. Only focused regression tests remain untracked in review worktrees. Flutter-generated analysis_options.yaml exclusions were preserved as a patch and restored.
