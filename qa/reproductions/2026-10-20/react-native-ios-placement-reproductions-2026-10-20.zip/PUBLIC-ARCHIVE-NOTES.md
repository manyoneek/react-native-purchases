# Reproduction source and original evidence

Original capture date: 2026-10-20. Original reviewed commit: cd5de3d7d78ae9b8b8655b3ae2432953be72e85d. The recorded app/client was run before and after the suggested fix on that revision. Fresh branch-level tests are published separately; these captures were not rerun on the latest upstream revision.

Replace test_REPLACE_WITH_YOUR_PUBLIC_TEST_STORE_KEY in the client configuration with your public RevenueCat Test Store SDK key before running.
