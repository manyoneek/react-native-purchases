import pathlib,json,urllib.request,tarfile,subprocess,os,re
r=pathlib.Path(__file__).resolve().parent;h=r/'history';h.mkdir(exist_ok=True)
meta=json.load(urllib.request.urlopen('https://registry.npmjs.org/react-native/0.73.5'))
(h/'react-native-0.73.5-dist.json').write_text(json.dumps(meta['dist'],indent=2))
archive=h/'react-native-0.73.5.tgz'
if not archive.exists():urllib.request.urlretrieve(meta['dist']['tarball'],archive)
with tarfile.open(archive) as t:
 for f in ['React/Base/RCTModuleMethod.mm','Libraries/BatchedBridge/NativeModules.js']:
  (h/('react-native-0.73.5-'+pathlib.Path(f).name)).write_bytes(t.extractfile('package/'+f).read())
s=(h/'react-native-0.73.5-RCTModuleMethod.mm').read_text();pos=s.index('isEqualToString:@"RCTPromiseResolveBlock"');start=s.index('BLOCK_CASE((id result)',pos);end=s.index('\n',start);block=s[start:end]
source=r'''#import <Foundation/Foundation.h>
@interface Bridge : NSObject
@property NSArray *args;
- (void)enqueueCallback:(id)json args:(NSArray *)args;
@end
@implementation Bridge
- (void)enqueueCallback:(id)json args:(NSArray *)args {self.args=args;}
@end
#define BLOCK_CASE(ARGS, BODY) void (^resolve) ARGS = ^ ARGS BODY
int main(){@autoreleasepool{Bridge *bridge=[Bridge new];id json=@1;
'''+block+r'''
resolve(nil);NSArray *nilArgs=bridge.args;resolve([NSNull null]);NSArray *nullArgs=bridge.args;
NSData *data=[NSJSONSerialization dataWithJSONObject:@{@"nil":nilArgs,@"NSNull":nullArgs} options:0 error:nil];puts([[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding].UTF8String);
}}
'''
(h/'react-native-historical-resolver.m').write_text(source)
env=os.environ.copy();env['DEVELOPER_DIR']='/Applications/Xcode-27.1.0-release.candidate.app/Contents/Developer'
c=subprocess.run(['xcrun','clang','-fobjc-arc','-fblocks','-framework','Foundation',str(h/'react-native-historical-resolver.m'),'-o',str(h/'react-native-historical-resolver')],env=env,capture_output=True,text=True);(h/'resolver-compile.log').write_text(c.stdout+c.stderr);c.check_returncode()
result=subprocess.check_output([str(h/'react-native-historical-resolver')],text=True);(h/'react-native-resolver-arguments.json').write_text(result);print(result)
repo=r/'worktrees/react-native-purchases'
for rev,label in [('a3d1f06386a6726a83c9cc89372b885a157c16ed','default-introduction'),('91c21caea7228a4bf8cd8682d0dd5141618f11bd','feature-introduction'),('HEAD','current')]:
 s=subprocess.check_output(['git','-C',str(repo),'show',rev+':src/purchases.ts'],text=True)
 start=s.index('public static async getCurrentOfferingForPlacement(');brace=s.index('{',start);end=s.index('\n  }',brace)+4
 method=s[start:end]
 # The only substituted behavior is the transport return and configured guard.
 (h/(label+'-placement-method.ts')).write_text(method)
 program='''const fs = require('fs');
const ts = require(process.argv[2]);
const method=fs.readFileSync(process.argv[3],'utf8');
const args=JSON.parse(fs.readFileSync(process.argv[4],'utf8'));
const source=`let nativeValue;
const RNPurchases={getCurrentOfferingForPlacement:async()=>nativeValue};
async function throwIfNotConfigured() {}
class Purchases {static async throwIfNotConfigured() {} ${method}}
(async()=>{const rows=[];
for(const [name,wireArgs] of Object.entries(${JSON.stringify(args)})) {
 nativeValue=await new Promise(resolve=>resolve(...wireArgs));
 const value=await Purchases.getCurrentOfferingForPlacement('qa');
 rows.push({name,actual:String(value),strictNull:value===null,expected:'null'});
}
console.log(JSON.stringify(rows,null,2));})();`;
eval(ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2020,module:ts.ModuleKind.CommonJS}}).outputText);
'''
 (h/'run-historical-wrapper.cjs').write_text(program)
 c=subprocess.run(['node',str(h/'run-historical-wrapper.cjs'),str(repo/'node_modules/typescript'),str(h/(label+'-placement-method.ts')),str(h/'react-native-resolver-arguments.json')],capture_output=True,text=True);c.check_returncode();(h/(label+'-null-wrapper-results.json')).write_text(c.stdout);print(label,c.stdout)
