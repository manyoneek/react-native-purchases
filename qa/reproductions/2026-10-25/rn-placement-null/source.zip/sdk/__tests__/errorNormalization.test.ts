import { NativeModules } from "react-native";
import { WebPurchaseRedemptionResultType } from "@revenuecat/purchases-typescript-internal";
import type { PurchasesError } from "@revenuecat/purchases-typescript-internal";

import Purchases from "../src/purchases";

/**
 * The shape React Native builds on Android: PromiseImpl sends code, message and
 * userInfo, and RNPurchasesModule passes ErrorContainer.info as that userInfo.
 */
function nativeRejection(): Error {
  return Object.assign(new Error("There was a credentials issue."), {
    code: "11",
    message: "There was a credentials issue.",
    userInfo: {
      code: 11,
      message: "There was a credentials issue.",
      readableErrorCode: "InvalidCredentialsError",
      readable_error_code: "InvalidCredentialsError",
      underlyingErrorMessage: "Invalid API Key.",
    },
    nativeStackAndroid: [],
  });
}

describe("errors rejected by the native module", () => {
  beforeEach(() => {
    NativeModules.RNPurchases.isConfigured.mockResolvedValue(true);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it("match the PurchasesError interface", async () => {
    NativeModules.RNPurchases.getCustomerInfo.mockRejectedValueOnce(nativeRejection());

    const error: PurchasesError = await Purchases.getCustomerInfo().catch((caught: unknown) => caught);

    expect(error.code).toBe("11");
    expect(error.readableErrorCode).toBe("InvalidCredentialsError");
    expect(error.underlyingErrorMessage).toBe("Invalid API Key.");
    expect(error.userInfo.readableErrorCode).toBe("InvalidCredentialsError");
    expect(error.userCancelled).toBe(false);
  });

  it("stay real Errors", async () => {
    NativeModules.RNPurchases.getCustomerInfo.mockRejectedValueOnce(nativeRejection());

    const error = await Purchases.getCustomerInfo().catch((caught: unknown) => caught);

    expect(error).toBeInstanceOf(Error);
    expect(typeof (error as Error).stack).toBe("string");
  });

  it("keep the fields userInfo already carried", async () => {
    NativeModules.RNPurchases.getCustomerInfo.mockRejectedValueOnce(nativeRejection());

    const error: PurchasesError = await Purchases.getCustomerInfo().catch((caught: unknown) => caught);
    const userInfo = error.userInfo as Record<string, unknown>;

    expect(userInfo.underlyingErrorMessage).toBe("Invalid API Key.");
    expect(userInfo.readable_error_code).toBe("InvalidCredentialsError");
  });

  it("leave successful calls alone", async () => {
    NativeModules.RNPurchases.getCustomerInfo.mockResolvedValueOnce(global.customerInfoStub);

    await expect(Purchases.getCustomerInfo()).resolves.toBeTruthy();
  });
});

describe("errors delivered in a resolved web redemption result", () => {
  const redemption = { redemptionLink: "https://pay.rev.cat/redeem/abc" };

  beforeEach(() => {
    NativeModules.RNPurchases.isConfigured.mockResolvedValue(true);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it("match the PurchasesError interface", async () => {
    NativeModules.RNPurchases.redeemWebPurchase.mockResolvedValueOnce({
      result: "ERROR",
      error: {
        code: 1,
        message: "Purchase was cancelled.",
        readableErrorCode: "PURCHASE_CANCELLED",
        underlyingErrorMessage: "",
      },
    });

    const result = await Purchases.redeemWebPurchase(redemption);

    if (result.result !== WebPurchaseRedemptionResultType.ERROR) {
      throw new Error(`Expected an ERROR result, got ${result.result}`);
    }
    const error: PurchasesError = result.error;
    expect(error.code).toBe("1");
    expect(error.userInfo.readableErrorCode).toBe("PURCHASE_CANCELLED");
    expect(error.readableErrorCode).toBe("PURCHASE_CANCELLED");
    expect(error.message).toBe("Purchase was cancelled.");
    expect(error.userCancelled).toBe(true);
  });

  it("leave results without an error alone", async () => {
    const expired = { result: "EXPIRED", obfuscatedEmail: "a***@example.com" };
    NativeModules.RNPurchases.redeemWebPurchase.mockResolvedValueOnce(expired);

    await expect(Purchases.redeemWebPurchase(redemption)).resolves.toEqual({
      result: "EXPIRED",
      obfuscatedEmail: "a***@example.com",
    });
  });
});
