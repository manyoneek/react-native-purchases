## 10.15.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.14.1 (#2052) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.28.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.28.1)
  * [Android 10.28.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.28.0)
  * [Android 10.27.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.27.1)
  * [iOS 5.96.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.96.1)
  * [iOS 5.96.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.96.0)
  * [Web 1.71.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.71.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.14.0 (#2045) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* chore: route CODEOWNERS review requests to owning teams (#2041) via Cesar de la Vega (@vegaro)
* chore(deps): bump fastlane from 2.241.0 to 2.241.1 (#2046) via dependabot[bot] (@dependabot[bot])
* Read npm token from `npm-publishing` CircleCI context (#2044) via Álvaro Brey (@AlvaroBrey)
* Upgrade MagicWeather example to React Native 0.88 and react-native-purchases 10.14.0 (#2043) via Jens-Fabian Goetzmann (@jefago)

## 10.15.0
## RevenueCat SDK
### ✨ New Features
* feat(ads): admob adapter (#2023) via Peter Porfy (@peterporfy)

### 🔄 Other Changes
* feat(ads): use the AdMob adapter in adsTester (#2033) via Peter Porfy (@peterporfy)

## 10.14.0
## RevenueCat SDK
### ✨ New Features
* Expose unverified rewarded ad tracking (#2009) via Pol Miro (@polmiro)

### 🔄 Other Changes
* chore(deps): bump fastlane from 2.240.1 to 2.241.0 (#2036) via dependabot[bot] (@dependabot[bot])

## 10.13.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.12.0 (#2029) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Align React Native dev dependency with purchase tester (#2032) via Cesar de la Vega (@vegaro)
* chore: bump purchaseTesterTypescript to Ruby 3.3.0 (#2016) via Cesar de la Vega (@vegaro)
* other: add .purr.local.json to .gitignore (#2020) via Will Taylor (@fire-at-will)
* Run Maestro purchase flow on old architecture (#2000) via Cesar de la Vega (@vegaro)
* Only scan src/ for codegen specs in react-native-purchases-ui and galaxy (#2017) via Cesar de la Vega (@vegaro)
* chore(deps): bump compression from 1.8.1 to 1.8.2 in /e2e-tests/AGP9TestApp (#2025) via dependabot[bot] (@dependabot[bot])
* chore(deps): bump shell-quote from 1.10.0 to 1.12.0 in /examples/adsTester (#2026) via dependabot[bot] (@dependabot[bot])
* chore(deps): bump joi from 17.13.4 to 17.13.8 in /examples/adsTester (#2027) via dependabot[bot] (@dependabot[bot])

## 10.13.0
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.11.0 (#2024) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.27.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.27.0)
  * [iOS 5.95.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.95.0)

## RevenueCatUI SDK
### ✨ New Features
* feat(paywalls): Add callbacks to presentPaywall and presentPaywallIfNeeded (#1958) via Álvaro Brey (@AlvaroBrey)

## 10.12.2
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.10.0 (#2014) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 5.94.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.94.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.9.0 (#2013) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* other: extras to support InstallmentsInfo on iOS (#2002) via Will Taylor (@fire-at-will)
* Bump CI to Ruby 3.3 (#2012) via Josh Holtz (@joshdholtz)

## 10.12.1
## RevenueCat SDK
### 🐞 Bugfixes
* Fix iOS ignoring `automaticDeviceIdentifierCollectionEnabled` in `configure` (RevenueCat/purchases-hybrid-common#1956) via Álvaro Brey (@AlvaroBrey)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.8.0 (#2007) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.26.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.26.0)
  * [Android 10.25.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.25.0)
  * [Android 10.24.2](https://github.com/RevenueCat/purchases-android/releases/tag/10.24.2)
  * [iOS 5.93.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.93.0)
  * [Web 1.70.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.70.0)
  * [Web 1.69.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.69.0)
  * [Web 1.68.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.68.0)

### 🔄 Other Changes
* chore(deps): bump shell-quote from 1.10.0 to 1.12.0 in /examples/MagicWeather (#2006) via dependabot[bot] (@dependabot[bot])
* chore(deps): bump joi from 17.13.7 to 17.13.8 (#2005) via dependabot[bot] (@dependabot[bot])
* chore(deps): bump compression from 1.8.1 to 1.8.2 in /examples/adsTester (#2004) via dependabot[bot] (@dependabot[bot])

## 10.12.0
## RevenueCat SDK
### ✨ New Features
* Track rewarded ad prompt shown and accepted (#1988) via Drago Crnjac (@popcorn)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.6.0 (#1989) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.24.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.24.1)

### 🔄 Other Changes
* chore(deps): bump shell-quote from 1.10.0 to 1.12.0 (#2001) via dependabot[bot] (@dependabot[bot])
* chore(deps): bump joi from 17.13.7 to 17.13.8 in /examples/MagicWeather (#1995) via dependabot[bot] (@dependabot[bot])
* chore(deps): bump fastlane-plugin-revenuecat_internal from `c3e3afe` to `4c49d48` (#1998) via dependabot[bot] (@dependabot[bot])
* chore(deps): bump compression from 1.8.0 to 1.8.2 (#1996) via dependabot[bot] (@dependabot[bot])
* Bump purchaseTesterTypescript to React Native 0.87.1 (#1992) via Cesar de la Vega (@vegaro)
* chore(deps): bump brace-expansion from 1.1.18 to 1.1.21 in /examples/adsTester (#1994) via dependabot[bot] (@dependabot[bot])
* chore(deps): bump fastlane-plugin-revenuecat_internal from `9f7a03e` to `c3e3afe` (#1993) via dependabot[bot] (@dependabot[bot])
* chore(deps): bump brace-expansion from 1.1.16 to 1.1.21 (#1990) via dependabot[bot] (@dependabot[bot])
* chore(deps): bump brace-expansion from 1.1.16 to 1.1.21 in /examples/MagicWeather (#1985) via dependabot[bot] (@dependabot[bot])
* chore: bump sample app to Android target SDK 36 (#1856) via Toni Rico (@tonidero)

## 10.11.0
## RevenueCat SDK
### ✨ New Features
* Allow opting in to external purchase custom links on iOS (experimental) (#1976) via Antonio Pallares (@ajpallares)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.5.0 (#1984) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.24.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.24.0)
  * [Android 10.23.4](https://github.com/RevenueCat/purchases-android/releases/tag/10.23.4)
  * [Android 10.23.3](https://github.com/RevenueCat/purchases-android/releases/tag/10.23.3)
  * [Android 10.23.2](https://github.com/RevenueCat/purchases-android/releases/tag/10.23.2)
  * [Android 10.23.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.23.1)
  * [Android 10.23.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.23.0)
  * [iOS 5.92.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.92.0)
  * [iOS 5.91.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.91.0)
  * [Web 1.67.1](https://github.com/RevenueCat/purchases-js/releases/tag/1.67.1)
  * [Web 1.67.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.67.0)
  * [Web 1.66.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.66.0)
  * [Web 1.65.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.65.0)
  * [Web 1.64.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.64.0)
* [RENOVATE] Update dependency revenuecat to v4.6.2 (#1981) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.4.1 (#1979) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.4.0 (#1977) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* chore(deps): bump ip-address from 10.4.0 to 10.7.2 in /examples/MagicWeather (#1982) via dependabot[bot] (@dependabot[bot])

## 10.10.2
## RevenueCat SDK
### 🐞 Bugfixes
* Bump PHC to 19.3.0 and fix errors not matching PurchasesError (#1919) via Álvaro Brey (@AlvaroBrey)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.3.1 (#1973) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 5.90.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.90.2)

### 🔄 Other Changes
* Auto-merge PHC bump PRs (#1972) via Álvaro Brey (@AlvaroBrey)
* chore(deps): bump fastlane-plugin-revenuecat_internal from `6db1da0` to `9f7a03e` (#1970) via dependabot[bot] (@dependabot[bot])
* chore(deps): bump fastlane from 2.240.0 to 2.240.1 (#1971) via dependabot[bot] (@dependabot[bot])

## 10.10.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.2.0 (#1965) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.22.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.22.1)
  * [Android 10.22.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.22.0)
  * [iOS 5.90.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.90.1)
  * [iOS 5.90.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.90.0)
  * [Web 1.63.1](https://github.com/RevenueCat/purchases-js/releases/tag/1.63.1)
  * [Web 1.63.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.63.0)
  * [Web 1.62.1](https://github.com/RevenueCat/purchases-js/releases/tag/1.62.1)
  * [Web 1.62.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.62.0)
  * [Web 1.61.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.61.0)

### 🔄 Other Changes
* chore(deps): bump fastlane from 2.239.0 to 2.240.0 (#1963) via dependabot[bot] (@dependabot[bot])
* ci: approve the release hold automatically when the release PR is approved (#1961) via Álvaro Brey (@AlvaroBrey)

## 10.10.0
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.0.0 (#1955) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.21.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.21.1)
  * [Android 10.21.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.21.0)
  * [iOS 5.89.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.89.0)
  * [Web 1.60.1](https://github.com/RevenueCat/purchases-js/releases/tag/1.60.1)
  * [Web 1.60.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.60.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.38.0 (#1952) via RevenueCat Git Bot (@RCGitBot)

## RevenueCatUI SDK
### ✨ New Features
* feat(paywalls): Add onInteraction callback to PaywallView (#1956) via Álvaro Brey (@AlvaroBrey)

### 🔄 Other Changes
* docs: Link the paywall interaction event reference (#1959) via Álvaro Brey (@AlvaroBrey)
* [EXTERNAL] fix: prefix browser-mode detection logs with [RevenueCat] (#1953) via @cpruijsen (#1954) via Rick (@rickvdl)

## 10.9.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.37.0 (#1946) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.20.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.20.0)
  * [iOS 5.88.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.88.0)
  * [Web 1.59.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.59.0)
  * [Web 1.58.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.58.0)
  * [Web 1.57.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.57.0)
  * [Web 1.56.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.56.0)
  * [Web 1.55.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.55.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.36.1 (#1944) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.36.0 (#1943) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.35.0 (#1937) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.34.0 (#1936) via RevenueCat Git Bot (@RCGitBot)

## RevenueCatUI SDK
### 🐞 Bugfixes
* [EXTERNAL] Fix build on AGP 9 by skipping kotlin-android when AGP registers the kotlin extension (#1934) via @gabrieldonadel (#1939) via Álvaro Brey (@AlvaroBrey)

### 🔄 Other Changes
* chore(deps): bump baseline-browser-mapping from 2.10.16 to 2.11.21 (#1947) via dependabot[bot] (@dependabot[bot])
* chore(deps): bump joi from 17.13.3 to 17.13.7 in /examples/MagicWeather (#1950) via dependabot[bot] (@dependabot[bot])
* chore(deps): bump js-yaml from 3.15.1 to 3.15.2 (#1949) via dependabot[bot] (@dependabot[bot])
* chore(deps): bump joi from 17.13.4 to 17.13.7 (#1948) via dependabot[bot] (@dependabot[bot])
* chore(deps): bump fastlane from 2.238.0 to 2.239.0 (#1945) via dependabot[bot] (@dependabot[bot])
* ci: compile a React Native 0.87 app on AGP 9 with and without built-in Kotlin (#1940) via Álvaro Brey (@AlvaroBrey)
* ci: bump external PR notifications workflow to v8 (#1942) via Álvaro Brey (@AlvaroBrey)
* ci: notify external PRs feed on PRs from outside the org (#1941) via Álvaro Brey (@AlvaroBrey)
* chore(deps): bump browserslist from 4.28.1 to 4.28.8 in /examples/MagicWeather (#1935) via dependabot[bot] (@dependabot[bot])

## 10.9.0
## RevenueCat SDK
### ✨ New Features
* feat(singular): add setSingularDeviceID (#1928) via Guillem Corominas (@guillemcorominas)

### 🔄 Other Changes
* chore(deps): bump fastlane-plugin-revenuecat_internal from `7dd9ab9` to `6db1da0` (#1932) via dependabot[bot] (@dependabot[bot])

## 10.8.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.33.1 (#1929) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.19.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.19.1)
  * [Android 10.19.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.19.0)
  * [iOS 5.87.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.87.1)
  * [iOS 5.87.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.87.0)
  * [iOS 5.86.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.86.0)
  * [Web 1.54.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.54.0)

### 🔄 Other Changes
* chore(ads): remove ads beta jsdoc markers (#1918) via Peter Porfy (@peterporfy)
* Upgrade MagicWeather to React Native 0.87 and RevenueCat 10.8 (#1926) via Jens-Fabian Goetzmann (@jefago)
* chore: don't run danger on main (#1921) via Cesar de la Vega (@vegaro)

## 10.8.0
## RevenueCat SDK
### ✨ New Features
* feat(ads): ad reward tracking support (#1890) via Peter Porfy (@peterporfy)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.32.1 (#1913) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.18.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.18.1)
  * [Android 10.18.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.18.0)
  * [iOS 5.85.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.85.0)
  * [Web 1.53.1](https://github.com/RevenueCat/purchases-js/releases/tag/1.53.1)
  * [Web 1.53.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.53.0)

## RevenueCatUI SDK
### 🐞 Bugfixes
* [EXTERNAL] Fix RN interop mode crash for Paywalls (#1916) via @TheRogue76 (#1917) via Cesar de la Vega (@vegaro)

### 🔄 Other Changes
* Update sdks-common-config orb to v4.6.1 (#1914) via Antonio Pallares (@ajpallares)
* Match native SDKs text for simulated store purchase alert (#1724) via Antonio Pallares (@ajpallares)
* fix: web purchases report SDK version 9.1.0 instead of the real one (#1910) via Antonio Pallares (@ajpallares)
* Bump js-yaml from 4.3.0 to 4.3.1 in /examples/adsTester (#1911) via dependabot[bot] (@dependabot[bot])
* feat: rewarded ad sample app (#1897) via Peter Porfy (@peterporfy)
* chore(ios): drop dead Swift stubs and namespace React header imports (#1906) via Antonio Pallares (@ajpallares)

## 10.7.2
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.31.0 (#1904) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.17.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.17.0)
  * [Android 10.16.2](https://github.com/RevenueCat/purchases-android/releases/tag/10.16.2)
  * [iOS 5.84.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.84.0)
  * [iOS 5.83.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.83.2)
  * [Web 1.52.3](https://github.com/RevenueCat/purchases-js/releases/tag/1.52.3)
  * [Web 1.52.2](https://github.com/RevenueCat/purchases-js/releases/tag/1.52.2)
  * [Web 1.52.1](https://github.com/RevenueCat/purchases-js/releases/tag/1.52.1)
* [RENOVATE] Update dependency revenuecat to v4.6.0 (#1902) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.30.1 (#1901) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `7fbbe66` to `7dd9ab9` (#1905) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.237.0 to 2.238.0 (#1903) via dependabot[bot] (@dependabot[bot])

## 10.7.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.30.0 (#1899) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.16.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.16.1)
  * [iOS 5.83.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.83.1)
  * [Web 1.52.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.52.0)
  * [Web 1.51.2](https://github.com/RevenueCat/purchases-js/releases/tag/1.51.2)
  * [Web 1.51.1](https://github.com/RevenueCat/purchases-js/releases/tag/1.51.1)
  * [Web 1.51.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.51.0)
  * [Web 1.50.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.50.0)

### 🔄 Other Changes
* Bump nanoid from 3.3.11 to 3.3.18 (#1895) via dependabot[bot] (@dependabot[bot])
* Bump js-yaml from 3.15.0 to 3.15.1 (#1896) via dependabot[bot] (@dependabot[bot])
* Bump json from 2.20.0 to 2.21.2 (#1894) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `b4e1e7f` to `7fbbe66` (#1893) via dependabot[bot] (@dependabot[bot])

## 10.7.0
## RevenueCat SDK
### ✨ New Features
* feat: add setOnesignalUserID for OneSignal v11+ (#1877) via Cesar de la Vega (@vegaro)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.29.0 (#1882) via RevenueCat Git Bot (@RCGitBot)

## RevenueCatUI SDK
### ✨ New Features
* Add onWebCheckoutOpened and onUrlOpened to the paywall listener (#1871) via Álvaro Brey (@AlvaroBrey)

### 🔄 Other Changes
* Wire mise into CI for Ruby, Node, and JDK (#1870) via Álvaro Brey (@AlvaroBrey)
* Bump ip-address from 10.1.0 to 10.4.0 in /examples/MagicWeather (#1889) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `dd577ee` to `b4e1e7f` (#1888) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `3421c88` to `dd577ee` (#1885) via dependabot[bot] (@dependabot[bot])
* Bump danger from 9.6.0 to 9.6.1 (#1884) via dependabot[bot] (@dependabot[bot])
* Add multipage to CHANGELOG (#1883) via Cesar de la Vega (@vegaro)

## 10.6.0
## RevenueCat SDK
### ✨ New Features
* Enables support for multipage paywalls

### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.28.0 (#1879) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.16.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.16.0)
  * [iOS 5.83.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.83.0)
  * [iOS 5.82.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.82.0)
  * [Web 1.49.1](https://github.com/RevenueCat/purchases-js/releases/tag/1.49.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.27.0 (#1876) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Remove workflows dangerous settings (#1878) via Facundo Menzella (@facumenzella)

## 10.5.0
## RevenueCat SDK
### ✨ New Features
* feat(ads): reward-verification primitives for react-native (#1828) via Peter Porfy (@peterporfy)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.26.0 (#1874) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.15.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.15.1)
  * [Android 10.15.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.15.0)
  * [iOS 5.81.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.81.3)
  * [iOS 5.81.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.81.2)
  * [Web 1.49.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.49.0)
  * [Web 1.48.1](https://github.com/RevenueCat/purchases-js/releases/tag/1.48.1)
  * [Web 1.48.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.48.0)
  * [Web 1.47.3](https://github.com/RevenueCat/purchases-js/releases/tag/1.47.3)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.25.0 (#1872) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.24.0 (#1867) via RevenueCat Git Bot (@RCGitBot)
* [RENOVATE] Update dependency revenuecat to v4.5.1 (#1868) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `d392939` to `3421c88` (#1873) via dependabot[bot] (@dependabot[bot])
* Bump tar from 7.5.20 to 7.5.22 in /examples/MagicWeather (#1869) via dependabot[bot] (@dependabot[bot])
* Bump json from 2.12.2 to 2.19.9 in /examples/purchaseTesterTypescript (#1866) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `b52fca5` to `d392939` (#1865) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `9b928b6` to `b52fca5` (#1863) via dependabot[bot] (@dependabot[bot])
* Bump brace-expansion from 1.1.13 to 1.1.16 in /examples/MagicWeather (#1862) via dependabot[bot] (@dependabot[bot])
* Bump shell-quote from 1.8.4 to 1.10.0 in /examples/MagicWeather (#1861) via dependabot[bot] (@dependabot[bot])
* Bump tar from 7.5.11 to 7.5.20 in /examples/MagicWeather (#1859) via dependabot[bot] (@dependabot[bot])
* Bump shell-quote from 1.8.4 to 1.10.0 (#1860) via dependabot[bot] (@dependabot[bot])
* Bump brace-expansion from 1.1.11 to 1.1.16 (#1858) via dependabot[bot] (@dependabot[bot])

## 10.4.4
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.22.2 (#1855) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.14.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.14.1)
  * [Android 10.14.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.14.0)
  * [Android 10.13.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.13.0)
  * [iOS 5.81.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.81.1)
  * [iOS 5.81.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.81.0)
  * [iOS 5.80.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.80.3)
  * [Web 1.47.2](https://github.com/RevenueCat/purchases-js/releases/tag/1.47.2)
  * [Web 1.47.1](https://github.com/RevenueCat/purchases-js/releases/tag/1.47.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.22.1 (#1852) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* chore: add internal support for enabling workflows from React Native (#1847) via Cesar de la Vega (@vegaro)
* chore: bump fastlane-plugin-revenuecat_internal to unblock hybrid bumps (#1853) via Antonio Pallares (@ajpallares)
* ci: bump sdks-common-config orb to 4.5.0 (#1851) via Antonio Pallares (@ajpallares)
* Bump fastlane-plugin-revenuecat_internal from `dab6765` to `9e334ff` (#1850) via dependabot[bot] (@dependabot[bot])

## 10.4.3
## RevenueCat SDK
### 📦 Dependency Updates
* [RENOVATE] Update dependency revenuecat to v4 (#1846) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.21.0 (#1843) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.13.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.13.0)
  * [iOS 5.80.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.80.3)
  * [Web 1.47.1](https://github.com/RevenueCat/purchases-js/releases/tag/1.47.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.19.1 (#1838) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Bump cocoapods from 1.16.2 to 1.17.0 (#1844) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.236.1 to 2.237.0 (#1842) via dependabot[bot] (@dependabot[bot])
* Bump ws from 6.2.3 to 6.2.4 (#1839) via dependabot[bot] (@dependabot[bot])

## 10.4.2
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.19.0 (#1835) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.12.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.12.0)
  * [iOS 5.80.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.80.2)
  * [iOS 5.80.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.80.1)
  * [Web 1.47.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.47.0)

### 🔄 Other Changes
* Bump js-yaml from 3.14.2 to 3.15.0 in /examples/MagicWeather (#1834) via dependabot[bot] (@dependabot[bot])

## 10.4.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.18.0 (#1830) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.11.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.11.0)
  * [Android 10.10.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.10.0)
  * [iOS 5.80.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.80.0)
  * [iOS 5.79.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.79.0)
  * [Web 1.46.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.46.0)
  * [Web 1.45.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.45.0)
  * [Web 1.44.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.44.0)
  * [Web 1.43.1](https://github.com/RevenueCat/purchases-js/releases/tag/1.43.1)
  * [Web 1.43.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.43.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.17.0 (#1827) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.16.0 (#1824) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* feat: Add apitester coverage for new `SubscriptionInfo` fields (#1823) via Álvaro Brey (@AlvaroBrey)
* Bump fastlane-plugin-revenuecat_internal from `70bf5c7` to `dab6765` (#1831) via dependabot[bot] (@dependabot[bot])
* Bump js-yaml from 3.14.2 to 3.15.0 (#1829) via dependabot[bot] (@dependabot[bot])
* Bump faraday from 1.10.5 to 1.10.6 (#1826) via dependabot[bot] (@dependabot[bot])
* Bump concurrent-ruby from 1.3.3 to 1.3.7 in /examples/MagicWeather (#1820) via dependabot[bot] (@dependabot[bot])
* Bump nokogiri from 1.19.3 to 1.19.4 (#1821) via dependabot[bot] (@dependabot[bot])
* Bump danger from 9.5.3 to 9.6.0 (#1819) via dependabot[bot] (@dependabot[bot])

## 10.4.0
## RevenueCat SDK
### ✨ New Features
* Add presentedOfferingContext support to custom paywall impression events (#1796) via Rick (@rickvdl)
* feat: Add setAppsFlyerConversionData (#1805) via Toni Rico (@tonidero)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.15.1 (#1807) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.9.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.9.1)
  * [Web 1.42.4](https://github.com/RevenueCat/purchases-js/releases/tag/1.42.4)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.15.0 (#1804) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Bump @babel/core from 7.26.9 to 7.29.6 (#1812) via dependabot[bot] (@dependabot[bot])
* chore: Add 3-day Dependabot cooldown, excluding fastlane plugin (#1815) via Toni Rico (@tonidero)
* Bump launch-editor from 2.12.0 to 2.14.1 in /examples/MagicWeather (#1813) via dependabot[bot] (@dependabot[bot])
* Bump tar from 7.5.11 to 7.5.16 (#1814) via dependabot[bot] (@dependabot[bot])
* Upgrade MagicWeather to React Native 0.86 and react-native-purchases 10.3 (#1811) via Jens-Fabian Goetzmann (@jefago)
* Bump ws from 6.2.3 to 6.2.4 in /examples/MagicWeather (#1810) via dependabot[bot] (@dependabot[bot])
* Bump tmp from 0.2.6 to 0.2.7 (#1809) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `ce6a7ef` to `70bf5c7` (#1808) via dependabot[bot] (@dependabot[bot])
* Bump joi from 17.13.3 to 17.13.4 (#1806) via dependabot[bot] (@dependabot[bot])

## 10.3.0
## RevenueCat SDK
### ✨ New Features
* Add Galaxy Store support for Android (#1795) via Rick (@rickvdl)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.14.1 (#1802) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.9.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.9.0)
  * [iOS 5.78.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.78.0)
  * [iOS 5.77.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.77.0)
  * [Web 1.42.3](https://github.com/RevenueCat/purchases-js/releases/tag/1.42.3)
  * [Web 1.42.2](https://github.com/RevenueCat/purchases-js/releases/tag/1.42.2)
  * [Web 1.42.1](https://github.com/RevenueCat/purchases-js/releases/tag/1.42.1)

### 🔄 Other Changes
* Bump fastlane from 2.236.0 to 2.236.1 (#1801) via dependabot[bot] (@dependabot[bot])

## 10.2.3
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.11.0 (#1792) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Bump shell-quote from 1.8.3 to 1.8.4 in /examples/MagicWeather (#1798) via dependabot[bot] (@dependabot[bot])
* Bump shell-quote from 1.8.2 to 1.8.4 (#1797) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.235.0 to 2.236.0 (#1793) via dependabot[bot] (@dependabot[bot])

## 10.2.2
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.10.0 (#1790) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.8.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.8.0)
  * [iOS 5.76.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.76.0)
  * [Web 1.42.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.42.0)

## 10.2.1
## RevenueCat SDK
### 🐞 Bugfixes
* Fix NativeEventEmitter crash on React Native 0.79+ (#1595) via Josh Holtz (@joshdholtz)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.9.1 (#1785) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.7.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.7.0)
  * [iOS 5.75.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.75.0)
  * [Web 1.41.2](https://github.com/RevenueCat/purchases-js/releases/tag/1.41.2)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `af7bb5c` to `ce6a7ef` (#1787) via dependabot[bot] (@dependabot[bot])

## 10.2.0
## RevenueCat SDK
### ✨ New Features
* feat(ads): add ad tracking (#1780) via Peter Porfy (@peterporfy)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.8.0 (#1778) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.6.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.6.1)
  * [iOS 5.74.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.74.0)
  * [iOS 5.73.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.73.1)
  * [Web 1.41.1](https://github.com/RevenueCat/purchases-js/releases/tag/1.41.1)
  * [Web 1.41.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.41.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.7.1 (#1773) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Bump tmp from 0.2.5 to 0.2.6 (#1782) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.234.0 to 2.235.0 (#1781) via dependabot[bot] (@dependabot[bot])
* [EXTERNAL] fix: wrong npx command in DEVELOPMENT.md (#1775) via @mervivian (#1777) via Antonio Pallares (@ajpallares)
* Bump qs from 6.15.1 to 6.15.2 in /examples/MagicWeather (#1774) via dependabot[bot] (@dependabot[bot])

## 10.1.2
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.7.0 (#1771) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.6.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.6.0)
  * [iOS 5.73.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.73.0)
  * [Web 1.40.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.40.0)
  * [Web 1.39.1](https://github.com/RevenueCat/purchases-js/releases/tag/1.39.1)

## 10.1.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.6.0 (#1763) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.5.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.5.0)
  * [Android 10.4.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.4.0)
  * [iOS 5.72.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.72.0)
  * [iOS 5.71.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.71.0)
  * [Web 1.39.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.39.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.5.0 (#1762) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* MagicWeather: upgrade to React Native 0.85.3 (#1769) via Jens-Fabian Goetzmann (@jefago)
* Bump fastlane from 2.233.1 to 2.234.0 (#1768) via dependabot[bot] (@dependabot[bot])
* Bump @babel/plugin-transform-modules-systemjs from 7.28.5 to 7.29.4 in /examples/MagicWeather (#1766) via dependabot[bot] (@dependabot[bot])
* Bump @babel/plugin-transform-modules-systemjs from 7.25.9 to 7.29.4 (#1765) via dependabot[bot] (@dependabot[bot])
* Bump fast-xml-builder from 1.1.4 to 1.2.0 (#1764) via dependabot[bot] (@dependabot[bot])

## 10.1.0
## RevenueCat SDK
### ✨ New Features
* Unified StoreReplacementMode API + Deprecate PRORATION_MODE enum API (#1749) via Will Taylor (@fire-at-will)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.4.0 (#1760) via RevenueCat Git Bot (@RCGitBot)

## 10.0.2
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.3.0 (#1754) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.3.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.3.1)
  * [Android 10.3.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.3.0)
  * [Android 10.2.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.2.1)
  * [iOS 5.70.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.70.0)
  * [iOS 5.69.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.69.0)
  * [Web 1.38.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.38.0)
  * [Web 1.37.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.37.0)
  * [Web 1.36.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.36.0)
  * [Web 1.35.1](https://github.com/RevenueCat/purchases-js/releases/tag/1.35.1)
  * [Web 1.35.0](https://github.com/RevenueCat/purchases-js/releases/tag/1.35.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.2.0 (#1746) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `21e02ec` to `af7bb5c` (#1757) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `2d11430` to `21e02ec` (#1755) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `d24ab26` to `2d11430` (#1748) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.233.0 to 2.233.1 (#1744) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `b822f01` to `d24ab26` (#1740) via dependabot[bot] (@dependabot[bot])
* Add web SDK to release automations (#1738) via Toni Rico (@tonidero)
* Bump fastlane-plugin-revenuecat_internal from `e348913` to `b822f01` (#1737) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `a1eed48` to `e348913` (#1735) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.232.2 to 2.233.0 (#1736) via dependabot[bot] (@dependabot[bot])

## 10.0.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.1.0 (#1733) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.2.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.2.0)
  * [iOS 5.68.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.68.0)

### 🔄 Other Changes
* Add retry mechanism to Maestro e2e tests (#1731) via Antonio Pallares (@ajpallares)
* Bump fastlane-plugin-revenuecat_internal from `20911d1` to `a1eed48` (#1732) via dependabot[bot] (@dependabot[bot])

## 10.0.0
## RevenueCat SDK
> [!WARNING]  
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrect as consumables, RevenueCat will consume these purchases. This means that customers won't be able to restore them from version 10.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions. Please see more information in our [docs](https://www.revenuecat.com/docs/known-store-issues/play-billing-library/restore-consumable-purchases-bc8)

### 💥 Breaking Changes
This release updates to Billing Library 8.3.0 with min SDK supported of Android 6 (API 23), previously min was 21. It also removes a previous workaround used to be able to restore consumed one time products which is not available anymore.

* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.0.0 (#1729) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.1.2](https://github.com/RevenueCat/purchases-android/releases/tag/10.1.2)
  * [Android 10.1.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.1.1)
  * [Android 10.1.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.1.0)
  * [Android 10.0.2](https://github.com/RevenueCat/purchases-android/releases/tag/10.0.2)
  * [Android 10.0.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.0.1)
  * [Android 9.29.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.29.1)
  * [Android 10.0.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.0.0)
  * [iOS 5.67.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.67.2)

### 🔄 Other Changes
* Skip test cases list in maestro tests using launch arguments (#1722) via Antonio Pallares (@ajpallares)
* Add CircleCI job for maestro E2E tests (#1637) via Antonio Pallares (@ajpallares)
* Bump fastlane-plugin-revenuecat_internal from `894bb1b` to `20911d1` (#1728) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `ceecf91` to `894bb1b` (#1726) via dependabot[bot] (@dependabot[bot])
* Update CODEOWNERS default owner to @RevenueCat/sdk (#1725) via Antonio Pallares (@ajpallares)
* Add maestro E2E test for purchase through paywall (#1636) via Antonio Pallares (@ajpallares)
* Add maestro E2E test app (#1635) via Antonio Pallares (@ajpallares)
* Bump addressable from 2.8.9 to 2.9.0 (#1723) via dependabot[bot] (@dependabot[bot])
* Bump addressable from 2.8.7 to 2.9.0 in /examples/purchaseTesterTypescript (#1721) via dependabot[bot] (@dependabot[bot])
* Bump addressable from 2.8.7 to 2.9.0 in /examples/MagicWeather (#1720) via dependabot[bot] (@dependabot[bot])

## 9.15.2
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.55.1 (#1717) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.29.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.29.0)
  * [iOS 5.67.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.67.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.55.0 (#1716) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `6289be1` to `ceecf91` (#1718) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `5d6e93f` to `6289be1` (#1715) via dependabot[bot] (@dependabot[bot])
* Bump lodash from 4.17.23 to 4.18.1 in /examples/MagicWeather (#1714) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `b5a7159` to `5d6e93f` (#1713) via dependabot[bot] (@dependabot[bot])

## 9.15.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.54.0 (#1706) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.28.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.28.1)
  * [Android 9.28.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.28.0)
  * [iOS 5.67.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.67.0)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `f11fe40` to `b5a7159` (#1707) via dependabot[bot] (@dependabot[bot])
* Add AGENTS.md for AI coding assistants (#1616) via Facundo Menzella (@facumenzella)
* chore: bump react-native devDependency from 0.73.5 to 0.78.0 (#1704) via Cesar de la Vega (@vegaro)
* Fix known security vulnerabilities in dependencies (#1703) via Cesar de la Vega (@vegaro)
* Bump brace-expansion from 1.1.12 to 1.1.13 in /examples/MagicWeather (#1702) via dependabot[bot] (@dependabot[bot])

## 9.15.0
## RevenueCat SDK
### ✨ New Features
* CustomerCenter: Adds onPromotionalOfferSucceeded callback, bump purchases-hybrid-common to 17.53.0 (#1684) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.27.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.27.0)
  * [iOS 5.66.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.66.0)
### 📦 Dependency Updates
* [RENOVATE] Update dependency gradle to v9.4.1 (#1688) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Bump node-forge from 1.3.3 to 1.4.0 (#1700) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `9a6911b` to `f11fe40` (#1699) via dependabot[bot] (@dependabot[bot])
* Bump yaml from 1.10.2 to 1.10.3 (#1695) via dependabot[bot] (@dependabot[bot])
* Bump yaml from 2.8.2 to 2.8.3 in /examples/MagicWeather (#1698) via dependabot[bot] (@dependabot[bot])
* Bump picomatch from 2.3.1 to 2.3.2 (#1697) via dependabot[bot] (@dependabot[bot])
* Bump picomatch from 2.3.1 to 2.3.2 in /examples/MagicWeather (#1696) via dependabot[bot] (@dependabot[bot])
* Bump activesupport from 7.2.2.1 to 7.2.3.1 in /examples/purchaseTesterTypescript (#1693) via dependabot[bot] (@dependabot[bot])
* Bump fast-xml-parser from 4.5.4 to 4.5.5 in /examples/MagicWeather (#1692) via dependabot[bot] (@dependabot[bot])
* security: pin GitHub Actions to SHA hashes (#1691) via Alfonso Embid-Desmet (@alfondotnet)
* Bump activesupport from 7.2.2.2 to 7.2.3.1 (#1690) via dependabot[bot] (@dependabot[bot])
* Bump activesupport from 7.2.2.1 to 7.2.3.1 in /examples/MagicWeather (#1689) via dependabot[bot] (@dependabot[bot])
* Merge release PR after deploy (#1686) via Antonio Pallares (@ajpallares)
* Require PR approval before release tagging (#1685) via Antonio Pallares (@ajpallares)
* Bump flatted from 3.3.3 to 3.4.2 in /examples/MagicWeather (#1687) via dependabot[bot] (@dependabot[bot])
* Bump json from 2.18.1 to 2.19.2 (#1683) via dependabot[bot] (@dependabot[bot])

## 9.14.0
## RevenueCat SDK
### ✨ New Features
* Add offeringId override to trackCustomPaywallImpression (#1679) via Rick (@rickvdl)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.52.0 (#1680) via RevenueCat Git Bot (@RCGitBot)

## RevenueCatUI SDK
### ✨ New Features
* Add number and boolean support for CustomVariable (#1675) via Facundo Menzella (@facumenzella)

## 9.13.0
## RevenueCat SDK
### ✨ New Features
* Add trackCustomPaywallImpression API (#1660) via Rick (@rickvdl)
### 📦 Dependency Updates
* Updates purchases-hybrid-common to 17.51.1 (#1677) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.26.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.26.1)
  * [Android 9.26.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.26.0)
  * [Android 9.25.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.25.0)
  * [Android 9.24.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.24.0)
  * [iOS 5.65.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.65.0)
  * [iOS 5.64.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.64.0)
  * [iOS 5.63.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.63.0)
  * [iOS 5.62.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.62.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.51.0 (#1674) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.26.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.26.1)
  * [Android 9.26.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.26.0)
  * [Android 9.25.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.25.0)
  * [Android 9.24.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.24.0)
  * [iOS 5.65.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.65.0)
  * [iOS 5.64.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.64.0)
  * [iOS 5.63.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.63.0)
  * [iOS 5.62.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.62.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.50.0 (#1672) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.26.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.26.1)
  * [Android 9.26.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.26.0)
  * [Android 9.25.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.25.0)
  * [Android 9.24.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.24.0)
  * [iOS 5.65.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.65.0)
  * [iOS 5.64.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.64.0)
  * [iOS 5.63.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.63.0)
  * [iOS 5.62.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.62.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.49.0 (#1670) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.26.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.26.1)
  * [Android 9.26.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.26.0)
  * [Android 9.25.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.25.0)
  * [Android 9.24.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.24.0)
  * [iOS 5.65.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.65.0)
  * [iOS 5.64.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.64.0)
  * [iOS 5.63.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.63.0)
  * [iOS 5.62.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.62.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.48.0 (#1668) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.26.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.26.1)
  * [Android 9.26.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.26.0)
  * [Android 9.25.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.25.0)
  * [Android 9.24.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.24.0)
  * [iOS 5.65.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.65.0)
  * [iOS 5.64.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.64.0)
  * [iOS 5.63.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.63.0)
  * [iOS 5.62.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.62.0)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `3e8c384` to `9a6911b` (#1676) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `e146447` to `3e8c384` (#1671) via dependabot[bot] (@dependabot[bot])
* Bump tar from 7.5.10 to 7.5.11 (#1669) via dependabot[bot] (@dependabot[bot])

## 9.12.0
## RevenueCat SDK
### ✨ New Features
* Add setAppstackAttributionParams API (#1661) via Rick (@rickvdl)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.46.1 (#1663) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.46.0 (#1662) via RevenueCat Git Bot (@RCGitBot)
* [RENOVATE] Update dependency gradle to v9.4.0 (#1656) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.45.0 (#1657) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Bump tar from 7.5.10 to 7.5.11 in /examples/MagicWeather (#1664) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `f5c099b` to `e146447` (#1659) via dependabot[bot] (@dependabot[bot])
* Bump tar from 7.5.9 to 7.5.10 in /examples/MagicWeather (#1647) via dependabot[bot] (@dependabot[bot])

## 9.11.2
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.44.0 (#1654) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.23.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.23.1)
  * [Android 9.23.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.23.0)
  * [iOS 5.61.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.61.0)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `8cd957f` to `f5c099b` (#1652) via dependabot[bot] (@dependabot[bot])

## 9.11.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.42.0 (#1648) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.22.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.22.2)
  * [iOS 5.60.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.60.0)

### 🔄 Other Changes
* Bump tar from 7.5.9 to 7.5.10 (#1649) via dependabot[bot] (@dependabot[bot])

## 9.11.0
## RevenueCat SDK
### ✨ New Features
* Add custom PurchaseLogic support to PaywallView component (#1607) via Rick (@rickvdl)

### 🔄 Other Changes
* Update sdks-common-config orb to 3.13.0 (#1645) via Cesar de la Vega (@vegaro)
* Bump fast-xml-parser from 4.5.3 to 4.5.4 in /examples/MagicWeather (#1642) via dependabot[bot] (@dependabot[bot])
* Add custom PurchaseLogic button to OfferingDetailScreen (#1641) via Rick (@rickvdl)
* Bump fastlane from 2.232.1 to 2.232.2 (#1640) via dependabot[bot] (@dependabot[bot])
* Bump minimatch from 3.1.3 to 3.1.5 (#1639) via dependabot[bot] (@dependabot[bot])
* Bump fast-xml-parser from 4.5.3 to 4.5.4 (#1638) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `ea6276c` to `8cd957f` (#1634) via dependabot[bot] (@dependabot[bot])

## 9.10.5
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.41.1 (#1625) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.22.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.22.1)

### 🔄 Other Changes
* Update `README` to include Web Billing (#1629) via JayShortway (@JayShortway)
* Bump minimatch from 3.1.2 to 3.1.3 (#1628) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal to ea6276c (#1618) via Facundo Menzella (@facumenzella)

## 9.10.4
## RevenueCatUI SDK
### 🐞 Bugfixes
* Fix crash when using customVariables with Paywall component (#1623) via Facundo Menzella (@facumenzella)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `afc9219` to `ea6276c` (#1624) via dependabot[bot] (@dependabot[bot])

## 9.10.3
### 🔄 Other Changes
* Add internal API to debug tracked events on iOS (#1612) via Antonio Pallares (@ajpallares)

## 9.10.2
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.41.0 (#1613) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 5.59.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.59.2)
  * [iOS 5.59.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.59.1)

### 🔄 Other Changes
* Bump tar from 7.5.7 to 7.5.9 (#1615) via dependabot[bot] (@dependabot[bot])
* Bump nokogiri from 1.19.0 to 1.19.1 (#1614) via dependabot[bot] (@dependabot[bot])
* Add UI package tests to CI (#1602) via Facundo Menzella (@facumenzella)
* Bump tar from 7.5.7 to 7.5.9 in /examples/MagicWeather (#1611) via dependabot[bot] (@dependabot[bot])

## 9.10.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.40.0 (#1608) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.22.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.22.0)

### 🔄 Other Changes
* Add debugEventListener internal API (#1609) via Toni Rico (@tonidero)

## 9.10.0
## RevenueCat SDK
### ✨ New Features
* [SDK-4254] Add onPurchasePackageInitiated callback to Paywall component (#1598) via Toni Rico (@tonidero)
### 🐞 Bugfixes
* Fix: footer paywall purchase hang when onPurchasePackageInitiated is not set (iOS) (#1605) via Toni Rico (@tonidero)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.38.0 (#1600) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 5.59.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.59.0)
  * [iOS 5.58.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.58.1)

## RevenueCatUI SDK
### ✨ New Features
* Add custom variables support for paywalls (#1581) via Facundo Menzella (@facumenzella)

## 9.9.0
## RevenueCat SDK
### ✨ New Features
* [SDK-4250] Add webCheckoutUrl to API testers (#1587) via Toni Rico (@tonidero)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.37.0 (#1599) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.21.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.21.0)
  * [Android 9.20.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.20.2)
  * [iOS 5.58.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.58.0)
  * [iOS 5.57.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.57.2)

### 🔄 Other Changes
* Bump qs from 6.14.1 to 6.14.2 in /examples/MagicWeather (#1597) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `e6454e3` to `afc9219` (#1596) via dependabot[bot] (@dependabot[bot])
* Bump faraday from 1.10.4 to 1.10.5 (#1594) via dependabot[bot] (@dependabot[bot])
* Run `pod update` if `pod install` fails in bumping branches (#1591) via Cesar de la Vega (@vegaro)

## 9.8.0
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.33.0 (#1580) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.20.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.20.1)
  * [iOS 5.57.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.57.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.32.0 (#1579) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.20.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.20.1)
  * [iOS 5.57.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.57.1)

## RevenueCatUI SDK
### ✨ New Features
* Add `presentPaywall` web support (#1485) via Toni Rico (@tonidero)

### 🔄 Other Changes
* Bump fastlane from 2.232.0 to 2.232.1 (#1586) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.231.1 to 2.232.0 (#1585) via dependabot[bot] (@dependabot[bot])
* Bump @isaacs/brace-expansion from 5.0.0 to 5.0.1 in /examples/MagicWeather (#1578) via dependabot[bot] (@dependabot[bot])
* Added warning about previous discrepancy in pricePer{Period} APIs to changelog (#1577) via Rick (@rickvdl)
* Bump tar from 7.5.6 to 7.5.7 in /examples/MagicWeather (#1575) via dependabot[bot] (@dependabot[bot])

## 9.7.6
> [!WARNING]
> In previous versions of the SDK, there was a discrepancy in the `pricePer{week/month/year}` StoreProduct APIs between platforms. On iOS, the value was expressed as a decimal number, while on Android it was expressed in micros. As of this release, this discrepancy has been fixed and both platforms now return the value as a decimal number.


## RevenueCat SDK
### 🐞 Bugfixes
* Handle missing log handler when reloading (#1573) via Toni Rico (@tonidero)
* Avoid crash on import when native modules are unavailable (#1559) via Facundo Menzella (@facumenzella)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.31.0 (#1574) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.20.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.20.0)
  * [iOS 5.57.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.57.0)
  * [iOS 5.56.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.56.1)
* [RENOVATE] Update dependency gradle to v9.3.1 (#1569) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Added LeakCanary to Android purchaseTester example app (#1571) via Rick (@rickvdl)

## 9.7.5
## RevenueCat SDK
### 🐞 Bugfixes
* Fix issue in iOS with incorrectly configured event (#1566) via Toni Rico (@tonidero)

## 9.7.4
> [!CAUTION]
> This release can cause crashes on app startup on iOS releases. We ask to update to 9.7.5+ instead
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.30.1 (#1560) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.19.4](https://github.com/RevenueCat/purchases-android/releases/tag/9.19.4)

### 🔄 Other Changes
* Add internal API to debug tracked events (#1562) via Toni Rico (@tonidero)
* Bump tar from 7.5.6 to 7.5.7 (#1561) via dependabot[bot] (@dependabot[bot])
* Add PaywallViewController bugfix to changelog (#1558) via Cesar de la Vega (@vegaro)

## 9.7.3
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.30.0 (#1555) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.19.3](https://github.com/RevenueCat/purchases-android/releases/tag/9.19.3)
  * [iOS 5.56.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.56.0)

## 9.7.2
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.29.0 (#1553) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.19.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.19.2)
  * [iOS 5.55.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.55.3)
  * [iOS 5.55.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.55.2)
* [RENOVATE] Update dependency gradle to v8.14.4 (#1552) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.28.1 (#1546) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.19.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.19.2)
  * [iOS 5.55.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.55.3)
  * [iOS 5.55.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.55.2)
* [RENOVATE] Update dependency gradle to v9.3.0 (#1544) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Update dependencies to solve dependabot alerts (#1551) via Toni Rico (@tonidero)
* Bump lodash from 4.17.21 to 4.17.23 in /examples/MagicWeather (#1550) via dependabot[bot] (@dependabot[bot])
* Bump tar from 7.5.3 to 7.5.6 in /examples/MagicWeather (#1549) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.231.0 to 2.231.1 (#1548) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.230.0 to 2.231.0 (#1545) via dependabot[bot] (@dependabot[bot])
* Bump tar from 7.4.3 to 7.5.3 (#1542) via dependabot[bot] (@dependabot[bot])
* Bump tar from 7.5.2 to 7.5.3 in /examples/MagicWeather (#1543) via dependabot[bot] (@dependabot[bot])

## 9.7.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.28.0 (#1540) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.19.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.19.1)
  * [iOS 5.55.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.55.1)
  * [iOS 5.55.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.55.0)

## 9.7.0
## RevenueCat SDK
### ✨ New Features
* Adds `syncPurchasesForResult` (#1537) via JayShortway (@JayShortway)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.27.1 (#1538) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 5.54.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.54.1)
## RevenueCatUI SDK
### Paywalls
#### 🐞 Bugfixes
* Fix for infinite recursion crash in PaywallViewController (https://github.com/RevenueCat/purchases-ios/pull/6066)

## 9.6.15
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.27.0 (#1535) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.19.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.19.0)
  * [iOS 5.54.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.54.0)
  * [iOS 5.53.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.53.0)
## RevenueCat UI SDK
### Paywalls
#### ✨ New Features
* Add exit offers support

## 9.6.14
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.26.1 (#1533) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.18.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.18.1)
  * [iOS 5.52.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.52.1)

## 9.6.13
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.26.0 (#1531) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 5.52.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.52.0)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `76a3a08` to `e6454e3` (#1530) via dependabot[bot] (@dependabot[bot])

## 9.6.12
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.25.0 (#1528) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.18.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.18.0)
  * [Android 9.17.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.17.1)
  * [Android 9.17.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.17.0)
  * [Android 9.16.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.16.0)
  * [iOS 5.51.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.51.1)
  * [iOS 5.51.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.51.0)

### 🔄 Other Changes
* Bump fastlane from 2.229.1 to 2.230.0 (#1526) via dependabot[bot] (@dependabot[bot])
* Bump aws-sdk-s3 from 1.205.0 to 1.208.0 (#1525) via dependabot[bot] (@dependabot[bot])
* Bump brace-expansion from 1.1.11 to 1.1.12 in /examples/MagicWeather (#1521) via dependabot[bot] (@dependabot[bot])
* Bump node-forge from 1.3.1 to 1.3.2 (#1506) via dependabot[bot] (@dependabot[bot])

## 9.6.11
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.24.0 (#1523) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.15.5](https://github.com/RevenueCat/purchases-android/releases/tag/9.15.5)
  * [Android 9.15.4](https://github.com/RevenueCat/purchases-android/releases/tag/9.15.4)
  * [iOS 5.50.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.50.1)
* [RENOVATE] Update dependency com.android.tools.build:gradle to v8.13.2 (#1522) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Upgrade MagicWeather to RN 0.83 and RC 9.6.10 (#1519) via Jens-Fabian Goetzmann (@jefago)
* Remove unnecessary dependencies from expo sample project (#1520) via Cesar de la Vega (@vegaro)
* Update sample to Expo 54 (#1516) via Cesar de la Vega (@vegaro)
* Bump fastlane-plugin-revenuecat_internal from `efca663` to `76a3a08` (#1518) via dependabot[bot] (@dependabot[bot])
* Updated CircleCI macos executor from m1 to m4 to avoid deprecation (#1517) via Rick (@rickvdl)

## 9.6.10
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.23.0 (#1514) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.15.3](https://github.com/RevenueCat/purchases-android/releases/tag/9.15.3)
  * [Android 9.15.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.15.2)
  * [iOS 5.50.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.50.0)
  * [iOS 5.49.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.49.3)

## 9.6.9
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.21.2 (#1509) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.15.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.15.1)
  * [iOS 5.49.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.49.2)
  * [iOS 5.49.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.49.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.21.1 (#1508) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.15.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.15.1)
  * [iOS 5.49.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.49.2)
  * [iOS 5.49.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.49.1)

## 9.6.8
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.21.0 (#1504) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.15.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.15.0)
  * [Android 9.14.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.14.1)
  * [iOS 5.49.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.49.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.20.0 (#1502) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.15.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.15.0)
  * [Android 9.14.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.14.1)
  * [iOS 5.49.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.49.0)
* [RENOVATE] Update build-dependencies (#1456) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Bump fastlane from 2.229.0 to 2.229.1 (#1503) via dependabot[bot] (@dependabot[bot])
* Bump js-yaml from 3.14.1 to 3.14.2 in /examples/MagicWeather (#1501) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `083ced9` to `efca663` (#1499) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.228.0 to 2.229.0 (#1500) via dependabot[bot] (@dependabot[bot])
* Bump js-yaml from 3.14.1 to 3.14.2 (#1495) via dependabot[bot] (@dependabot[bot])

## 9.6.7
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.19.1 (#1496) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.14.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.14.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.19.0 (#1494) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.14.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.14.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.18.1 (#1491) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.14.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.14.1)

## 9.6.6
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.18.0 (#1487) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.14.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.14.0)
  * [iOS 5.48.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.48.0)
  * [iOS 5.47.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.47.1)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `1e3e3fd` to `083ced9` (#1488) via dependabot[bot] (@dependabot[bot])

## 9.6.5
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.17.0 (#1481) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.13.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.13.0)
  * [iOS 5.47.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.47.0)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `525d48c` to `1e3e3fd` (#1483) via dependabot[bot] (@dependabot[bot])
* Fix running MagicWeather example with `yarn` (#1482) via Antonio Pallares (@ajpallares)

## 9.6.4
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.16.1 (#1478) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 5.46.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.46.3)
  * [iOS 5.46.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.46.2)

## 9.6.3
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 🐞 Bugfixes
* Fix `parseAsWebPurchaseRedemption` always returning the url that was passed (#1470) via Mark Villacampa (@MarkVillacampa)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.16.0 (#1475) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.12.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.12.2)
  * [iOS 5.46.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.46.1)

### 🔄 Other Changes
* Add 9.6.1 to CHANGELOG (#1468) via Toni Rico (@tonidero)

## 9.6.2
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.13.0 (#1466) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.12.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.12.1)
  * [Android 9.12.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.12.0)
  * [iOS 5.46.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.46.0)
  * [iOS 5.45.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.45.1)
  * [iOS 5.45.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.45.0)

## 9.6.1
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 🐞 Bugfixes
* Export WebPurchaseRedemption types (#1463) via Perttu (@plahteenlahti)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.12.0 (#1464) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.12.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.12.0)
  * [iOS 5.45.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.45.0)

### 🔄 Other Changes
* Bump rexml from 3.4.1 to 3.4.2 in /examples/purchaseTesterTypescript (#1460) via dependabot[bot] (@dependabot[bot])

## 9.6.0
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* Updates purchases-hybrid-common to 17.11.0 (#1459) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.11.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.11.0)
  * [Android 9.10.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.10.0)
  * [iOS 5.44.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.44.1)
  * [iOS 5.44.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.44.0)

## RevenueCatUI SDK
### Customer Center
#### ✨ New Features
* Add missing handlers for Customer Center (#1411) via Facundo Menzella (@facumenzella)

### 🔄 Other Changes
* Use Ruby 3.2 for `update-hybrid-common-versions` CI job (#1457) via Antonio Pallares (@ajpallares)
* Bump fastlane-plugin-revenuecat_internal from `25c7fb8` to `525d48c` (#1455) via dependabot[bot] (@dependabot[bot])
* Update Xcode versions to avoid CircleCI deprecation (#1454) via Antonio Pallares (@ajpallares)
* Update React Native to v0.82 and RevenueCat to 9.5.4 (#1452) via Jens-Fabian Goetzmann (@jefago)
* Improve API key validation error for native API key when running on Expo GO (#1447) via Rick (@rickvdl)
* Removed the async keyword from setupPurchases since no async calls are being made (#1451) via Rick (@rickvdl)
* Bump rexml from 3.4.1 to 3.4.2 in /examples/MagicWeather (#1410) via dependabot[bot] (@dependabot[bot])

## 9.5.4
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.10.0 (#1446) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.9.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.9.0)
  * [Android 9.8.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.8.1)
  * [iOS 5.43.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.43.0)
  * [iOS 5.42.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.42.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.9.1 (#1444) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.9.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.9.0)
  * [Android 9.8.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.8.1)
  * [iOS 5.43.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.43.0)
  * [iOS 5.42.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.42.0)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `3f7fffc` to `25c7fb8` (#1445) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `a8770fd` to `3f7fffc` (#1443) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `db640e8` to `a8770fd` (#1441) via dependabot[bot] (@dependabot[bot])

## 9.5.3
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 🐞 Bugfixes
* Fix web targets and expo go (#1439) via Toni Rico (@tonidero)

### 🔄 Other Changes
* Fix Rork support in RevenueCat module (#1438) via Antonio Pallares (@ajpallares)

## 9.5.2
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.9.0 (#1434) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.8.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.8.0)
  * [iOS 5.41.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.41.0)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `e555afb` to `db640e8` (#1435) via dependabot[bot] (@dependabot[bot])
* Update fastlane-plugin-revenuecat_internal to e555afb (#1433) via Cesar de la Vega (@vegaro)
* Add APITests for UI (#1431) via Facundo Menzella (@facumenzella)
* Bump fastlane-plugin-revenuecat_internal from `1593f78` to `7508f17` (#1430) via dependabot[bot] (@dependabot[bot])
* Update changelog for release v8.12.0 (#1429) via Antonio Pallares (@ajpallares)
* [CI] `bump` pipeline action won't trigger `build-test-hold-deploy` workflow (#1423) via Antonio Pallares (@ajpallares)
* Bump fastlane-plugin-revenuecat_internal from `24d8eda` to `1593f78` (#1420) via dependabot[bot] (@dependabot[bot])

## 9.5.1
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.8.0 (#1417) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.7.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.7.2)
  * [Android 9.7.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.7.1)
  * [iOS 5.40.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.40.0)
  * [iOS 5.39.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.39.3)
  * [iOS 5.39.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.39.2)
  * [iOS 5.39.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.39.1)

### 🔄 Other Changes
* Add Rork app detection for preview API mode (#1416) via Antonio Pallares (@ajpallares)
* Add CODEOWNERS (#1415) via Antonio Pallares (@ajpallares)
* Bump fastlane-plugin-revenuecat_internal from `a6dc551` to `24d8eda` (#1414) via dependabot[bot] (@dependabot[bot])

## 9.5.0
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### ✨ New Features
* Implement log handler (#1408) via Antonio Borrero Granell (@antoniobg)

## 9.4.3
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.7.0 (#1406) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.7.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.7.0)
  * [iOS 5.39.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.39.0)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `489faef` to `a6dc551` (#1405) via dependabot[bot] (@dependabot[bot])
* Update bundle dependencies (#1403) via Cesar de la Vega (@vegaro)

## 9.4.2
## RevenueCat SDK
> [!WARNING]
> If you don't have a login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.

### 🐞 Bugfixes
* Fix compilation in 0.81 (#1400) via Cesar de la Vega (@vegaro)

## 9.4.1
## RevenueCat SDK
> [!WARNING]
> If you don't have a login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.

### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.6.0 (#1398) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.6.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.6.0)
  * [iOS 5.38.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.38.2)
  * [iOS 5.38.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.38.1)
  * [iOS 5.38.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.38.0)

### 🔄 Other Changes
* Support simulated store in Expo Go (#1353) via Toni Rico (@tonidero)

## 9.4.0
## RevenueCat SDK
> [!WARNING]
> If you don't have a login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.

### ✨ New Features
* Add override preferred locale methods (#1392) via Antonio Pallares (@ajpallares)
* Support automaticDeviceIdentifierCollectionEnabled when configuring the SDK (#1390) via Toni Rico (@tonidero)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.5.1 (#1394) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.5.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.5.0)
  * [iOS 5.37.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.37.0)
* [RENOVATE] Update dependency com.android.tools.build:gradle to v8.13.0 (#1393) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.5.0 (#1391) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.5.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.5.0)
  * [iOS 5.37.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.37.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.4.0 (#1387) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.5.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.5.0)
  * [iOS 5.37.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.37.0)

## RevenueCatUI SDK
### Customer Center
#### ✨ New Features
* Add support for iOS close button in customer center (#1384) via Facundo Menzella (@facumenzella)

### 🔄 Other Changes
* Passing the PresentedOfferingContext from the Offering to the PHC APIs when navigating to a paywall (#1371) via Rick (@rickvdl)

## 9.3.0
## RevenueCat SDK
> [!WARNING]
> If you don't have a login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.

### ✨ New Features
* Virtual Currency Support for React Native Web (#1378) via Will Taylor (@fire-at-will)
### 🐞 Bugfixes
* Fix `react-native-purchases-ui` preview mode (#1383) via Toni Rico (@tonidero)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.3.0 (#1380) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.4.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.4.0)
  * [iOS 5.36.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.36.0)
* [RENOVATE] Update dependency com.android.tools.build:gradle to v8.12.2 (#1382) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.2.0 (#1379) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.4.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.4.0)
  * [iOS 5.36.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.36.0)
* Updates purchases-hybrid-common to 17.1.0 (#1377) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.4.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.4.0)
  * [iOS 5.36.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.36.0)

## RevenueCatUI SDK
### Customer Center
#### ✨ New Features
* Added custom actions support for customer center (#1370) via Facundo Menzella (@facumenzella)

### 🔄 Other Changes
* Add warning with 9.x issues to all versions since 9.0.0 in CHANGELOG (#1385) via Toni Rico (@tonidero)
* Fix PHC bumping of purchases-js-hybrid-mappings (#1375) via Toni Rico (@tonidero)

## 9.2.3
## RevenueCat SDK
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.

### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.0.0 (#1372) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.3.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.3.2)
  * [Android 9.3.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.3.1)
  * [Android 9.3.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.3.0)
  * [iOS 5.35.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.35.1)
  * [iOS 5.35.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.35.0)
* [RENOVATE] Update dependency com.android.tools.build:gradle to v8.12.1 (#1367) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Bump tmp from 0.2.3 to 0.2.4 (#1355) via dependabot[bot] (@dependabot[bot])

## 9.2.2
## RevenueCat SDK
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.

### 🐞 Bugfixes
* Remove `react-native-get-random-values` dependency temporarily (#1364) via Toni Rico (@tonidero)

## 9.2.1
## RevenueCat SDK
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.

### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 16.2.2 (#1361) via RevenueCat Git Bot (@RCGitBot)
### Customer Center
#### 🐞 Bugfixes
* fix: Support modal navigation to CustomerCenter (#1209) via Facundo Menzella (@facumenzella)

### 🔄 Other Changes
* Update MagicWeather to RN 0.81 (#1357) via Jens-Fabian Goetzmann (@jefago)

## 9.2.0
## RevenueCat SDK
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.

### ✨ New Features
* Add browser support through Web Billing (purchases-js) (#1330) via Toni Rico (@tonidero)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 16.2.0 (#1352) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.2.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.2.0)
  * [iOS 5.34.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.34.0)
* [RENOVATE] Update dependency com.android.tools.build:gradle to v8.12.0 (#1349) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 16.1.0 (#1346) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.2.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.2.0)
  * [iOS 5.34.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.34.0)

### 🔄 Other Changes
* Add warning on CHANGELOG (#1351) via Toni Rico (@tonidero)
* Improve 9.0.0 changelog (#1347) via Toni Rico (@tonidero)

## 9.1.0
## RevenueCat SDK
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.

### ✨ New Features
* Support Virtual Currencies (#1336) via Will Taylor (@fire-at-will)
### 📦 Dependency Updates
* Updates purchases-hybrid-common to 16.0.2 (#1343) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.1.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.1.2)
  * [Android 9.1.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.1.1)
  * [iOS 5.33.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.33.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 16.0.1 (#1338) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.1.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.1.2)
  * [Android 9.1.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.1.1)
  * [iOS 5.33.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.33.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 16.0.0 (#1335) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.1.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.1.2)
  * [Android 9.1.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.1.1)
  * [iOS 5.33.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.33.1)

### 🔄 Other Changes
* getVirtualCurrencies() JSDoc Typo Fix (#1340) via Will Taylor (@fire-at-will)
* Bump nokogiri from 1.18.8 to 1.18.9 (#1339) via dependabot[bot] (@dependabot[bot])

## 9.0.0
## RevenueCat SDK

> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 9.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.

This release updates the SDK to use Google Play Billing Library 8. This version of the Billing Library removed APIs to query for expired subscriptions and consumed one-time products, aside from other improvements. You can check the full list of changes here: https://developer.android.com/google/play/billing/release-notes#8-0-0

Additionally, we've also updated Kotlin to 2.0.21 and our new minimum version is Kotlin 1.8.0+. If you were using an older version of Kotlin, you will need to update it.

#### Play Billing Library 8: No expired subscriptions or consumed one-time products
Play Billing Library 8 removed the ability to query for expired subscriptions and consumed one-time products. This means that the RevenueCat SDK will no longer be able to send purchase information from these purchases. There are 2 cases where this can have an impact:
- If you have consumed one time purchases in Google Play that need to be restored (for example, in order to grant a lifetime entitlement). In these cases, the SDK will not be able to find these purchases and will not be able to restore them and grant the entitlements. This can especially be a problem if you're using anonymous ids and don't have your own account system. Please make sure your products are correctly configured as non-consumables in the RevenueCat dashboard to avoid consuming them in the first place if you intend to make them behave as lifetime purchases.
- (Only relevant if you recently integrated RevenueCat before upgrading to v9, and do not (yet) have all your transactions imported). The SDK will not be able to send purchase information from these expired subscriptions and consumed one time purchases to our backend, so we might miss this data in our customer profile/targeting. We can still ingest historical data from these purchases through a backend historical import. See [docs](https://www.revenuecat.com/docs/migrating-to-revenuecat/migrating-existing-subscriptions). This case doesn't affect developers that have all transactions in RevenueCat, which is true for the vast majority.

#### Using the SDK with your own IAP code (previously Observer Mode)
Using the SDK with your own IAP code is still supported in v9. Other than updating the SDK version, there are no changes required. Just make sure the version of the Play Billing Library is also version 8.0.0+.

### ✨ New features
* Add web target with fake data (#1307) via Toni Rico (@tonidero)

Now, our libraries will work when you try to run your react native app on web. However, they will just respond with hardcoded fakes for now. Full web support will arrive in future releases.

### 💥 Breaking Changes
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 15.0.0 (#1333) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.1.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.1.0)
  * [Android 9.0.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.0.1)
  * [Android 9.0.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.0.0)
  * [iOS 5.33.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.33.0)

### 🔄 Other Changes
* Make hold job wait for tests to pass (#1332) via Cesar de la Vega (@vegaro)

## 8.12.0
## RevenueCat SDK
### 📦 Dependency Updates
* Updates purchases-hybrid-common to 14.3.0 (#1421) via Antonio Pallares (@ajpallares)
  * [Android 8.24.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.24.0)
  * [Android 8.23.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.23.0)
  * [Android 8.22.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.22.1)

### 🔄 Other Changes
* [V8] Pass current version to determine next version action (#1424) via Antonio Pallares (@ajpallares)
* [V8] [CI] `bump` pipeline action won't trigger `deploy` workflow (#1422) via Antonio Pallares (@ajpallares)
* [v8] Bump fastlane-plugin-revenuecat_internal from `7d97553` to `1593f78` (#1418) via Antonio Pallares (@ajpallares)

## 8.11.10
## RevenueCat SDK
### 🐞 Bugfixes
* Fix blank `PaywallView` when using `react-navigation/stack` (#1328) via Cesar de la Vega (@vegaro)
### 📦 Dependency Updates
* [RENOVATE] Update dependency com.android.tools.build:gradle to v8 (#1327) via RevenueCat Git Bot (@RCGitBot)
* [RENOVATE] Update build-dependencies (#1326) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `05ef095` to `7d97553` (#1299) via dependabot[bot] (@dependabot[bot])
* Configure Renovate (#1325) via RevenueCat Git Bot (@RCGitBot)

## 8.11.9
## RevenueCat SDK
### 🐞 Bugfixes
* Fix crash on refresh app on the iOS simulator (#1320) via Antonio Pallares (@ajpallares)
* Per-period prices are now correctly typed as nullable ([purchases-hybrid-common#1195](https://github.com/RevenueCat/purchases-hybrid-common/pull/1195)) via Jay Shortway (@JayShortway)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 14.2.0 (#1323) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.22.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.22.0)
  * [Android 8.21.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.21.0)
  * [iOS 5.32.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.32.0)
  * [iOS 5.31.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.31.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 14.1.0 (#1316) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.22.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.22.0)
  * [Android 8.21.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.21.0)
  * [iOS 5.32.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.32.0)
  * [iOS 5.31.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.31.0)

### 🔄 Other Changes
* Bump danger from 9.5.1 to 9.5.3 (#1312) via dependabot[bot] (@dependabot[bot])

## 8.11.8
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 14.0.2 (#1310) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 5.30.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.30.0)

### 🔄 Other Changes
* Update workflows/issue-notifications.yml@v2 (#1309) via Josh Holtz (@joshdholtz)
* Add GitHub Issue Action Ack (#1306) via Josh Holtz (@joshdholtz)

## 8.11.7
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.38.1 (#1303) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.20.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.20.0)

## 8.11.6
## RevenueCat SDK
### 🐞 Bugfixes
* Force `presentPaywall` to run on main thread (#1301) via Josh Holtz (@joshdholtz)

### 🔄 Other Changes
* chore: update react-native-purchase-ui documentation (#1284) via Perttu (@plahteenlahti)

## 8.11.5
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.37.0 (#1293) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 5.29.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.29.0)

### 🔄 Other Changes
* Update MagicWeather to RN 0.80, remove external dependencies (#1291) via Jens-Fabian Goetzmann (@jefago)

## 8.11.4
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.36.0 (#1289) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 5.28.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.28.1)
  * [iOS 5.28.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.28.0)

## RevenueCatUI SDK
### 🐞 Bugfixes
* Posts request layout in `ComposeViewWrapper` (#1286) via Cesar de la Vega (@vegaro)

### 🔄 Other Changes
* Bump fastlane from 2.227.2 to 2.228.0 (#1287) via dependabot[bot] (@dependabot[bot])

## 8.11.3
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.35.0 (#1281) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.19.2](https://github.com/RevenueCat/purchases-android/releases/tag/8.19.2)
  * [Android 8.19.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.19.1)
  * [iOS 5.27.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.27.1)

## 8.11.2
## RevenueCat SDK
### 🐞 Bugfixes
* Fix `WindowRecomposer` issue in paywall views (#1274) via Cesar de la Vega (@vegaro)

## 8.11.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.33.0 (#1276) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.19.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.19.0)
  * [Android 8.18.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.18.0)
  * [iOS 5.26.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.26.0)
  * [iOS 5.25.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.25.3)
  * [iOS 5.25.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.25.2)
  * [iOS 5.25.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.25.1)
  * [iOS 5.25.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.25.0)

### 🔄 Other Changes
* Better native modules check for Preview API mode in react-native-purchases-ui (#1275) via Antonio Pallares (@ajpallares)

## 8.11.0
## RevenueCat SDK
### ✨ New Features
* Add default log handler (#1271) via Antonio Pallares (@ajpallares)
* Preview API Mode for Expo Go in RevenueCatUI (#1272) via Antonio Pallares (@ajpallares)
* Preview API Mode for Expo Go (#1270) via Antonio Pallares (@ajpallares)

## 8.10.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.32.0 (#1267) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 5.24.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.24.0)

## 8.10.0
## RevenueCat SDK
### ✨ New Features
* Add `getStorefront` API (#1258) via Toni Rico (@tonidero)

## 8.9.7
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.31.0 (#1260) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 5.23.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.23.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.30.0 (#1257) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 5.23.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.23.0)

### 🔄 Other Changes
* Bump fastlane from 2.227.0 to 2.227.2 (#1259) via dependabot[bot] (@dependabot[bot])
* Bump nokogiri from 1.18.4 to 1.18.8 (#1247) via dependabot[bot] (@dependabot[bot])

## 8.9.6
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.29.1 (#1251) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.17.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.17.1)
  * [Android 8.17.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.17.0)
  * [iOS 5.22.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.22.2)
  * [iOS 5.22.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.22.1)
  * [iOS 5.22.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.22.0)

## RevenueCatUI SDK
### 🐞 Bugfixes
* [EXTERNAL] Correctly sets RevenueCatUI podspec platform to `13.0` to fix compatibility issue (#1246) via @rgomezp (#1249) via JayShortway (@JayShortway)

## 8.9.5
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.28.1 (#1243) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.16.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.16.1)
  * [iOS 5.21.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.21.2)
  * [iOS 5.21.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.21.1)

### 🔄 Other Changes
* Update Example app to RN v0.79 (#1240) via Jens-Fabian Goetzmann (@jefago)

## 8.9.4
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.28.0 (#1238) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.16.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.16.0)
  * [iOS 5.21.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.21.0)
  * [iOS 5.20.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.20.3)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.27.0 (#1237) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.16.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.16.0)
  * [iOS 5.21.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.21.0)
  * [iOS 5.20.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.20.3)

### 🔄 Other Changes
* Working updated MagicWeather app (#1233) via Jens-Fabian Goetzmann (@jefago)

## 8.9.3
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.26.1 (#1232) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.15.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.15.1)
  * [iOS 5.20.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.20.2)
  * [iOS 5.20.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.20.1)

## 8.9.2
## RevenueCatUI SDK
### 🐞 Bugfixes
* Fix crash on Paywalls when setting options with null offering (#1225) via Cesar de la Vega (@vegaro)

### 🔄 Other Changes
* Bump nokogiri from 1.18.3 to 1.18.4 (#1222) via dependabot[bot] (@dependabot[bot])

## 8.9.1
## RevenueCatUI SDK
### Customer Center
#### 🐞 Bugfixes
* Fix Typescript definition of onManagementOptionSelected (#1220) via Cesar de la Vega (@vegaro)

## 8.9.0
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.26.0 (#1217) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.15.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.15.0)
  * [Android 8.14.3](https://github.com/RevenueCat/purchases-android/releases/tag/8.14.3)
  * [Android 8.14.2](https://github.com/RevenueCat/purchases-android/releases/tag/8.14.2)
  * [iOS 5.20.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.20.0)

## RevenueCatUI SDK
### Customer Center
#### ✨ New Features
* Add `callbacks` to `presentCustomerCenter` (#1211) via Cesar de la Vega (@vegaro)

## 8.8.2
## RevenueCat SDK
### 🐞 Bugfixes
* Fix get products in iOS (#1216) via Antonio Pallares (@ajpallares)

### 🔄 Other Changes
* Bump fastlane from 2.226.0 to 2.227.0 (#1215) via dependabot[bot] (@dependabot[bot])
* Update fastlane plugin (#1214) via Toni Rico (@tonidero)

## 8.8.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.25.0 (#1210) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.14.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.14.1)
  * [Android 8.14.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.14.0)
  * [iOS 5.19.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.19.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.24.0 (#1207) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.14.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.14.1)
  * [Android 8.14.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.14.0)
  * [iOS 5.19.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.19.0)

## 8.8.0
## RevenueCat SDK
### ✨ New Features
* [EXTERNAL] feat(ios): showManageSubscriptions (#1200) by @dylancom (#1203) via Toni Rico (@tonidero)
### 📦 Dependency Updates
* Bump nokogiri from 1.16.7 to 1.18.3 (#1183) via dependabot[bot] (@dependabot[bot])
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.22.0 (#1202) via RevenueCat Git Bot (@RCGitBot)

## 8.7.0
## RevenueCat SDK
### 🐞 Bugfixes
* Workaround to remove `NSNull` objects in ObjC layer (#1196) via Antonio Pallares (@ajpallares)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.21.0 (#1194) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.13.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.13.0)

## RevenueCatUI SDK
### Customer Center
#### ✨ New Features
* feat: Introduce CustomerCenter (#1184) via Facundo Menzella (@facumenzella)

### 🔄 Other Changes
* Update purchase tester to 0.78.0 (#1193) via Toni Rico (@tonidero)
* Add missing 8.5.2 changelog (#1195) via Toni Rico (@tonidero)

## 8.6.2
## RevenueCat SDK
### 📦 Dependency Updates
* Updates purchases-hybrid-common to 13.19.0 (#1189) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 5.18.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.18.0)
  * [iOS 5.17.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.17.0)

## 8.6.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.18.1 (#1181) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.12.2](https://github.com/RevenueCat/purchases-android/releases/tag/8.12.2)
  * [Android 8.12.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.12.1)

## 8.6.0
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.18.0 (#1177) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.12.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.12.0)
* Bump nanoid from 3.3.7 to 3.3.8 (#1164) via dependabot[bot] (@dependabot[bot])

### 🔄 Other Changes
* [Paywalls V2] Deprecate PaywallFooterContainerView in favor of OriginalTemplatePaywallFooterContainerView (#1172) via Toni Rico (@tonidero)

## 8.5.4
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.17.1 (#1174) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 5.16.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.16.1)

## 8.5.3
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.17.0 (#1170) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.11.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.11.0)
  * [iOS 5.16.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.16.0)
  * [iOS 5.15.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.15.1)
  * [iOS 5.15.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.15.0)
  * [iOS 5.14.6](https://github.com/RevenueCat/purchases-ios/releases/tag/5.14.6)

## 8.5.2
## RevenueCat SDK
### 📦 Dependency Updates
* Updates purchases-hybrid-common to 13.16.2 (#1168) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.11.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.11.0)
  * [iOS 5.15.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.15.0)
  * [iOS 5.14.6](https://github.com/RevenueCat/purchases-ios/releases/tag/5.14.6)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.16.0 (#1165) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.11.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.11.0)
  * [iOS 5.15.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.15.0)
  * [iOS 5.14.6](https://github.com/RevenueCat/purchases-ios/releases/tag/5.14.6)

## 8.5.1
## RevenueCat SDK
### 📦 Dependency Updates
* Updates purchases-hybrid-common to 13.15.2 (#1161) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.10.8](https://github.com/RevenueCat/purchases-android/releases/tag/8.10.8)
  * [Android 8.10.7](https://github.com/RevenueCat/purchases-android/releases/tag/8.10.7)
  * [Android 8.10.6](https://github.com/RevenueCat/purchases-android/releases/tag/8.10.6)
  * [iOS 5.14.5](https://github.com/RevenueCat/purchases-ios/releases/tag/5.14.5)
  * [iOS 5.14.4](https://github.com/RevenueCat/purchases-ios/releases/tag/5.14.4)
  * [iOS 5.14.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.14.3)
  * [iOS 5.14.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.14.2)
  * [iOS 5.14.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.14.1)
* Bump fastlane from 2.225.0 to 2.226.0 (#1157) via dependabot[bot] (@dependabot[bot])

## 8.5.0
## RevenueCat SDK
### ✨ New Features
* Add diagnostics support (#1149) via Toni Rico (@tonidero)
* Support Web Redemption Links (#1145) via Toni Rico (@tonidero)

## 8.4.2
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.13.0 (#1146) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.10.5](https://github.com/RevenueCat/purchases-android/releases/tag/8.10.5)
  * [Android 8.10.4](https://github.com/RevenueCat/purchases-android/releases/tag/8.10.4)
  * [iOS 5.14.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.14.0)
  * [iOS 5.13.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.13.0)

## 8.4.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.12.1 (#1143) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 5.12.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.12.1)

## 8.4.0
## RevenueCat SDK
### ✨ New Features
* Support Kochava and Tenjin integrations (#1138) via Toni Rico (@tonidero)
### 📦 Dependency Updates
* Bump cocoapods from 1.16.1 to 1.16.2 (#1122) via dependabot[bot] (@dependabot[bot])
* Bump cross-spawn from 7.0.3 to 7.0.6 (#1131) via dependabot[bot] (@dependabot[bot])
* Bump rexml from 3.3.6 to 3.3.9 in /examples/MagicWeather (#1137) via dependabot[bot] (@dependabot[bot])

## 8.3.0
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.12.0 (#1136) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.10.3](https://github.com/RevenueCat/purchases-android/releases/tag/8.10.3)
  * [iOS 5.12.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.12.0)
  * [iOS 5.11.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.11.0)
  * [iOS 5.10.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.10.0)
  * [iOS 5.9.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.9.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.11.0 (#1133) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.10.3](https://github.com/RevenueCat/purchases-android/releases/tag/8.10.3)
  * [iOS 5.12.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.12.0)
  * [iOS 5.11.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.11.0)
  * [iOS 5.10.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.10.0)
  * [iOS 5.9.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.9.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.10.0 (#1132) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.10.3](https://github.com/RevenueCat/purchases-android/releases/tag/8.10.3)
  * [iOS 5.12.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.12.0)
  * [iOS 5.11.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.11.0)
  * [iOS 5.10.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.10.0)
  * [iOS 5.9.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.9.0)
### Win-back Offers
#### ✨ New Features
* Support Fetching and Redeeming Win-Back Offers on Custom Paywall (#1134) via Will Taylor (@fire-at-will)

## 8.2.7
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.9.0 (#1128) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.10.2](https://github.com/RevenueCat/purchases-android/releases/tag/8.10.2)
  * [Android 8.10.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.10.1)
  * [Android 8.10.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.10.0)
  * [iOS 5.8.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.8.0)

## 8.2.6
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.8.0 (#1125) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.9.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.9.0)
  * [iOS 5.7.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.7.1)

## 8.2.5
## RevenueCat SDK
### 📦 Dependency Updates
* Bump rexml from 3.3.6 to 3.3.9 in /examples/purchaseTesterTypescript (#1115) via dependabot[bot] (@dependabot[bot])
* Bump cocoapods from 1.15.2 to 1.16.1 (#1119) via dependabot[bot] (@dependabot[bot])
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.7.0 (#1118) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 5.7.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.7.0)
* Bump danger from 9.5.0 to 9.5.1 (#1112) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.224.0 to 2.225.0 (#1111) via dependabot[bot] (@dependabot[bot])

## RevenueCatUI SDK
### 🐞 Bugfixes
* Fix paywall footer dismissal crash (#1120) via Toni Rico (@tonidero)

## 8.2.4
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.5.1 (#1107) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.8.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.8.1)
  * [iOS 5.6.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.6.0)
  * [iOS 5.5.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.5.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.5.0 (#1104) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.8.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.8.1)
  * [iOS 5.6.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.6.0)
  * [iOS 5.5.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.5.0)
* Bump fastlane from 2.223.1 to 2.224.0 (#1103) via dependabot[bot] (@dependabot[bot])

## 8.2.3
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.4.0 (#1097) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.8.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.8.0)
  * [iOS 5.4.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.4.0)
* Bump fastlane from 2.222.0 to 2.223.1 (#1096) via dependabot[bot] (@dependabot[bot])

### 🔄 Other Changes
* Update fastlane plugin (#1099) via Toni Rico (@tonidero)

## 8.2.2
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.3.0 (#1094) via RevenueCat Git Bot (@RCGitBot)

## 8.2.1
## RevenueCat SDK
### 📦 Dependency Updates
* Bump serve-static from 1.15.0 to 1.16.2 (#1090) via dependabot[bot] (@dependabot[bot])
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.2.1 (#1089) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.7.2](https://github.com/RevenueCat/purchases-android/releases/tag/8.7.2)
  * [Android 8.7.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.7.1)
  * [iOS 5.3.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.3.3)
  * [iOS 5.3.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.3.2)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from 5140dbc to 55a0455 (#1091) via Cesar de la Vega (@vegaro)
* Update allowSharingAppStoreAccount deprecation message (#1086) via Will Taylor (@fire-at-will)
* Update fastlane-plugin-revenuecat_internal (#1084) via Cesar de la Vega (@vegaro)

## 8.2.0
### New Features
* Adds pricePerPeriod functions to PurchasesStoreProduct (#1045) via JayShortway (@JayShortway)
### Dependency Updates
* Bump micromatch from 4.0.7 to 4.0.8 (#1079) via dependabot[bot] (@dependabot[bot])
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.2.0 (#1081) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.7.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.7.0)
  * [iOS 5.3.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.3.1)
* Bump rexml from 3.3.3 to 3.3.6 in /examples/MagicWeather (#1078) via dependabot[bot] (@dependabot[bot])
* Bump rexml from 3.3.3 to 3.3.6 in /examples/purchaseTesterTypescript (#1076) via dependabot[bot] (@dependabot[bot])
* Bump rexml from 3.3.3 to 3.3.6 (#1077) via dependabot[bot] (@dependabot[bot])

## 8.1.0
### Bugfixes
* Refine StoreKitVersion logging in configure function (#1068) via Will Taylor (@fire-at-will)
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.1.0 (#1074) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.6.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.6.0)
  * [Android 8.5.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.5.0)
  * [iOS 5.3.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.3.0)
* Bump rexml from 3.2.8 to 3.3.3 in /examples/MagicWeather (#1072) via dependabot[bot] (@dependabot[bot])
* Bump rexml from 3.2.8 to 3.3.3 in /examples/purchaseTesterTypescript (#1066) via dependabot[bot] (@dependabot[bot])
* Bump rexml from 3.2.9 to 3.3.3 (#1065) via dependabot[bot] (@dependabot[bot])
### Other Changes
* Typo fix in v8-MIGRATION.md (#1071) via Will Taylor (@fire-at-will)

## 8.0.1
### Dependency Updates
* Updates purchases-hybrid-common to 13.0.1 (#1063) via Mark Villacampa (@MarkVillacampa)
  * [Android 8.4.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.4.0)
  * [iOS 5.2.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.2.3)
* Bump danger from 9.4.3 to 9.5.0 (#1058) via dependabot[bot] (@dependabot[bot])
* Bump fast-xml-parser from 4.4.0 to 4.4.1 (#1051) via dependabot[bot] (@dependabot[bot])

## 8.0.0
Welcome to version 8.0 of the React Native RevenueCat SDK! A full migration guide can be found [here](https://github.com/RevenueCat/react-native-purchases/blob/66d77607d1ce2f11dcb4954eac8cd5756d0ec211/migrations/v8-MIGRATION.md).

### Breaking Changes

- v8.0 Release (#1050) via Will Taylor (@fire-at-will)

### Dependency Updates

- Bump fastlane from 2.221.1 to 2.222.0 (#1046) via dependabot[bot] (@dependabot[bot])
- Fix ws affected by a DoS (#1043) via Cesar de la Vega (@vegaro)

### Other Changes

- docs: Update installation instructions for Expo (#1041) via Aman Mittal (@amandeepmittal)

## 7.28.1
### Bugfixes
* [EXTERNAL] Make the setProxyURL a promise to wait for the native code to set the proxy URL (#1033) contributed by @dangilbert (#1035) via Toni Rico (@tonidero)
* Setting `proxyURL` should not require configure (#1032) via Cesar de la Vega (@vegaro)

## 7.28.0
### New Features
* Add support for `DEFERRED` upgrades and updates purchases-hybrid-common to 11.1.1 (#1029) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.12.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.12.0)
  * [iOS 4.43.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.43.2)
  * [iOS 4.43.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.43.1)
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 11.0.0 (#1026) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.12.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.12.0)
  * [iOS 4.43.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.43.2)
  * [iOS 4.43.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.43.1)
* Bump fastlane from 2.221.0 to 2.221.1 (#1023) via dependabot[bot] (@dependabot[bot])
* Bump ws from 6.2.2 to 6.2.3 (#1021) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.220.0 to 2.221.0 (#1020) via dependabot[bot] (@dependabot[bot])
### Other Changes
* get_phc_version now also checks PHC UI versions (#1019) via JayShortway (@JayShortway)

## 7.27.4
### Dependency Updates
* Bump braces from 3.0.2 to 3.0.3 (#1015) via dependabot[bot] (@dependabot[bot])
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 10.9.0 (#1014) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.11.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.11.1)
  * [iOS 4.43.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.43.0)
### Other Changes
* [EXTERNAL] Refactor magicweather package item via #1001 @onamfc (#1016) via Toni Rico (@tonidero)

## 7.27.3
### Dependency Updates
* Bump rexml from 3.2.6 to 3.2.8 in /examples/purchaseTesterTypescript (#1010) via dependabot[bot] (@dependabot[bot])
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 10.8.0 (#1012) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.11.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.11.0)
  * [iOS 4.42.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.42.0)

## 7.27.2
### Bugfixes
* Fix `purchaseDiscountedPackage` (#1007) via Cesar de la Vega (@vegaro)
### Dependency Updates
* Bump rexml from 3.2.6 to 3.2.8 (#1004) via dependabot[bot] (@dependabot[bot])
* Bump rexml from 3.2.5 to 3.2.8 in /examples/MagicWeather (#1003) via dependabot[bot] (@dependabot[bot])
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 10.6.2 (#996) via RevenueCat Git Bot (@RCGitBot)
### Other Changes
* Update fastlane plugin (#995) via Toni Rico (@tonidero)

## 7.27.1
### Dependency Updatesa
* BillingClient has been updated to version 6.2.1
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 10.6.1 (#992) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.10.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.10.1)
  * [Android 7.10.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.10.0)
  * [iOS 4.41.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.41.2)
  * [iOS 4.41.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.41.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 10.6.0 (#990) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.10.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.10.1)
  * [Android 7.10.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.10.0)
  * [iOS 4.41.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.41.2)
  * [iOS 4.41.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.41.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 10.5.1 (#988) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.10.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.10.1)
  * [Android 7.10.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.10.0)
  * [iOS 4.41.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.41.2)
  * [iOS 4.41.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.41.1)

## 7.27.0

This release fixes support of react-native-purchases-ui for React Native 0.74 with any architecture.

### Bugfixes
* Fix Footer Paywall in new arch (#980) via Cesar de la Vega (@vegaro)

## 7.26.3
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 10.5.0 (#977) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.9.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.9.0)
  * [iOS 4.41.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.41.0)
* Update to latest fastlane plugin version (#975) via Toni Rico (@tonidero)
### Other Changes
* Update to latest fastlane-plugin-revenuecat_internal (#985) via Cesar de la Vega (@vegaro)
* Update to use M1 CircleCI machines (#983) via Cesar de la Vega (@vegaro)
* Only update docs index on latest stable releases (#972) via Toni Rico (@tonidero)

## 7.26.2
### Bugfixes
* Use ReactContext instead of ThemedReactContext in PaywallFooterViewManager (#971) via Cesar de la Vega (@vegaro)
### Dependency Updates
* Bump tar from 6.2.0 to 6.2.1 (#968) via dependabot[bot] (@dependabot[bot])
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 10.4.1 (#970) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.8.2](https://github.com/RevenueCat/purchases-android/releases/tag/7.8.2)
  * [iOS 4.40.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.40.1)

## 7.26.1
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 10.4.0 (#967) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.40.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.40.0)

## 7.26.0
### New Features
* Add TVOS support for Expo apps (#953) via Cesar de la Vega (@vegaro)
### Dependency Updates
* Bump fastlane from 2.219.0 to 2.220.0 (#964) via dependabot[bot] (@dependabot[bot])

## 7.25.0
### New Features
* Add font support to presentPaywall  (#948) via Cesar de la Vega (@vegaro)
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 10.3.2 (#962) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.8.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.8.1)
  * [Android 7.8.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.8.0)
  * [Android 7.7.3](https://github.com/RevenueCat/purchases-android/releases/tag/7.7.3)
  * [iOS 4.39.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.39.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 10.3.1 (#960) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.8.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.8.1)
  * [Android 7.8.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.8.0)
  * [Android 7.7.3](https://github.com/RevenueCat/purchases-android/releases/tag/7.7.3)
  * [iOS 4.39.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.39.1)
### Other Changes
* Remove usage of RCTEventEmitter in Android (#961) via Cesar de la Vega (@vegaro)
* Fix pod install of sample when updating phc (#954) via Cesar de la Vega (@vegaro)

## 7.24.1
### Bugfixes
* Fix issue with iOS purchaseProduct arguments (#957) via Josh Holtz (@joshdholtz)
### Other Changes
* Remove flipper from tester (#950) via Cesar de la Vega (@vegaro)
* Update Podfile.lock when upgrading phc (#946) via Cesar de la Vega (@vegaro)
* Update changelog to include behavior change (#945) via Cesar de la Vega (@vegaro)
* Fix `generate_docs` (#943) via Cesar de la Vega (@vegaro)
* Add trigger_bump lane (#942) via Cesar de la Vega (@vegaro)

## 7.24.0
### New Features
* Add `displayCloseButton` option to `PaywallView` (#913) via Cesar de la Vega (@vegaro)
  * This changes the behavior of the PaywallView and FooterPaywallView in iOS, which were being dismissed automatically after a successful purchase. After this change, iOS matches existing Android's behavior, in which the `onDismiss` callback will get called whenever the paywall should be dismissed: after the user presses the close button, or after a successful purchase.
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 10.2.0 (#940) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.7.2](https://github.com/RevenueCat/purchases-android/releases/tag/7.7.2)
  * [iOS 4.39.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.39.0)
  * [iOS 4.38.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.38.1)
  * [iOS 4.38.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.38.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 10.1.0 (#938) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.7.2](https://github.com/RevenueCat/purchases-android/releases/tag/7.7.2)
  * [iOS 4.39.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.39.0)
  * [iOS 4.38.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.38.1)
  * [iOS 4.38.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.38.0)
### Other Changes
* Make hotfixes not deploy with the latest tag nor update latest docs (#937) via Toni Rico (@tonidero)
* Update RELEASING.md (#936) via Cesar de la Vega (@vegaro)
* Add 6.7.2 to changelog (#935) via Cesar de la Vega (@vegaro)

## 7.23.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 9.9.0 (#930) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.7.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.7.1)
  * [Android 7.7.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.7.0)
### Other Changes
* Update react native version in purchase tester (#929) via Cesar de la Vega (@vegaro)
* Increase react-native dev dependency version (#928) via Cesar de la Vega (@vegaro)
* Upgrade jest to fix yargs-parser to fix vulnerabilities (#927) via Cesar de la Vega (@vegaro)

## 7.22.0
### New Features
* Add `onRestoreStarted` (#907) via Cesar de la Vega (@vegaro)
* [EXTERNAL] Adding fontFamily from RN to CustomFontProvider in PaywallView (contributed by @Jjastiny) (#916) via Toni Rico (@tonidero)
* Add `onPurchaseStarted` event (#911) via Cesar de la Vega (@vegaro)
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 9.8.0 (#915) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.6.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.6.0)
  * [iOS 4.37.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.37.0)
### Other Changes
* Add some logs on sizing of the PaywallViewWrapper (#921) via Cesar de la Vega (@vegaro)
* Fix iOS caches (#918) via Cesar de la Vega (@vegaro)
* Add `fontFamily` usage to purchase tester (#917) via Toni Rico (@tonidero)

## 7.21.1
### Dependency Updates
* Bump ip from 1.1.8 to 1.1.9 (#909) via dependabot[bot] (@dependabot[bot])
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 9.7.2 (#908) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.5.2](https://github.com/RevenueCat/purchases-android/releases/tag/7.5.2)
  * [iOS 4.36.3](https://github.com/RevenueCat/purchases-ios/releases/tag/4.36.3)
### Other Changes
* Update cocoapods in Gemfile  (#906) via Cesar de la Vega (@vegaro)

## 7.21.0
### New Features
* Add listener functions to views (#887) via Cesar de la Vega (@vegaro)

## 7.20.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 9.7.1 (#903) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.5.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.5.1)
  * [iOS 4.36.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.36.2)
  * [iOS 4.36.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.36.1)
  * [iOS 4.36.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.36.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 9.7.0 (#901) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.5.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.5.1)
  * [iOS 4.36.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.36.2)
  * [iOS 4.36.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.36.1)
  * [iOS 4.36.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.36.0)
* Bump cocoapods from 1.15.1 to 1.15.2 (#900) via dependabot[bot] (@dependabot[bot])
### Other Changes
* Update CHANGELOG to include 6.7.1 release notes (#899) via Toni Rico (@tonidero)

## 7.19.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 9.6.0 (#897) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.5.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.5.0)
  * [iOS 4.35.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.35.0)
  * [iOS 4.34.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.34.0)
* Bump cocoapods from 1.15.0 to 1.15.1 (#895) via dependabot[bot] (@dependabot[bot])
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 9.5.0 (#893) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.5.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.5.0)
  * [iOS 4.35.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.35.0)
  * [iOS 4.34.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.34.0)
* Upgrade purchase tester dependencies to upgrade JSON5 (#889) via Toni Rico (@tonidero)
* Bump danger from 9.4.2 to 9.4.3 (#890) via dependabot[bot] (@dependabot[bot])
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 9.4.0 (#888) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.5.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.5.0)
  * [iOS 4.35.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.35.0)
  * [iOS 4.34.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.34.0)

## 7.18.0
### RevenueCatUI
* Add `offering` option to paywall views (#850) via Cesar de la Vega (@vegaro)
### Bugfixes
* Add xcodeproj to react-native-purchases-ui (#875) via Cesar de la Vega (@vegaro)
* Throw error if null module (#883) via Cesar de la Vega (@vegaro)
* Remove 'new NativeEventEmitter() was called with a non-null argument' (#882) via Cesar de la Vega (@vegaro)
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 9.3.0 (#885) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.4.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.4.1)
  * [iOS 4.33.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.33.0)
  * [iOS 4.32.4](https://github.com/RevenueCat/purchases-ios/releases/tag/4.32.4)
  * [iOS 4.32.3](https://github.com/RevenueCat/purchases-ios/releases/tag/4.32.3)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 9.2.1 (#880) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.4.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.4.1)
  * [iOS 4.33.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.33.0)
  * [iOS 4.32.4](https://github.com/RevenueCat/purchases-ios/releases/tag/4.32.4)
  * [iOS 4.32.3](https://github.com/RevenueCat/purchases-ios/releases/tag/4.32.3)
* Bump cocoapods from 1.14.3 to 1.15.0 (#879) via dependabot[bot] (@dependabot[bot])
### Other Changes
* `purchasePackage`: add `StoreTransaction` in `MakePurchaseResult` (#872) via NachoSoto (@NachoSoto)

## 7.17.1
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 9.2.0 (#873) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.4.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.4.0)
  * [Android 7.3.6](https://github.com/RevenueCat/purchases-android/releases/tag/7.3.6)
  * [iOS 4.32.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.32.2)
### Other Changes
* Update react native devDependency versions (#874) via Cesar de la Vega (@vegaro)

## 7.17.0
### RevenueCatUI
* Fix for footer in lansdcape mode in iOS (#867) via Cesar de la Vega (@vegaro)
* Add Offering option to paywall functions (#855) via Cesar de la Vega (@vegaro)
* `Paywalls`: separate `PurchasesHybridCommonUI` (#858) via NachoSoto (@NachoSoto)
### Bugfixes
* `PaywallViewManager`: added controller to UIVC hierarchy (#860) via Cesar de la Vega (@vegaro)
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 8.12.0 (#862) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.32.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.32.1)
### Other Changes
* Fix `update-hybrid-common-versions` (#865) via NachoSoto (@NachoSoto)
* `RNPaywalls.podspec`: remove `PurchasesHybridCommon` dependency (#864) via NachoSoto (@NachoSoto)
* Add repositories to `purchaseTesterTypescript` android build.gradle (#859) via Cesar de la Vega (@vegaro)
* `Fastlane`: fix `bump_phc_version` (#848) via NachoSoto (@NachoSoto)

## 7.16.1
### RevenueCatUI
* Fix `presentPaywall` and `presentPaywallIfNeeded` in iOS opening the paywall
* ### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 8.11.2 (#854) via RevenueCat Git Bot (@RCGitBot)

## 7.16.0
### RevenueCatUI
* Add `displayCloseButton` parameters to functions (#842) via Cesar de la Vega (@vegaro)
### Dependency Updates
* Updates purchases-hybrid-common to 8.11.1 (#849) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.3.5](https://github.com/RevenueCat/purchases-android/releases/tag/7.3.5)
  * [Android 7.3.4](https://github.com/RevenueCat/purchases-android/releases/tag/7.3.4)
  * [iOS 4.32.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.32.0)
### Other Changes
* Use parameter instead of multiple commands to install yarn dependencies (#843) via Toni Rico (@tonidero)
* Separate yarn caches by machine type (#841) via Toni Rico (@tonidero)

## 7.15.0
### New Features
* 📱 Initial support for cross-platform RevenueCat Paywalls 🐾 🧱  (#837)

### Instructions:
- Update your `package.json` to include `react-native-purchases-ui`:
```json
{
  "dependencies": {
    "react-native-purchases": "7.15.0",
    "react-native-purchases-ui": "7.15.0"
  }
}
```

### Usage:
```javascript
import RevenueCatUI, { PAYWALL_RESULT } from "../react-native-purchases-ui";

async function presentPaywallIfNeeded() {
    const paywallResult: PAYWALL_RESULT = await RevenueCatUI.presentPaywallIfNeeded({
        requiredEntitlementIdentifier: "pro"
    });
}
```

You can find more information in [our documentation](https://www.revenuecat.com/docs/displaying-paywalls#react-native).

## 7.6.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 8.2.1 (#814) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.3.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.3.1)
  * [Android 7.3.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.3.0)
  * [Android 7.2.9](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.9)
  * [Android 7.2.8](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.8)
  * [iOS 4.31.6](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.6)
  * [iOS 4.31.5](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.5)
  * [iOS 4.31.4](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.4)
  * [iOS 4.31.3](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.3)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 8.2.0 (#812) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.3.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.3.1)
  * [Android 7.3.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.3.0)
  * [Android 7.2.9](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.9)
  * [Android 7.2.8](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.8)
  * [iOS 4.31.6](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.6)
  * [iOS 4.31.5](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.5)
  * [iOS 4.31.4](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.4)
  * [iOS 4.31.3](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.3)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 8.1.2 (#806) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.3.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.3.1)
  * [Android 7.3.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.3.0)
  * [Android 7.2.9](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.9)
  * [Android 7.2.8](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.8)
  * [iOS 4.31.6](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.6)
  * [iOS 4.31.5](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.5)
  * [iOS 4.31.4](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.4)
  * [iOS 4.31.3](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.3)
* Bump danger from 9.4.1 to 9.4.2 (#805) via dependabot[bot] (@dependabot[bot])

## 7.5.1
### Dependency Updates
* Bump danger from 9.4.0 to 9.4.1 (#798) via dependabot[bot] (@dependabot[bot])
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 8.1.1 (#802) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.2.7](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.7)
  * [iOS 4.31.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.2)

## 7.5.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 8.1.0 (#800) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.2.6](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.6)
  * [Android 7.2.5](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.5)
  * [iOS 4.31.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.1)
  * [iOS 4.31.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.0)
* Bump cocoapods from 1.14.2 to 1.14.3 (#788) via dependabot[bot] (@dependabot[bot])

## 7.4.0
### New Features
* `Trusted Entitlements`: add support for setting `EntitlementVerificationMode` (#678) via NachoSoto (@NachoSoto)
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 8.0.0 (#790) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.2.4](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.4)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 7.4.0 (#785) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.2.4](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.4)
### Other Changes
* `CI`: disable `prepare-next-version` (#782) via NachoSoto (@NachoSoto)

## 7.3.1
### Dependency Updates
* Bump fastlane from 2.216.0 to 2.217.0 (#780) via dependabot[bot] (@dependabot[bot])
* Bump danger from 9.3.2 to 9.4.0 (#779) via dependabot[bot] (@dependabot[bot])
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 7.3.3 (#778) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.2.3](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.3)
  * [Android 7.2.2](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.2)
  * [Android 7.2.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.1)
  * [iOS 4.30.5](https://github.com/RevenueCat/purchases-ios/releases/tag/4.30.5)
  * [iOS 4.30.4](https://github.com/RevenueCat/purchases-ios/releases/tag/4.30.4)
  * [iOS 4.30.3](https://github.com/RevenueCat/purchases-ios/releases/tag/4.30.3)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 7.3.2 (#776) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 7.3.1 (#769) via RevenueCat Git Bot (@RCGitBot)

### Other Changes
* Update `VERSIONS` with `4.6.3` (#774) via NachoSoto (@NachoSoto)
* Update RevenueCat orb to 2.2.0 (#775) via Cesar de la Vega (@vegaro)

## 7.3.0
### Bugfixes
* Fix purchaseSubscriptionOption not accepting oldProductIdentifier (#764) via Toni Rico (@tonidero)
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 7.3.0 (#765) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.2.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.0)
  * [Android 7.1.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.1.1)
  * [Android 7.1.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.1.0)
  * [Android 7.1.0-beta.2](https://github.com/RevenueCat/purchases-android/releases/tag/7.1.0-beta.2)
  * [Android 7.1.0-beta.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.1.0-beta.1)
  * [iOS 4.30.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.30.2)
  * [iOS 4.30.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.30.1)
  * [iOS 4.30.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.30.0)

## 7.2.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 7.2.0 (#760) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.29.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.29.0)
  * [iOS 4.28.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.28.1)
* Bump cocoapods from 1.14.0 to 1.14.2 (#759) via dependabot[bot] (@dependabot[bot])
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 7.1.1 (#758) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.29.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.29.0)
  * [iOS 4.28.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.28.1)
* Bump cocoapods from 1.13.0 to 1.14.0 (#756) via dependabot[bot] (@dependabot[bot])

## 7.1.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 7.1.0 (#752) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.0.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.0.1)
  * [iOS 4.28.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.28.0)
  * [iOS 4.27.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.27.2)
  * [iOS 4.27.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.27.1)

## 7.0.0
**RevenueCat React Native SDK v7** is here!! 😻

This latest release updates the SDK to use BillingClient 6 in Android. This version of BillingClient brings little change compared with BillingClient 5 which brought an entire new subscription model which resulted in large changes across the entire SDK.

The only modification at the API level involves replacing "ProrationMode" with "ReplacementMode". The specific replacement modes remain unchanged.

If your app doesn't currently use DEFERRED replacement modes, then you should be safe to upgrade to this version without changes in behavior.

If your app supports product changes using [DEFERRED replacement mode](https://www.revenuecat.com/docs/managing-subscriptions#google-play), then you can either stick with the previous major version until support for DEFERRED is re-introduced in this major version, or you can remove DEFERRED replacement options from your app.

If you are using the SDK in observer mode, you should only use v7 in Android if you're using BillingClient 6.

See the [Android Native - 6.x to 7.x Migration](https://github.com/RevenueCat/purchases-android/blob/main/migrations/v7-MIGRATION.md) for more details.

If you come from an older version of the RevenueCat SDK, see [Android Native - 5.x to 6.x Migration](https://www.revenuecat.com/docs/android-native-5x-to-6x-migration) for a more thorough explanation of the new Google subscription model announced with BillingClient 5 and how to take advantage of it.

### Bumped minimum Android SDK version

RevenueCat SDK v7 bumps minimum Android SDK version from Android 4.0 (API level 16) to Android 4.4 (API level 19).

### Support for InApp Messages

We've added new APIs to support InApp messages both in Android and iOS. You can read more about:
* [Google Play InApp Messages](https://rev.cat/googleplayinappmessaging) which will show users a snackbar message during grace period and account hold once per day and provide them an opportunity to fix their payment without leaving the app.
* [App Store InApp messages](https://rev.cat/storekit-message) which will show a modal during grace period once per subscription.

InApp Messages are shown by default in both platforms. If you want to disable this behaviour during configuration of the RevenueCat SDK, setup the `shouldShowInAppMessagesAutomatically` property during configuration to `false`:

```typescript
  Purchases.configure({
    apiKey,
    appUserID,
    observerMode,
    userDefaultsSuiteName,
    usesStoreKit2IfAvailable,
    useAmazon,
    shouldShowInAppMessagesAutomatically
  });
```

### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 7.0.0 and temporarily removes `DEFERRED` proration mode (#747) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.0.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.0.0)
  * [iOS 4.27.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.27.0)
  * [iOS 4.26.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.26.2)
* Bump cocoapods from 1.12.1 to 1.13.0 (#740) via dependabot[bot] (@dependabot[bot])

## 6.7.2
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 6.3.2 (#933) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.9.7](https://github.com/RevenueCat/purchases-android/releases/tag/6.9.7)

## 6.7.1
### Dependency Updates
* Updates purchases-hybrid-common to 6.3.1 (#965)
  * [Android 6.9.6](https://github.com/RevenueCat/purchases-android/releases/tag/6.9.6)

## 6.7.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 6.3.0 (#743) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.9.5](https://github.com/RevenueCat/purchases-android/releases/tag/6.9.5)
  * [iOS 4.26.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.26.1)
  * [iOS 4.26.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.26.0)
  * [iOS 4.25.10](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.10)
  * [iOS 4.26.0-beta.4](https://github.com/RevenueCat/purchases-ios/releases/tag/4.26.0-beta.4)
  * [iOS 4.26.0-beta.3](https://github.com/RevenueCat/purchases-ios/releases/tag/4.26.0-beta.3)
  * [iOS 4.26.0-beta.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.26.0-beta.2)
  * [iOS 4.26.0-beta.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.26.0-beta.1)
* Bump danger from 9.3.1 to 9.3.2 (#737) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.215.1 to 2.216.0 (#736) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.214.0 to 2.215.1 (#734) via dependabot[bot] (@dependabot[bot])

## 6.6.5
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 6.1.2 (#729) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.9.4](https://github.com/RevenueCat/purchases-android/releases/tag/6.9.4)
  * [iOS 4.25.9](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.9)
  * [iOS 4.25.8](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.8)

## 6.6.4
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 6.1.0 (#724) via RevenueCat Git Bot (@RCGitBot)

## 6.6.3
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.6.4 (#719) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.9.3](https://github.com/RevenueCat/purchases-android/releases/tag/6.9.3)
  * [iOS 4.25.7](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.7)
* Bump activesupport from 6.1.7.3 to 6.1.7.6 in /examples/MagicWeather (#718) via dependabot[bot] (@dependabot[bot])
* Bump activesupport from 6.1.7.3 to 6.1.7.6 in /examples/purchaseTesterTypescript (#717) via dependabot[bot] (@dependabot[bot])
* Bump activesupport from 7.0.4.3 to 7.0.7.2 (#716) via dependabot[bot] (@dependabot[bot])
### Other Changes
* Move typescript interfaces to PHC (#684) via Toni Rico (@tonidero)

## 6.6.2
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.6.3 (#713) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.9.2](https://github.com/RevenueCat/purchases-android/releases/tag/6.9.2)
  * [iOS 4.25.6](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.6)
  * [iOS 4.25.5](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.5)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.6.2 (#712) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.9.2](https://github.com/RevenueCat/purchases-android/releases/tag/6.9.2)
  * [iOS 4.25.6](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.6)
  * [iOS 4.25.5](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.5)

## 6.6.1
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.6.1 (#709) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.9.1](https://github.com/RevenueCat/purchases-android/releases/tag/6.9.1)
  * [iOS 4.25.4](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.4)
  * [iOS 4.25.3](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.3)

## 6.6.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.6.0 (#705) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.9.0](https://github.com/RevenueCat/purchases-android/releases/tag/6.9.0)

## 6.5.0
### Bugfixes
* Use correct type in offering metadata (#702) via Toni Rico (@tonidero)
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.5.0 (#699) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.8.0](https://github.com/RevenueCat/purchases-android/releases/tag/6.8.0)
  * [iOS 4.25.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.2)

## 6.4.0
### Bugfixes
* Fix purchaseDiscountedPackage error with missing parameter (#694) via Josh Holtz (@joshdholtz)
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.4.1 (#695) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.7.0](https://github.com/RevenueCat/purchases-android/releases/tag/6.7.0)
  * [Android 6.6.0](https://github.com/RevenueCat/purchases-android/releases/tag/6.6.0)
  * [iOS 4.25.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.1)
  * [iOS 4.25.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.4.0 (#692) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.7.0](https://github.com/RevenueCat/purchases-android/releases/tag/6.7.0)
  * [Android 6.6.0](https://github.com/RevenueCat/purchases-android/releases/tag/6.6.0)
  * [iOS 4.25.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.1)
  * [iOS 4.25.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.0)
* Bump fastlane from 2.213.0 to 2.214.0 (#691) via dependabot[bot] (@dependabot[bot])

## 6.3.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.3.0 (#686) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.24.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.24.1)
  * [iOS 4.24.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.24.0)

## 6.2.3
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.2.4 (#679) via RevenueCat Git Bot (@RCGitBot)

## 6.2.2
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.2.3 (#675) via RevenueCat Git Bot (@RCGitBot)

## 6.2.1
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.2.2 (#671) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.5.2](https://github.com/RevenueCat/purchases-android/releases/tag/6.5.2)
  * [iOS 4.23.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.23.1)

## 6.2.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.2.0 (#666) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.5.1](https://github.com/RevenueCat/purchases-android/releases/tag/6.5.1)
  * [iOS 4.23.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.23.0)
  * [iOS 4.22.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.22.1)

## 6.1.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.1.0 (#662) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.5.0](https://github.com/RevenueCat/purchases-android/releases/tag/6.5.0)
  * [iOS 4.22.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.22.0)
  * [iOS 4.21.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.21.1)
### Other Changes
* Fix V6 migration docs to use correct method name (#661) via Toni Rico (@tonidero)

## 6.0.1
### Bugfixes
* [DENG-418] Accept `GoogleProductChangeInfo` in `purchasePackage` in Android (#657) via Mark Villacampa (@MarkVillacampa)

## 6.0.0
**RevenueCat Purchases React Native v6** is here!! 😻

This latest release updates the Android SDK dependency from v5 to [v6](https://github.com/RevenueCat/purchases-android/releases/tag/6.0.0) to use BillingClient 5. This version of BillingClient brings an entire new subscription model which has resulted in large changes across the entire SDK.

### Migration Guides
- See [Android Native - 5.x to 6.x Migration](https://www.revenuecat.com/docs/android-native-5x-to-6x-migration) for a more thorough explanation of the new Google subscription model announced with BillingClient 5 and how to take advantage of it in V6. This guide includes tips on product setup with the new model.

### New `SubscriptionOption` concept

#### Purchasing
In v5, a Google Play Android `Package` or `StoreProduct` represented a single purchaseable entity, and free trials or intro offers would automatically be applied to the purchase if the user was eligible.

Now, in React Native v6, an Google Play Android `Package` or `StoreProduct` represents a duration of a subscription and contains all the ways to purchase that duration -- any offers and its base plan. Each of these purchase options are `SubscriptionOption`s.
When passing a `Package` to `purchasePackage()` or `StoreProduct` to `purchaseStoreProduct()`, the SDK will use the following logic to choose which `SubscriptionOption` to purchase:
- Filters out offers with "rc-ignore-offer" tag
- Uses `SubscriptionOption` with the longest free trial or cheapest first phase
    - Only offers the user is eligible will be applied
- Falls back to base plan

For more control, purchase subscription options with the new `purchaseSubscriptionOption()` method.

#### Models

`StoreProduct` now has a few new properties use for Google Play Android:
- `defaultOption`
  - A subscription option that will automatically be applie when purchasing a `Package` or `StoreProduct`
- `subscriptionOptions`
  - A list of subscription options (could be null)

### Observer Mode

Observer mode is still supported in v6. Other than updating the SDK version, there are no changes required.

### Offline Entitlements

✨ With this new feature, even if our main and backup servers are down, the SDK can continue to process purchases. This is enabled transparently to the user, and when the servers come back online, the SDK automatically syncs the information so it can be visible in the dashboard.

### Offering Metadata

✨ Metadata allows attaching arbitrary information as key/value pairs to your Offering to control how to display your products inside your app. The metadata you configure in an Offering is available from the RevenueCat SDK. For example, you could use it to remotely configure strings on your paywall, or even URLs of images shown on the paywall.

See the [metadata documentation](https://www.revenuecat.com/docs/offering-metadata) for more info!

## 5.16.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.18.0 (#638) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.21.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.21.0)
  * [iOS 4.19.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.19.1)
  * [iOS 4.20.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.20.0)
* Bump fastlane from 2.212.2 to 2.213.0 (#632) via dependabot[bot] (@dependabot[bot])

## 5.15.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.16.0 (#628) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.19.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.19.0)

## 5.14.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.15.0 (#623) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.18.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.18.0)
### Other Changes
* Update fastlane-plugin-revenuecat version (#622) via Cesar de la Vega (@vegaro)

## 5.13.4
### Dependency Updates
* Bump danger from 9.2.0 to 9.3.0 (#615) via dependabot[bot] (@dependabot[bot])

## 5.13.3
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.14.3 (#612) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.17.11](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.11)
  * [iOS 4.17.10](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.10)
* Bump cocoapods from 1.12.0 to 1.12.1 (#609) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.212.1 to 2.212.2 (#608) via dependabot[bot] (@dependabot[bot])
### Other Changes
* Update `react-native-reanimated` in MagicWeather example app (#610) via Andy Boedo (@aboedo)

## 5.13.2
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.14.2 (#603) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.17.9](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.9)
### Other Changes
* Create v4_to_v5_migration_guide.md (#601) via Andy Boedo (@aboedo)

## 5.13.1
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.14.1 (#587) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.17.8](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.8)
* Bump activesupport from 6.1.7.1 to 6.1.7.3 in /examples/MagicWeather (#582) via dependabot[bot] (@dependabot[bot])
* Bump activesupport from 6.1.7.2 to 6.1.7.3 in /examples/purchaseTesterTypescript (#583) via dependabot[bot] (@dependabot[bot])
* Bump activesupport from 7.0.4.2 to 7.0.4.3 (#584) via dependabot[bot] (@dependabot[bot])

## 5.13.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.14.0 (#578) via RevenueCat Git Bot (@RCGitBot)
  * [Android 5.8.2](https://github.com/RevenueCat/purchases-android/releases/tag/5.8.2)

## 5.12.0
### New Features
* Add `immediateAndChargeFullPrice` proration mode (#574) via Andy Boedo (@aboedo)
### Other Changes
* Deprecate `usesStoreKit2IfAvailable` (#570) via Andy Boedo (@aboedo)

## 5.11.1
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.13.5 (#569) via RevenueCat Git Bot (@RCGitBot)

## 5.11.0
### New Features
* Add `syncObserverModeAmazonPurchase` (#552) via Cesar de la Vega (@vegaro)
### Dependency Updates
* Bump cocoapods from 1.11.3 to 1.12.0 (#566) via dependabot[bot] (@dependabot[bot])
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.13.4 (#565) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.17.7](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.7)
* Bump fastlane from 2.212.0 to 2.212.1 (#564) via dependabot[bot] (@dependabot[bot])
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.13.3 (#561) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.17.7](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.7)

## 5.10.1
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.13.2 (#559) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.17.6](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.6)
* Bump fastlane from 2.211.0 to 2.212.0 (#558) via dependabot[bot] (@dependabot[bot])
### Other Changes
* Reformats files (#553) via Cesar de la Vega (@vegaro)

## 5.10.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.13.1 (#554) via RevenueCat Git Bot (@RCGitBot)
  * [Android 5.7.1](https://github.com/RevenueCat/purchases-android/releases/tag/5.7.1)
  * [iOS 4.17.5](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.5)

## 5.9.0
### New Features
* Adds setLogHandler (#544) via Cesar de la Vega (@vegaro)
* Added `setLogLevel` (#531) via NachoSoto (@NachoSoto)
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.12.1 (#547) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.17.4](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.4)
* Configures dependabot (#541) via Cesar de la Vega (@vegaro)
### Other Changes
* Changes to npm scripts and DEVELOPMENT.md (#546) via Cesar de la Vega (@vegaro)
* Upgrade purchase tester to React Native 0.71.2 (#545) via Cesar de la Vega (@vegaro)

## 5.8.0
### Dependency Updates
* Update gems (#540) via Cesar de la Vega (@vegaro)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.12.0 (#539) via RevenueCat Git Bot (@RCGitBot)
  * [Android 5.7.0](https://github.com/RevenueCat/purchases-android/releases/tag/5.7.0)
  * [iOS 4.17.3](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.3)
### Other Changes
* Change prepublish hook to prepare (#534) via Cesar de la Vega (@vegaro)
* Adds missing docs for PurchasesConfiguration (#528) via Cesar de la Vega (@vegaro)

## 5.7.0
### New Features
* Add latest error codes from native layer to react native (#524) via Toni Rico (@tonidero)
* Add beginRefundRequest APIs for iOS 15+ (#523) via Toni Rico (@tonidero)
* Adds PurchasesStoreProduct.susbcriptionPeriod (#522) via Cesar de la Vega (@vegaro)
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.10.0 (#533) via RevenueCat Git Bot (@RCGitBot)
  * [Android 5.6.7](https://github.com/RevenueCat/purchases-android/releases/tag/5.6.7)
  * [iOS 4.17.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.2)
  * [iOS 4.17.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.1)
  * [iOS 4.17.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.0)
* Bump activesupport from 6.1.4.6 to 6.1.7.1 in /examples/MagicWeather (#529) via dependabot[bot] (@dependabot[bot])
### Other Changes
* `DEVELOPMENT.md`: clarified invocation commands (#527) via NachoSoto (@NachoSoto)
* Fixed `Xcode` spelling (#525) via NachoSoto (@NachoSoto)
* `DEVELOPMENT.md`: replaced `yarn` commands with `npx` (#526) via NachoSoto (@NachoSoto)

## 5.6.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.8.0 (#516) via RevenueCat Git Bot (@RCGitBot)
### Other Changes
* Update Gemfile.lock (#517) via Cesar de la Vega (@vegaro)

## 5.5.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.7.0 (#510) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.16.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.16.0)
### Other Changes
* Adds missing params for better changelogs when bumping (#513) via Cesar de la Vega (@vegaro)
* Update Gemfile.lock (#512) via Cesar de la Vega (@vegaro)
* remove stalebot in favor of SLAs in Zendesk (#509) via Andy Boedo (@aboedo)
* Update fastlane-plugin-revenuecat_internal to latest version (#507) via Cesar de la Vega (@vegaro)

## 5.4.0
### New Features
* Add setFirebaseAppInstanceID, setMixpanelDistinctID, setCleverTapID (#499) via Cesar de la Vega (@vegaro)
### Other Changes
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.5.4 (#504) via RevenueCat Git Bot (@RCGitBot)
* Remove Podfile.locks when running `pods` script (#502) via Cesar de la Vega (@vegaro)

## 5.3.3
### Other Changes
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.5.3 (#498) via RevenueCat Git Bot (@RCGitBot)

## 5.3.2
### Other Changes
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.5.2 (#495) via RevenueCat Git Bot (@RCGitBot)

## 5.3.1
### Other Changes
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.5.1 (#491) via RevenueCat Git Bot (@RCGitBot)

## 5.3.0
### Other Changes
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.5.0 (#488) via RevenueCat Git Bot (@RCGitBot)
* Update typedoc dependency and fix 5.2.3 docs (#484) via Cesar de la Vega (@vegaro)

## 5.2.4
### Other Changes
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.4.4 (#481) via RevenueCat Git Bot (@RCGitBot)

## 5.2.3
### Other Changes
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.4.3 (#478) via RevenueCat Git Bot (@RCGitBot)
* Update typescript version to 4.9.3 (#482) via Cesar de la Vega (@vegaro)

## 5.2.2
### Bugfixes
* Use receivedUpdatedCustomerInfo instead of didReceiveUpdatedCustomerInfo (#473) via Ian Ownbey (@imownbey)

## 5.2.1
### Other Changes
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.4.1 (#470) via RevenueCat Git Bot (@RCGitBot)
* Update Fastlane plugin (#467) via Cesar de la Vega (@vegaro)

## 5.2.0
### Other Changes
* [AUTOMATIC] Updates purchases-hybrid-common to 4.4.0 (#463) via RevenueCat Git Bot (@RCGitBot)

## 5.1.2
### Other Changes
* Update fastlane-plugin-revenuecat_internal (#457) via Cesar de la Vega (@vegaro)
* [AUTOMATIC] Updates purchases-hybrid-common to 4.3.6 (#456) via RevenueCat Git Bot (@RCGitBot)

## 5.1.1
### Other Changes
* bump fastlane plugin to latest version (#452) via Andy Boedo (@aboedo)
* [AUTOMATIC] Updates purchases-hybrid-common to 4.3.2 (#451) via RevenueCat Git Bot (@RCGitBot)
* Adds missing \ via Cesar de la Vega (@vegaro)

## 5.1.0
### Other Changes
* [AUTOMATIC] Updates purchases-hybrid-common to 4.3.1 (#447) via Cesar de la Vega (@vegaro)
* Updated main and MagicWeather README to match purchases-ios (#433) via rglanz-rc (@rglanz-rc)
* Move prepare_next_version job to different workflow (#434) via Toni Rico (@tonidero)
* Switch to main before preparing next release (#432) via Cesar de la Vega (@vegaro)

## 5.0.2
### Other Changes
* Add link to reference docs at the bottom (#426) via Andy Boedo (@aboedo)

## 5.0.1
### Bugfixes
* `presentCodeRedemptionSheet`: fixed Catalyst build (#425) via NachoSoto (@NachoSoto)
* `purchaseProduct` not working when SK2 is enabled (#402)
### Other Changes
* Updated purchases-hybrid-common to 4.2.1
* Configures Danger (#421) via Cesar de la Vega (@vegaro)
* Add link to SDK reference to README (#419) via Jens-Fabian Goetzmann (@jefago)
* Specify branch for deployment dependencies (#418) via Toni Rico (@tonidero)

## 5.0.0
#### Amazon store support
We have introduced support for using the Amazon Store. You can enable Amazon Store support by configuring the SDK using the new configure function:
```
Purchases.configure({ apiKey: "AMAZON_API_KEY", useAmazon: true });
```

For more information around configuration please take a look at the [Amazon Store section in our docs](https://docs.revenuecat.com/docs/amazon-platform-resources). The official [Amazon In-App Purchasing docs](https://developer.amazon.com/docs/in-app-purchasing/iap-overview.html) also contain very valuable information, specially around testing and best practices.

#### Apple AdServices support
New method for automatic collecting of attribution tokens on iOS and macOS using AdServices - `Purchases.enableAdServicesAttributionTokenCollection()`

#### StoreKit 2 support
This version of the SDK automatically uses StoreKit 2 APIs under the hood only for APIs that the RevenueCat team has determined work better than StoreKit 1.

#### New types and cleaned up naming
New types that wrap native types from Apple, Google and Amazon, and we cleaned up the naming of other types and methods for a more consistent experience.

### Removed APIs
- `setUp` has been removed in favor of `configure`
- `configure` now expects an Object for the different parameters. Example:
```javascript
Purchases.configure({
    apiKey: "key",
    appUserID: "user ID",
    observerMode: false,
    userDefaultsSuiteName: "suite name",
    usesStoreKit2IfAvailable: true,
    useAmazon: true
});
```
- `identify` and `createAlias` have been removed in favor of `logIn`.
- `reset` has been removed in favor of `logOut`.
- `addAttributionData` has been removed in favor of `set<NetworkID> methods`.
- `PurchasesStoreProduct`: removed `intro_price_string`, `intro_price_period`, `intro_price_cycles`, `intro_price_period_unit`, `intro_price_period_number_of_units` in favor of new `introPrice: PurchasesIntroPrice`.
- `PurchasesStoreTransaction`: removed `revenueCatId` and `productId` in favor of `transactionIdentifier` and `productIdentifier` respectively.

### Renamed APIs

| 4.x | 5.0.0 |
| :-: | :-: |
| `PurchaserInfo` | `CustomerInfo` |
| `PurchasesProduct` | `PurchasesStoreProduct` |
| `PurchasesStoreProductProduct.price_string` | `PurchasesStoreProductProduct.priceString` |
| `PurchasesStoreProductProduct.currency_code` | `PurchasesStoreProductProduct.currencyCode` |
| `PurchasesTransaction` | `PurchasesStoreTransaction` |
| `PurchasesTransaction.revenueCatId` | `PurchasesStoreTransaction.transactionIdentifier` |
| `PurchasesTransaction.productId` | `PurchasesStoreTransaction.productIdentifier` |
| `PurchasesDiscount` | `PurchasesStoreProductDiscount` |
| `PurchasesPaymentDiscount` | `PurchasesPromotionalOffer` |
| `Purchases.restoreTransactions` | `Purchases.restorePurchases` |
| `Purchases.getPaymentDiscount` | `Purchases.getPromotionalOffer` |
| `Purchases.invalidatePurchaserInfoCache` | `Purchases.invalidateCustomerInfoCache` |
| `Purchases.addPurchaserInfoUpdateListener` | `Purchases.addCustomerInfoUpdateListener` |
| `Purchases.removePurchaserInfoUpdateListener` | `Purchases.removeCustomerInfoUpdateListener` |


## 5.0.0-beta.6

⚠️⚠️ This is a pre-release version. ⚠️⚠️

* Bump purchases-hybrid-common version to 4.1.2 (#408) via Toni Rico (@tonidero)

## 5.0.0-beta.5

⚠️⚠️ This is a pre-release version. ⚠️⚠️

- Bumped purchases-hybrid-common dependency to [4.1.1](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/4.1.1)

## 5.0.0-beta.4

⚠️⚠️ This is a pre-release version. ⚠️⚠️

#### Apple AdServices support
New method for automatic collecting of attribution tokens on iOS and macOS using AdServices - `Purchases.enableAdServicesAttributionTokenCollection()`

#### StoreKit 2 support
This version of the SDK automatically uses StoreKit 2 APIs under the hood only for APIs that the RevenueCat team has determined work better than StoreKit 1.

#### New types and cleaned up naming
New types that wrap native types from Apple, Google and Amazon, and we cleaned up the naming of other types and methods for a more consistent experience.

### Removed APIs
- `setUp` has been removed in favor of `configure`
- `configure` now expects an Object for the different parameters. Example:
```javascript
Purchases.configure({
    apiKey: "key",
    appUserID: "user ID",
    observerMode: false,
    userDefaultsSuiteName: "suite name",
    usesStoreKit2IfAvailable: true,
    useAmazon: true
});
```
- `identify` and `createAlias` have been removed in favor of `logIn`.
- `reset` has been removed in favor of `logOut`.
- `addAttributionData` has been removed in favor of `set<NetworkID> methods`.
- `PurchasesStoreProduct`: removed `intro_price_string`, `intro_price_period`, `intro_price_cycles`, `intro_price_period_unit`, `intro_price_period_number_of_units` in favor of new `introPrice: PurchasesIntroPrice`.

### Renamed APIs

| 4.x | 5.0.0 |
| :-: | :-: |
| `PurchaserInfo` | `CustomerInfo` |
| `PurchasesProduct` | `PurchasesStoreProduct` |
| `PurchasesStoreProductProduct.price_string` | `PurchasesStoreProductProduct.priceString` |
| `PurchasesStoreProductProduct.currency_code` | `PurchasesStoreProductProduct.currencyCode` |
| `PurchasesTransaction` | `PurchasesStoreTransaction` |
| `PurchasesDiscount` | `PurchasesStoreProductDiscount` |
| `PurchasesPaymentDiscount` | `PurchasesPromotionalOffer` |
| `Purchases.restoreTransactions` | `Purchases.restorePurchases` |
| `Purchases.getPaymentDiscount` | `Purchases.getPromotionalOffer` |
| `Purchases.invalidatePurchaserInfoCache` | `Purchases.invalidateCustomerInfoCache` |
| `Purchases.addPurchaserInfoUpdateListener` | `Purchases.addCustomerInfoUpdateListener` |
| `Purchases.removePurchaserInfoUpdateListener` | `Purchases.removeCustomerInfoUpdateListener` |

## 5.0.0-beta.3

⚠️⚠️ This is a pre-release version. ⚠️⚠️

#### StoreKit 2 support
This version of the SDK automatically uses StoreKit 2 APIs under the hood only for APIs that the RevenueCat team has determined work better than StoreKit 1.

#### New types and cleaned up naming
New types that wrap native types from Apple, Google and Amazon, and we cleaned up the naming of other types and methods for a more consistent experience.

### Removed APIs
- `setUp` has been removed in favor of `configure`
- `configure` now expects an Object for the different parameters. Example:
```javascript
Purchases.configure({
    apiKey: "key",
    appUserID: "user ID",
    observerMode: false,
    userDefaultsSuiteName: "suite name",
    usesStoreKit2IfAvailable: true,
    useAmazon: true
});
```
- `identify` and `createAlias` have been removed in favor of `logIn`.
- `reset` has been removed in favor of `logOut`.
- `addAttributionData` has been removed in favor of `set<NetworkID> methods`.
- `PurchasesStoreProduct`: removed `intro_price_string`, `intro_price_period`, `intro_price_cycles`, `intro_price_period_unit`, `intro_price_period_number_of_units` in favor of new `introPrice: PurchasesIntroPrice`.

### Renamed APIs

| 4.x | 5.0.0 |
| :-: | :-: |
| `PurchaserInfo` | `CustomerInfo` |
| `PurchasesProduct` | `PurchasesStoreProduct` |
| `PurchasesStoreProductProduct.price_string` | `PurchasesStoreProductProduct.priceString` |
| `PurchasesStoreProductProduct.currency_code` | `PurchasesStoreProductProduct.currencyCode` |
| `PurchasesTransaction` | `PurchasesStoreTransaction` |
| `PurchasesDiscount` | `PurchasesStoreProductDiscount` |
| `PurchasesPaymentDiscount` | `PurchasesPromotionalOffer` |
| `Purchases.restoreTransactions` | `Purchases.restorePurchases` |
| `Purchases.getPaymentDiscount` | `Purchases.getPromotionalOffer` |
| `Purchases.invalidatePurchaserInfoCache` | `Purchases.invalidateCustomerInfoCache` |
| `Purchases.addPurchaserInfoUpdateListener` | `Purchases.addCustomerInfoUpdateListener` |
| `Purchases.removePurchaserInfoUpdateListener` | `Purchases.removeCustomerInfoUpdateListener` |

## 5.0.0-beta.2

⚠️⚠️ This is a pre-release version. ⚠️⚠️

#### StoreKit 2 support
This version of the SDK automatically uses StoreKit 2 APIs under the hood only for APIs that the RevenueCat team has determined work better than StoreKit 1.

#### New types and cleaned up naming
New types that wrap native types from Apple, Google and Amazon, and we cleaned up the naming of other types and methods for a more consistent experience.

### Removed APIs
- `setUp` has been removed in favor of `configure`
- `identify` and `createAlias` have been removed in favor of `logIn`.
- `reset` has been removed in favor of `logOut`.
- `addAttributionData` has been removed in favor of `set<NetworkID> methods`.
- `PurchasesStoreProduct`: removed `intro_price_string`, `intro_price_period`, `intro_price_cycles`, `intro_price_period_unit`, `intro_price_period_number_of_units` in favor of new `introPrice: PurchasesIntroPrice`.

### Renamed APIs

| 4.x | 5.0.0 |
| :-: | :-: |
| `PurchaserInfo` | `CustomerInfo` |
| `PurchasesProduct` | `PurchasesStoreProduct` |
| `PurchasesStoreProductProduct.price_string` | `PurchasesStoreProductProduct.priceString` |
| `PurchasesStoreProductProduct.currency_code` | `PurchasesStoreProductProduct.currencyCode` |
| `PurchasesTransaction` | `PurchasesStoreTransaction` |
| `PurchasesDiscount` | `PurchasesStoreProductDiscount` |
| `PurchasesPaymentDiscount` | `PurchasesPromotionalOffer` |
| `Purchases.restoreTransactions` | `Purchases.restorePurchases` |
| `Purchases.getPaymentDiscount` | `Purchases.getPromotionalOffer` |
| `Purchases.invalidatePurchaserInfoCache` | `Purchases.invalidateCustomerInfoCache` |
| `Purchases.addPurchaserInfoUpdateListener` | `Purchases.addCustomerInfoUpdateListener` |
| `Purchases.removePurchaserInfoUpdateListener` | `Purchases.removeCustomerInfoUpdateListener` |

## 5.0.0-beta.1

⚠️⚠️ This is a pre-release version. ⚠️⚠️

#### StoreKit 2 support
This version of the SDK automatically uses StoreKit 2 APIs under the hood only for APIs that the RevenueCat team has determined work better than StoreKit 1.

#### New types and cleaned up naming
New types that wrap native types from Apple, Google and Amazon, and we cleaned up the naming of other types and methods for a more consistent experience.

### Removed APIs
- `setUp` has been removed in favor of `configure`
- `identify` and `createAlias` have been removed in favor of `logIn`.
- `reset` has been removed in favor of `logOut`.
- `addAttributionData` has been removed in favor of `set<NetworkID> methods`.
- `PurchasesStoreProduct`: removed `intro_price_string`, `intro_price_period`, `intro_price_cycles`, `intro_price_period_unit`, `intro_price_period_number_of_units` in favor of new `introPrice: PurchasesIntroPrice`.

### Renamed APIs

| 4.x | 5.0.0 |
| :-: | :-: |
| `PurchaserInfo` | `CustomerInfo` |
| `PurchasesProduct` | `PurchasesStoreProduct` |
| `PurchasesStoreProductProduct.price_string` | `PurchasesStoreProductProduct.priceString` |
| `PurchasesStoreProductProduct.currency_code` | `PurchasesStoreProductProduct.currencyCode` |
| `PurchasesTransaction` | `PurchasesStoreTransaction` |
| `PurchasesDiscount` | `PurchasesStoreProductDiscount` |
| `PurchasesPaymentDiscount` | `PurchasesPromotionalOffer` |
| `Purchases.restoreTransactions` | `Purchases.restorePurchases` |
| `Purchases.getPaymentDiscount` | `Purchases.getPromotionalOffer` |
| `Purchases.invalidatePurchaserInfoCache` | `Purchases.invalidateCustomerInfoCache` |
| `Purchases.addPurchaserInfoUpdateListener` | `Purchases.addCustomerInfoUpdateListener` |
| `Purchases.removePurchaserInfoUpdateListener` | `Purchases.removeCustomerInfoUpdateListener` |

### Known issues:
- Amazon support currently doesn't work correctly.

## 4.6.1

- Replaced `jcenter` with `mavenCentral` (https://github.com/RevenueCat/react-native-purchases/pull/369)

## 4.6.0

- Export MakePurchaseResult (https://github.com/RevenueCat/react-native-purchases/pull/351)

## 4.5.3

- Fix warnings regarding `new NativeEventEmitter()` being called without the required `addListener` and `removeListeners` methods, which fixes [this issue](https://github.com/RevenueCat/react-native-purchases/issues/309)

## 4.5.2

- Fix [an issue](https://github.com/RevenueCat/react-native-purchases/issues/328) where calling `checkTrialOrIntroductoryPriceEligibility` could cause a log in prompt
- Bump `purchases-hybrid-common` to 2.0.1. [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/2.0.1)
- Bump `purchases-ios` to 3.14.1. [Changelog here](https://github.com/RevenueCat/purchases-ios/releases/3.14.1))
- Bump `purchases-android` to 4.6.1. [Changelog here](https://github.com/RevenueCat/purchases-android/releases/4.6.1)
    https://github.com/RevenueCat/react-native-purchases/pull/329

## 4.5.1

- Fix Expo 44 compatibility by fixing `RCTEventEmitter` import [PR](https://github.com/RevenueCat/react-native-purchases/commit/75e3c5a99430168fac3a2a28c17238408580fcb3) [Issue](https://github.com/RevenueCat/react-native-purchases/issues/160)

## 4.5.0

This release has some changes that should help prevent "There is no singleton instance" errors [issue](https://github.com/RevenueCat/react-native-purchases/issues/101), [PR](https://github.com/RevenueCat/react-native-purchases/pull/310).
- Added `isConfigured` function to be able to check if the instance of Purchases has been configured before calling any function that accesses the singleton instance.
- These functions that were returning `void`, now return `Promise<void>`:

| Integrations         | Subscriber attributes      | Configuration and other |
| :------------------: | :------------------------: | :----------------------------: |
| `addAttributionData` | `collectDeviceIdentifiers` | `invalidatePurchaserInfoCache` |
| `setAd`              | `setAttributes`            | `presentCodeRedemptionSheet` |
| `setAdGroup`         | `setDisplayName`           | `setAllowSharingStoreAccount` |
| `setAdjustID`        | `setEmail`                 | `setAutomaticAppleSearchAdsAttributionCollection` |
| `setAirshipChannelID`| `setPhoneNumber`           | `setDebugLogsEnabled` |
| `setAppsflyerID`     | `setPushToken`             | `setFinishTransactions` |
| `setCampaign`        |                            | `setSimulatesAskToBuyInSandbox` |
| `setCreative`        |                            | `syncPurchases` |
| `setFBAnonymousID`   |                            |                 |
| `setKeyword`         |                            |                 |
| `setMediaSource`     |                            |                 |
| `setMparticleID`     |                            |                 |
| `setOnesignalID`     |                            |                 |

- Accessing a function that accesses the singleton instance before it has been setup will now reject with a `UninitializedPurchasesError`.

- Bump`purchases-hybrid-common` to `1.11.1` [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/1.10.1)
- Bump `purchases-ios` to `3.13.1` ([Changelog here](https://github.com/RevenueCat/purchases-ios/releases/3.13.1))
- Bump `purchases-android` to `4.6.0` ([Changelog here](https://github.com/RevenueCat/purchases-android/releases/4.6.0))

## 4.4.1

- Fixed declared type in `getAppUserId`
     https://github.com/RevenueCat/react-native-purchases/pull/306

## 4.4.0

- Bump`purchases-hybrid-common` to `1.10.0` [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/1.10.0)
- Bump `purchases-ios` to `3.13.0` ([Changelog here](https://github.com/RevenueCat/purchases-ios/releases/3.13.0))
- Bump `purchases-android` to `4.4.0` ([Changelog here](https://github.com/RevenueCat/purchases-android/releases/4.4.0))
- Added support for Airship integration via `setAirshipChannelID`
     https://github.com/RevenueCat/react-native-purchases/pull/307

## 4.3.3

- Bump `purchases-ios` to 3.12.8
   [3.12.8 Changelog here](https://github.com/RevenueCat/purchases-ios/releases/tag/3.12.8)
   [3.12.7 Changelog here](https://github.com/RevenueCat/purchases-ios/releases/tag/3.12.7)
   [3.12.6 Changelog here](https://github.com/RevenueCat/purchases-ios/releases/tag/3.12.6)
   [3.12.5 Changelog here](https://github.com/RevenueCat/purchases-ios/releases/tag/3.12.5)
   [3.12.4 Changelog here](https://github.com/RevenueCat/purchases-ios/releases/tag/3.12.4)
- Bump `purchases-android` to 4.3.3
   [4.3.3 Changelog here](https://github.com/RevenueCat/purchases-android/releases/tag/4.3.3)
   [4.3.2 Changelog here](https://github.com/RevenueCat/purchases-android/releases/tag/4.3.2)

## 4.3.2

- Fixed return type of `isAnonymous`
    https://github.com/RevenueCat/react-native-purchases/pull/302
- Fix `EntitlementInfo.store` type
    https://github.com/RevenueCat/react-native-purchases/pull/296

## 4.3.1

- Bumped purchases-android to 4.3.1 [Changelog here](https://github.com/RevenueCat/purchases-android/releases/4.3.1),
which fixes canMakePayments not returning (see related issue: https://github.com/RevenueCat/purchases-unity/issues/61)
- Bumped purchases-ios to 3.12.3 [Changelog here](https://github.com/RevenueCat/purchases-ios/releases/tag/3.12.3)
- Bumped purchases-hybrid-common to 1.9.1 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/1.9.1)
- Extracted readableErrorCode to userInfo (https://github.com/RevenueCat/react-native-purchases/pull/268)

## 4.3.0

### Identity V3:

In this version, we’ve redesigned the way that user identification works.
Detailed docs about the new system are available [here](https://docs.revenuecat.com/v3.2/docs/user-ids).

#### New methods
- Introduces `logIn`, a new way of identifying users, which also returns whether a new user has been registered in the system.
`logIn` uses a new backend endpoint.
- Introduces `logOut`, a replacement for `reset`.

#### Deprecations
- deprecates `createAlias` in favor of `logIn`.
- deprecates `identify` in favor of `logIn`.
- deprecates `reset` in favor of `logOut`.
- deprecates `setAllowSharingStoreAccount` in favor of dashboard-side configuration.
    https://github.com/RevenueCat/react-native-purchases/pull/229/

#### Other
- Updated BillingClient to version [4.0.0](https://developer.android.com/google/play/billing/release-notes#4-0).
     https://github.com/RevenueCat/purchases-android/commit/f6554bbf7376c3fd492f0bc67183a9f35889ae78
- Fixed build issues MagicWeather example for Xcode 12.5
    https://github.com/RevenueCat/react-native-purchases/pull/267
- Dependency security updates
    https://github.com/RevenueCat/react-native-purchases/pull/271
    https://github.com/RevenueCat/react-native-purchases/pull/273
- Bumped purchases-ios to 3.12.2 [Changelog here](https://github.com/RevenueCat/purchases-ios/releases/3.12.2)
- Bumped purchases-android to 4.3.0 [Changelog here](https://github.com/RevenueCat/purchases-android/releases/4.3.0)

## 4.2.0

- Add canMakePayments method (https://github.com/RevenueCat/react-native-purchases/pull/244)
- Add PR template (https://github.com/RevenueCat/react-native-purchases/pull/263)

## 4.1.4

- Bumped purchases-hybrid-common to 1.7.1 in Android [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/1.7.1)

## 4.1.3

- Bumped purchases-hybrid-common to 1.7.1 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/1.7.1)
- Bumped purchases-android to 4.2.1 [Changelog here](https://github.com/RevenueCat/purchases-android/releases/4.2.1)

## 4.1.2

- Fix wrong types specified in TypeScript
    https://github.com/RevenueCat/react-native-purchases/pull/231
- Cleaned up directory structure
    https://github.com/RevenueCat/react-native-purchases/pull/235
    https://github.com/RevenueCat/react-native-purchases/pull/237
    https://github.com/RevenueCat/react-native-purchases/pull/232
- Updated example apps dependencies
    https://github.com/RevenueCat/react-native-purchases/pull/240
    https://github.com/RevenueCat/react-native-purchases/pull/239
    https://github.com/RevenueCat/react-native-purchases/pull/233
    https://github.com/RevenueCat/react-native-purchases/pull/227
    https://github.com/RevenueCat/react-native-purchases/pull/226
    https://github.com/RevenueCat/react-native-purchases/pull/234
- Bumped purchases-hybrid-common to 1.6.3 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/1.6.3)
- Bumped purchases-ios to 3.11.1 [Changelog here](https://github.com/RevenueCat/purchases-ios/releases/3.11.1)
    https://github.com/RevenueCat/react-native-purchases/pull/243

## 4.1.1

- Updated example app to the latest React-Native version
    https://github.com/RevenueCat/react-native-purchases/pull/222
- Updated `y18n` version
    https://github.com/RevenueCat/react-native-purchases/pull/227
    https://github.com/RevenueCat/react-native-purchases/pull/226
- Bumped purchases-hybrid-common to 1.6.2 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/1.6.2)
- Bumped purchases-ios to 3.10.7 [Changelog here](https://github.com/RevenueCat/purchases-ios/releases/3.10.7)
- Bumped purchases-android to 4.0.5 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/4.0.5)
    https://github.com/RevenueCat/react-native-purchases/pull/225

## 4.1.0

- Added a new sample project available at `/Examples/WeatherApp`
    https://github.com/RevenueCat/react-native-purchases/pull/212
- iOS:
    - Added a new method `setSimulatesAskToBuyInSandbox`, that allows developers to test deferred purchases easily.
- Bumped purchases-hybrid-common to 1.6.1 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/1.6.1)
- Bumped purchases-ios to 3.10.6 [Changelog here](https://github.com/RevenueCat/purchases-ios/releases/3.10.6)
- Bumped purchases-android to 4.0.4 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/4.0.4)
    https://github.com/RevenueCat/react-native-purchases/pull/216
- Fixed issues with CI builds in Android
    https://github.com/RevenueCat/react-native-purchases/pull/214
    https://github.com/RevenueCat/react-native-purchases/pull/217

## 4.0.1

- Update npm description for better discoverability
    https://github.com/RevenueCat/react-native-purchases/pull/207

## 4.0.0

- removes deprecated `makePurchase`, replaced by `purchaseProduct`
- iOS:
    - added new method, `syncPurchases`, that enables syncing the purchases in the local receipt with the backend without risking a password prompt. The method was already available on Android.
    - added a new method, `presentCodeRedemptionSheet`, for offer codes redemption.
    - Updated `React` dependency to `React-Core` and set `DEFINES_MODULE` to fix issues when building in Xcode 12
- Bumped `purchases-hybrid-common` to 1.5.0 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/1.5.0)
- Bumped `purchases-ios` to 3.9.2 [Changelog here](https://github.com/RevenueCat/purchases-ios/releases/tag/3.9.2)
- Bumped `purchases-android` to 4.0.1 [Changelog here](https://github.com/RevenueCat/purchases-ios/releases/tag/4.0.1)

## 3.4.3

- Bumped common files to 1.4.5 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/1.4.5)
- Bumped iOS SDK to 3.7.5 [Changelog here](https://github.com/RevenueCat/purchases-ios/releases/tag/3.7.5)

## 3.4.2

- Bumped common files to 1.4.4 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/1.4.4)
  - Should include the following Android changes:
  https://github.com/RevenueCat/purchases-android/releases/tag/3.5.2
  https://github.com/RevenueCat/purchases-android/releases/tag/3.5.1

## 3.4.1

- Bumped common files to 1.4.3 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/1.4.3)
- Bumped iOS to 3.7.2 [Changelog here](https://github.com/RevenueCat/purchases-ios/releases/tag/3.7.2)

## 3.4.0

- Removes usage of BuildConfig [#171](https://github.com/RevenueCat/react-native-purchases/pull/171)
- Bumped common files to 1.4.2 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/1.4.2)
- Bumped iOS to 3.7.1 [Changelog here](https://github.com/RevenueCat/purchases-ios/releases/tag/3.7.1)
- Bumped Android to 3.5.0 [Changelog here](https://github.com/RevenueCat/purchases-android/releases/tag/3.5.0)
- Added a new property `nonSubscriptionTransactions` in `PurchaserInfo` to better manage non-subscriptions
- Attribution V2:
 - Deprecated addAttribution in favor of setAdjustId, setAppsflyerId, setFbAnonymousId, setMparticleId.
 - Added support for OneSignal via setOnesignalId
 - Added setMediaSource, setCampaign, setAdGroup, setAd, setKeyword, setCreative, and collectDeviceIdentifiers

## 3.3.3

- Removes usage of BuildConfig [#171](https://github.com/RevenueCat/react-native-purchases/pull/171)
- Bumped common files to 1.3.1 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/1.3.1)
- Bumped iOS to 3.5.1 [Changelog here](https://github.com/RevenueCat/purchases-ios/releases/tag/3.5.1)
- Bumped Android to 3.3.0 [Changelog here](https://github.com/RevenueCat/purchases-android/releases/tag/3.3.0)

## 3.3.2

- Fixes purchaseDiscountedPackage and purchaseDiscountedProduct [#167](https://github.com/RevenueCat/react-native-purchases/pull/167)

## 3.3.1

- Renames setProxyURLString with setProxyURL [#148](https://github.com/RevenueCat/react-native-purchases/pull/148)
- Adds instructions to include the PurchasesHybridCommon framework [#150](https://github.com/RevenueCat/react-native-purchases/pull/150)

## 3.3.0

- Bumped iOS to 3.4.0 [Changelog here](https://github.com/RevenueCat/purchases-ios/releases)
- Bumped Android to 3.2.0 [Changelog here](https://github.com/RevenueCat/purchases-android/releases)
- Added managementURL to PurchaserInfo
- Added setProxyURLString
- Added originalPurchaseDate to PurchaserInfo
- Update invalidatePurchaserInfoCache docs [#137](https://github.com/RevenueCat/react-native-purchases/pull/137)
- Changes the way the common dependency is managed [#144](https://github.com/RevenueCat/react-native-purchases/pull/144) [#145](https://github.com/RevenueCat/react-native-purchases/pull/145)
- Adds new headers for platformFlavor and platformFlavorVersion
- Adds userDefaultsSuiteName as an option when setting up the SDK

## 3.2.0

- Adds Subscriber Attributes, which allow developers to store additional, structured information
for a user in RevenueCat. More info: https://docs.revenuecat.com/docs/user-attributes.

## 3.1.0

- Properly scope Android package [#114](https://github.com/RevenueCat/react-native-purchases/pull/114)
  - ⚠️**IMPORTANT**⚠️: You might need to relink the plugin since the Android package name has changed. All references to `com.reactlibrary.RNPurchasesPackage` in the code should be replace with `com.revenuecat.purchases.react.RNPurchasesPackage`.
- Apply correct array notation: [type] to type[] [#117](https://github.com/RevenueCat/react-native-purchases/pull/117)
- Adds subscription offers support for iOS https://docs.revenuecat.com/docs/ios-subscription-offers
- Introductory Price is now an object inside the PurchasesProduct object

## 3.0.6

- Exports enums

## 3.0.5

- Exports interfaces and types

## 3.0.4

- Renames introEligibilityStatus to status in IntroEligibility

## 3.0.3

- Adds `Purchases.checkTrialOrIntroductoryPriceEligibility`. Note that Android always returns INTRO_ELIGIBILITY_STATUS_UNKNOWN.
- Updates iOS to 3.0.1 and Android to 3.0.4

## 3.0.2

- Adds `Purchases.addShouldPurchasePromoProduct` to be able to handle purchases started from the Apple App Store.

## 3.0.1

- Updates Android SDK to 3.0.3 which should fix issues with restores and syncs.

## 3.0.0

- Support for new Offerings system.
- Deprecates `makePurchase` methods. Replaces with `purchasePackage`
- Deprecates `getEntitlements` method. Replaces with `getOfferings`
- See our migration guide for more info: https://docs.revenuecat.com/v3.0/docs/offerings-migration
- Updates to BillingClient 2.0.3. If finishTransactions is set to false (or observerMode is true when configuring the SDK),
this SDK won't acknowledge any purchase and you have to do it yourself.
- Adds proration mode support on upgrades/downgrades
- Adds more PurchaserInfo missing properties. `activeEntitlements`, `expirationsForActiveEntitlements`
and `purchaseDatesForActiveEntitlements` have been removed from PurchaserInfo
- `intro_price`, `intro_price_period_number_of_units` and `intro_price_cycles` are a number now or null instead of empty
 strings, `intro_price_period_unit` can also be null.
- Added Typescript types (#72)
- New identity changes:
  - The .createAlias() method is no longer required, use .identify() instead
  - .identify() will create an alias if being called from an anonymous ID generated by RevenueCat
  - Added an isAnonymous property to Purchases.sharedInstance
  - Improved offline use


## 2.4.1

- Fixes expirationDate in the EntitlementInfo object in iOS

## 2.4.0

- Deprecates activeEntitlements in PurchaserInfo and adds entitlements object to RCPurchaserInfo. For more info check out https://docs.revenuecat.com/docs/purchaserinfo
- Fixes trial info being lost in Android. Access intro_price in the product information to get information around the trial period.
- Fixes exception when trying to purchase a product that doesn't exist.

## 2.3.4

- Fixes permissions of install scripts

## 2.3.3

- Upgrades Android SDK to https://github.com/RevenueCat/purchases-android/releases/tag/2.3.1

## 2.3.2

- Fixes a bug when normalizing intro_price_period.
- **BREAKING_CHANGE** All `intro_price` related fields in the product are strings, or empty strings if inexistent, in both iOS and Android. There were some discrepancies between platforms released in https://github.com/RevenueCat/react-native-purchases/releases/tag/2.3.0.

## 2.3.1

- Upgrades iOS SDK to https://github.com/RevenueCat/purchases-ios/releases/tag/2.5.0

## 2.3.0

- Upgrades SDKs to iOS https://github.com/RevenueCat/purchases-ios/releases/tag/2.4.0 and Android to https://github.com/RevenueCat/purchases-android/releases/tag/2.3.0.
- Adds Facebook as supported attribution network.
- Adds automatic Apple Search Ads attribution collection. Disabled by default.
- Adds introductory pricing to the iOS product.

## 2.2.2

- Removes wrong import referring to support library instead of androidx.

## 2.2.1

- Removes console.log statement

## 2.2.0

- Updates iOS SDK to 2.3.0. Check out the changelog for a full list of changes https://github.com/RevenueCat/purchases-ios/releases/tag/2.3.0
- Updates Android SDK to 2.2.2. Check out the changelog for a full list of changes https://github.com/RevenueCat/purchases-android/releases/tag/2.2.2
- ** BREAKING CHANGE ** makePurchase parameter oldSKUs is not an array anymore, it only accepts a string now. This is due to changes in the BillingClient.
- AddAttributionData can be called before the SDK has been setup. A network user identifier can be send to the addAttribution function, replacing the previous rc_appsflyer_id parameter.
- Adds an optional configuration boolean observerMode. This will set the value of finishTransactions at configuration time.

### Android only:

- addAttribution will automatically add the rc_gps_adid parameter.
- ** ANDROID BREAKING CHANGE ** Call syncTransactions to send purchases information to RevenueCat after any restore or purchase if you are using the SDK in observerMode. See our guide on Migrating Subscriptions for more information on syncTransactions: https://docs.revenuecat.com/docs/migrating-existing-subscriptions

### iOS only

- addAttribution will automatically add the rc_idfa and rc_idfv parameters if the AdSupport and UIKit frameworks are included, respectively.
- Apple Search Ad attribution can be automatically collected by setting the automaticAttributionCollection boolean to true before the SDK is configured.

## 2.1.2

- Updates iOS SDK to 2.1.1

## 2.1.1

- If using an app ejected from Expo, the Android project wouldn't build since it couldn't find the react-native dependency. This release should fix it.

## 2.1.0

- Updates SDK versions to 2.1.0 to include new error handling
- **BREAKING CHANGE** errors now contain a `userInfo` object with the message, an underlying error and a readable error code. The error codes have completely changed too and updated to the SDK 2.1.0.
- Updates RN and React versions.
- Fixes Windows installation

## 2.0.0

- Updates native SDKs to versions iOS 2.0.0 and Android 2.0.1
- Checks that the user ID sent to setup, identify or create alias is actually a string #28
- BREAKING CHANGE restoreTransactions returns a promise, the RestoreTransactionsListener has been removed
- BREAKING CHANGE makePurchase returns a promise, the PurchaseListener has been removed
- BREAKING CHANGE PurchaserInfoListener has been replaced with PurchaserInfoUpdateListener and it now only sends a purchaser info object. This listener is used to listen to changes in the purchaser info.
- Added support for Tenjin
- BREAKING CHANGE When failure making a purchase, the productIdentifier of the failed purchase is not sent to the rejected promise. Before, the PurchaseListener received both productIdentifier and error objects.
- Added setDebugLogsEnabled to display debug logs.
- Added getPurchaserInfo function to get the latest purchaser info known by the SDK

## 1.5.4

- Removes unnecessary debugger statement https://github.com/RevenueCat/react-native-purchases/issues/47
- Runs Linter and prettifier
- Adds missing setup call in the example

## 1.5.3

- Fix android setup on a null appuserid
- Adds listener removal methods

## 1.5.2

- Changes setIsUsingAnonymousID to allowSharingStoreAccount

## 1.5.1

- Fixes compilation in iOS

## 1.5.0

- Adds create alias, identify and reset

## 1.4.4

- Fixes download script issue

## 1.4.3

- Fixes build issue on the Android bridge

## 1.4.2

- Adds requestDate to the purchaser info to avoid edge cases
