import { NativeEventEmitter, NativeModules } from "react-native";
import {
  PURCHASES_ERROR_CODE,
  UninitializedPurchasesError,
  UnsupportedPlatformError,
  CustomerInfo,
  PurchasesEntitlementInfo,
  PRORATION_MODE,
  PACKAGE_TYPE,
  INTRO_ELIGIBILITY_STATUS,
  PurchasesOfferings,
  PurchasesStoreProduct,
  UpgradeInfo,
  PurchasesPromotionalOffer,
  PurchasesPackage,
  IntroEligibility,
  PurchasesStoreProductDiscount,
  SubscriptionOption,
  PRODUCT_CATEGORY,
  GoogleProductChangeInfo,
  PURCHASE_TYPE,
  BILLING_FEATURE,
  REFUND_REQUEST_STATUS,
  LOG_LEVEL,
  PurchasesConfiguration as BasePurchasesConfiguration,
  CustomerInfoUpdateListener,
  ShouldPurchasePromoProductListener,
  MakePurchaseResult,
  LogHandler,
  LogInResult,
  IN_APP_MESSAGE_TYPE,
  ENTITLEMENT_VERIFICATION_MODE,
  VERIFICATION_RESULT,
  STOREKIT_VERSION,
  PurchasesStoreTransaction,
  PurchasesOffering,
  PURCHASES_ARE_COMPLETED_BY_TYPE,
  PurchasesAreCompletedBy,
  PurchasesAreCompletedByMyApp,
  PurchasesVirtualCurrencies,
  PurchasesWinBackOffer,
  WebPurchaseRedemption,
  WebPurchaseRedemptionResult,
  Storefront,
  STORE_REPLACEMENT_MODE,
  StoreProductChangeInfo,
  BILLING_PLAN_TYPE,
  normalizePurchasesError,
} from "@revenuecat/purchases-typescript-internal";

/**
 * Result of a syncPurchases operation.
 */
export interface SyncPurchasesResult {
  /**
   * The updated customer info after syncing purchases.
   */
  customerInfo: CustomerInfo;
}

import { normalizingRejections } from "./normalizingRejections";
import { shouldUseBrowserMode } from "./utils/environment";
import { browserNativeModuleRNPurchases } from "./browser/nativeModule";

// This export is kept to keep backwards compatibility to any possible users using this file directly
export {
  PURCHASE_TYPE,
  PurchasesAreCompletedBy,
  PurchasesAreCompletedByMyApp,
  PURCHASES_ARE_COMPLETED_BY_TYPE,
  BILLING_FEATURE,
  REFUND_REQUEST_STATUS,
  LOG_LEVEL,
  STOREKIT_VERSION,
  CustomerInfoUpdateListener,
  ShouldPurchasePromoProductListener,
  MakePurchaseResult,
  LogHandler,
  LogInResult,
  WebPurchaseRedemption,
  WebPurchaseRedemptionResult,
  WebPurchaseRedemptionResultType,
} from "@revenuecat/purchases-typescript-internal";

import { Platform } from "react-native";

export interface ConfigurationsByStore {
  PLAY_STORE: {};
}

interface BaseConfiguration extends BasePurchasesConfiguration {}

export type PurchasesConfiguration = {
  [S in keyof ConfigurationsByStore]: BaseConfiguration &
    ConfigurationsByStore[S] &
    (S extends "PLAY_STORE" ? { store?: S } : { store: S })
}[keyof ConfigurationsByStore];

type InternalStoreConfigurationFields = {
  store?: string;
  galaxyBillingMode?: string;
};

const NATIVE_MODULE_ERROR =
  `[RevenueCat] Native module (RNPurchases) not found. This can happen if:\n\n` +
  `- You are running in an environment where native modules are unavailable\n` +
  `- The native module failed to initialize\n` +
  `- The package is not properly linked\n\n` +
  `To fix this:\n` +
  `- If using Expo Go, the SDK works in preview mode but native modules are not available. ` +
  `For full functionality, create a development build: https://docs.expo.dev/develop/development-builds/create-a-build/\n` +
  `- If using bare React Native, run 'pod install' and rebuild the app\n` +
  `- Check that you have rebuilt the app after installing the package\n`;

// Get the native module or use the browser implementation
const usingBrowserMode = shouldUseBrowserMode();
const nativeModule = usingBrowserMode ? browserNativeModuleRNPurchases : NativeModules.RNPurchases;
const RNPurchases = nativeModule ? normalizingRejections(nativeModule) : nativeModule;

// Only create event emitter if native module is available to avoid crash on import
//
// React Native 0.79+ requires native modules to implement addListener() and removeListeners()
// methods for NativeEventEmitter to work. Both iOS and Android native modules now have these.
// See: https://github.com/RevenueCat/react-native-purchases/issues/1298
// See: https://reactnative.dev/blog/2025/04/08/react-native-0.79 (Breaking Changes section)
const eventEmitter = !usingBrowserMode && nativeModule ? new NativeEventEmitter(nativeModule) : null;

// Helper function to check if native module is available - provides better error message than "Cannot read property X of null"
function throwIfNativeModuleNotAvailable(): void {
  if (!RNPurchases) {
    throw new Error(NATIVE_MODULE_ERROR);
  }
}

let customerInfoUpdateListeners: CustomerInfoUpdateListener[] = [];
let shouldPurchasePromoProductListeners: ShouldPurchasePromoProductListener[] =
  [];

let customLogHandler: LogHandler;

/**
 * Represents a tracked feature event from RevenueCatUI.
 * @internal This is a debug API not meant for public use.
 */
export interface TrackedEvent {
  eventDictionary: Record<string, unknown>;
}

/**
 * Listener for tracked feature events.
 * @internal This is a debug API not meant for public use.
 */
export type TrackedEventListener = (event: TrackedEvent) => void;

let trackedEventListeners: TrackedEventListener[] = [];

/**
 * Represents a debug event from RevenueCat.
 * @internal This is a debug API not meant for public use.
 */
export interface DebugEvent {
  eventDictionary: Record<string, unknown>;
}

/**
 * Listener for debug events.
 * @internal This is a debug API not meant for public use.
 */
export type DebugEventListener = (event: DebugEvent) => void;

/**
 * Options for tracking a custom paywall impression.
 */
export interface TrackCustomPaywallImpressionOptions {
  paywallId?: string | null;
  /**
   * The offering associated with the custom paywall.
   *
   * Prefer passing the offering object when available so RevenueCat can track placement
   * and targeting context for placement-resolved offerings.
   */
  offering?: PurchasesOffering | null;
  /**
   * An optional identifier for the offering associated with the custom paywall.
   * If not provided, the SDK will use the current offering identifier from the cache.
   *
   * @deprecated Prefer passing `offering` when available.
   */
  offeringId?: string | null;
}

/**
 * Predefined mediator name constants. Use these or pass any string for unlisted networks.
 */
export const AdMediatorName = {
  adMob: "AdMob",
  appLovin: "AppLovin",
} as const;
export type AdMediatorName = string;

/**
 * Predefined ad format constants. Use these or pass any string for unlisted formats.
 */
export const AdFormat = {
  other: "other",
  banner: "banner",
  interstitial: "interstitial",
  rewarded: "rewarded",
  rewardedInterstitial: "rewarded_interstitial",
  nativeAd: "native",
  appOpen: "app_open",
} as const;
export type AdFormat = string;

/**
 * Predefined precision constants for ad revenue. Use these or pass any string for unlisted values.
 */
export const AdRevenuePrecision = {
  exact: "exact",
  publisherDefined: "publisher_defined",
  estimated: "estimated",
  unknown: "unknown",
} as const;
export type AdRevenuePrecision = string;

/**
 * Identifies the integration that emitted an ad event. Reserved for the
 * official RevenueCat ad-network adapters (for example
 * `react-native-purchases-admob`); leave it unset when tracking manually.
 */
export const AdCaptureMethod = {
  reactNativeAdMobAdapter: "react_native_admob_adapter",
} as const;
export type AdCaptureMethod = string;

export interface AdDisplayedData {
  mediatorName: AdMediatorName;
  adFormat: AdFormat;
  adUnitId: string;
  impressionId: string;
  networkName?: string | null;
  placement?: string | null;
  /** @internal Reserved for the official RevenueCat ad-network adapters. */
  captureMethod?: AdCaptureMethod | null;
}

export interface AdOpenedData {
  mediatorName: AdMediatorName;
  adFormat: AdFormat;
  adUnitId: string;
  impressionId: string;
  networkName?: string | null;
  placement?: string | null;
  /** @internal Reserved for the official RevenueCat ad-network adapters. */
  captureMethod?: AdCaptureMethod | null;
}

export interface AdLoadedData {
  mediatorName: AdMediatorName;
  adFormat: AdFormat;
  adUnitId: string;
  impressionId: string;
  networkName?: string | null;
  placement?: string | null;
  /** @internal Reserved for the official RevenueCat ad-network adapters. */
  captureMethod?: AdCaptureMethod | null;
}

export interface AdRevenueData {
  mediatorName: AdMediatorName;
  adFormat: AdFormat;
  adUnitId: string;
  impressionId: string;
  revenueMicros: number;
  currency: string;
  precision: AdRevenuePrecision;
  networkName?: string | null;
  placement?: string | null;
  /** @internal Reserved for the official RevenueCat ad-network adapters. */
  captureMethod?: AdCaptureMethod | null;
}

export interface AdFailedToLoadData {
  mediatorName: AdMediatorName;
  adFormat: AdFormat;
  adUnitId: string;
  mediatorErrorCode?: number | null;
  placement?: string | null;
  /** @internal Reserved for the official RevenueCat ad-network adapters. */
  captureMethod?: AdCaptureMethod | null;
}

export interface AdRewardEarnedUnverifiedData {
  mediatorName: AdMediatorName;
  adFormat: AdFormat;
  adUnitId: string;
  impressionId: string;
  networkName?: string | null;
  placement?: string | null;
  /** @internal Reserved for the official RevenueCat ad-network adapters. */
  captureMethod?: AdCaptureMethod | null;
}

export interface AdRewardPromptShownData {
  mediatorName: AdMediatorName;
  adUnitId: string;
  placement?: string | null;
}

export interface AdRewardPromptAcceptedData {
  mediatorName: AdMediatorName;
  adUnitId: string;
  placement?: string | null;
}

/**
 * Token generated for a rewarded ad impression. Pass `clientTransactionId` to
 * the ad network as server-side verification custom data, then to
 * {@link Purchases.pollRewardVerification} to await the reward.
 */
export interface RewardVerificationToken {
  customData: string;
  clientTransactionId: string;
  appUserID: string;
}

/**
 * A reward granted after a verified rewarded ad. Discriminated by `type`.
 */
export type VerifiedReward =
  | VerifiedVirtualCurrencyReward
  | VerifiedEntitlementReward
  | VerifiedNoReward
  | VerifiedUnsupportedReward;

export interface VerifiedVirtualCurrencyReward {
  type: "virtual_currency";
  code: string;
  amount: number;
}

export interface VerifiedEntitlementReward {
  type: "entitlement";
  identifier: string;
  /** ISO 8601 expiration date string. */
  expiresAt: string;
  /** Expiration date in milliseconds since epoch. */
  expiresAtMillis: number;
}

/** Verification completed but nothing was granted. */
export interface VerifiedNoReward {
  type: "no_reward";
}

/** Verification completed but the reward type isn't modeled by this SDK version. */
export interface VerifiedUnsupportedReward {
  type: "unsupported_reward";
}

/**
 * Result of polling for reward verification.
 */
export interface RewardVerificationResult {
  /** The primary reward when verification succeeded; absent on failure. */
  reward?: VerifiedReward;
  /** Additional rewards granted alongside the primary; never repeats it; empty on failure. */
  moreRewards: VerifiedReward[];
  /** True when verification did not complete (rejected / timeout / network). */
  failed: boolean;
}

/**
 * Ad metadata for a rewarded ad, passed to {@link Purchases.pollRewardVerification}
 * to have the SDK automatically track reward-verification events for it.
 */
export interface RewardedAdTrackingMetadata {
  mediatorName: AdMediatorName;
  adFormat: AdFormat;
  adUnitId: string;
  impressionId: string;
  networkName?: string | null;
  placement?: string | null;
  /** @internal Reserved for the official RevenueCat ad-network adapters. */
  captureMethod?: AdCaptureMethod | null;
}

let debugEventListeners: DebugEventListener[] = [];

eventEmitter?.addListener(
  "Purchases-CustomerInfoUpdated",
  (event: unknown) => {
    const customerInfo = event as CustomerInfo;
    customerInfoUpdateListeners.forEach((listener) => listener(customerInfo));
  }
);

eventEmitter?.addListener(
  "Purchases-ShouldPurchasePromoProduct",
  (event: unknown) => {
    const { callbackID } = event as { callbackID: number };
    shouldPurchasePromoProductListeners.forEach((listener) =>
      listener(() => RNPurchases.makeDeferredPurchase(callbackID))
    );
  }
);

eventEmitter?.addListener(
  "Purchases-LogHandlerEvent",
  (event: unknown) => {
    const { logLevel, message } = event as {
      logLevel: LOG_LEVEL;
      message: string;
    };
    if (customLogHandler) {
      const logLevelEnum = LOG_LEVEL[logLevel];
      customLogHandler(logLevelEnum, message);
    }
  }
);

eventEmitter?.addListener(
  "Purchases-TrackedEvent",
  (event: unknown) => {
    const eventDictionary = event as Record<string, unknown>;
    trackedEventListeners.forEach((listener) => listener({ eventDictionary }));
  }
);

eventEmitter?.addListener(
  "Purchases-DebugEvent",
  (event: unknown) => {
    const eventDictionary = event as Record<string, unknown>;
    debugEventListeners.forEach((listener) => listener({ eventDictionary }));
  }
);

async function throwIfNotConfigured() {
  const isConfigured = await Purchases.isConfigured();
  if (!isConfigured) {
    throw new UninitializedPurchasesError();
  }
}

export default class Purchases {
  /**
   * Supported SKU types.
   * @readonly
   * @enum {string}
   * @deprecated, use PRODUCT_CATEGORY
   */
  public static PURCHASE_TYPE = PURCHASE_TYPE;

  /**
   * Supported product categories.
   * @readonly
   * @enum {string}
   */
  public static PRODUCT_CATEGORY = PRODUCT_CATEGORY;

  /**
   * Enum for billing features.
   * Currently, these are only relevant for Google Play Android users:
   * https://developer.android.com/reference/com/android/billingclient/api/BillingClient.FeatureType
   * @readonly
   * @enum {string}
   */
  public static BILLING_FEATURE = BILLING_FEATURE;

  /**
   * Enum with possible return states for beginning refund request.
   * @readonly
   * @enum {string}
   */
  public static REFUND_REQUEST_STATUS = REFUND_REQUEST_STATUS;

  /**
   * Replace SKU's ProrationMode.
   * @readonly
   * @enum {number}
   * @deprecated, use STORE_REPLACEMENT_MODE
   */
  public static PRORATION_MODE = PRORATION_MODE;

  /**
   * Replacement modes for use when changing products.
   * @readonly
   * @enum {string}
   */
  public static STORE_REPLACEMENT_MODE = STORE_REPLACEMENT_MODE;

  /**
   * Enumeration of all possible Package types.
   * @readonly
   * @enum {string}
   */
  public static PACKAGE_TYPE = PACKAGE_TYPE;

  /**
   * Enum of billing plan types for subscriptions with billing plans on iOS.
   * @readonly
   * @enum {string}
   */
  public static BILLING_PLAN_TYPE = BILLING_PLAN_TYPE;

  /**
   * Enum of different possible states for intro price eligibility status.
   * @readonly
   * @enum {number}
   */
  public static INTRO_ELIGIBILITY_STATUS = INTRO_ELIGIBILITY_STATUS;

  /**
   * Enum of all error codes the SDK produces.
   * @readonly
   * @enum {string}
   */
  public static PURCHASES_ERROR_CODE = PURCHASES_ERROR_CODE;

  /**
   * List of valid log levels.
   * @readonly
   * @enum {string}
   */
  public static LOG_LEVEL = LOG_LEVEL;

  /**
   * List of valid in app message types.
   * @readonly
   * @enum {number}
   */
  public static IN_APP_MESSAGE_TYPE = IN_APP_MESSAGE_TYPE;

  /**
   * Enum of entitlement verification modes.
   * @readonly
   * @enum {string}
   */
  public static ENTITLEMENT_VERIFICATION_MODE = ENTITLEMENT_VERIFICATION_MODE;

  /**
   * The result of the verification process.
   * @readonly
   * @enum {string}
   */
  public static VERIFICATION_RESULT = VERIFICATION_RESULT;

  /**
   * Enum of StoreKit version.
   * @readonly
   * @enum {string}
   */
  public static STOREKIT_VERSION = STOREKIT_VERSION;

  /**
   * Enum of PurchasesAreCompletedByType.
   * @readonly
   * @enum {string}
   */
  public static PURCHASES_ARE_COMPLETED_BY_TYPE =
    PURCHASES_ARE_COMPLETED_BY_TYPE;

  public static UninitializedPurchasesError = UninitializedPurchasesError;

  public static UnsupportedPlatformError = UnsupportedPlatformError;

  /**
   * Sets up Purchases with your API key and an app user id.
   * @param {String} apiKey RevenueCat API Key. Needs to be a String
   * @param {String?} appUserID An optional unique id for identifying the user. Needs to be a string.
   * @param {PurchasesAreCompletedBy} [purchasesAreCompletedBy=PURCHASES_ARE_COMPLETED_BY_TYPE.REVENUECAT] Set this to an instance of PurchasesAreCompletedByMyApp if you have your own IAP implementation and want to use only RevenueCat's backend. Default is PURCHASES_ARE_COMPLETED_BY_TYPE.REVENUECAT.
   * @param {STOREKIT_VERSION} [storeKitVersion=DEFAULT] iOS-only. Defaults to STOREKIT_2. StoreKit 2 is only available on iOS 16+. StoreKit 1 will be used for previous iOS versions regardless of this setting.
   * @param {ENTITLEMENT_VERIFICATION_MODE} [entitlementVerificationMode=ENTITLEMENT_VERIFICATION_MODE.DISABLED] Sets the entitlement verifciation mode to use. For more details, check https://rev.cat/trusted-entitlements
   * @param {boolean} [useAmazon=false] An optional boolean. Android-only. Set this to true to enable Amazon on compatible devices.
   * @param {String?} userDefaultsSuiteName An optional string. iOS-only, will be ignored for Android.
   * Set this if you would like the RevenueCat SDK to store its preferences in a different NSUserDefaults suite, otherwise it will use standardUserDefaults.
   * Default is null, which will make the SDK use standardUserDefaults.
   * @param {boolean} [pendingTransactionsForPrepaidPlansEnabled=false] An optional boolean. Android-only. Set this to true to enable pending transactions for prepaid subscriptions in Google Play.
   * @param {boolean} [diagnosticsEnabled=false] An optional boolean. Set this to true to enable SDK diagnostics.
   * @param {boolean} [automaticDeviceIdentifierCollectionEnabled=true] An optional boolean. Set this to true to allow the collection of identifiers when setting the identifier for an attribution network.
   * @param {String?} [preferredUILocaleOverride] An optional string. Set this to the preferred UI locale to use for RevenueCat UI components.
   * @param {boolean} [useExternalPurchaseCustomLinks=false] Experimental. An optional boolean. iOS-only. Set this to true to make web purchase buttons that open in the external browser go through Apple's external purchase custom link flow.
   * @param {boolean} [enableExternalPurchasesInSimulator=true] Experimental. An optional boolean. iOS-only. Set this to false to make the simulator behave as a device does for a customer who is not eligible for external purchases.
   *
   * @warning If you use purchasesAreCompletedBy=PurchasesAreCompletedByMyApp, you must also provide a value for storeKitVersion.
   */
  public static configure(configuration: PurchasesConfiguration): void {
    const {
    apiKey,
    appUserID = null,
    purchasesAreCompletedBy = PURCHASES_ARE_COMPLETED_BY_TYPE.REVENUECAT,
    userDefaultsSuiteName,
    storeKitVersion = STOREKIT_VERSION.DEFAULT,
    useAmazon = false,
    shouldShowInAppMessagesAutomatically = true,
    entitlementVerificationMode = ENTITLEMENT_VERIFICATION_MODE.DISABLED,
    pendingTransactionsForPrepaidPlansEnabled = false,
    diagnosticsEnabled = false,
    automaticDeviceIdentifierCollectionEnabled = true,
    preferredUILocaleOverride,
    useExternalPurchaseCustomLinks = false,
    enableExternalPurchasesInSimulator = true,
    } = configuration;
    const {
      store,
      galaxyBillingMode,
    } = configuration as PurchasesConfiguration & InternalStoreConfigurationFields;

    throwIfNativeModuleNotAvailable();

    if (!customLogHandler) {
      this.setLogHandler((logLevel: LOG_LEVEL, message: string) => {
        switch (logLevel) {
          case LOG_LEVEL.DEBUG:
            // tslint:disable-next-line:no-console
            console.debug(`[RevenueCat] ${message}`);
            break;
          case LOG_LEVEL.INFO:
            // tslint:disable-next-line:no-console
            console.info(`[RevenueCat] ${message}`);
            break;
          case LOG_LEVEL.WARN:
            // tslint:disable-next-line:no-console
            console.warn(`[RevenueCat] ${message}`);
            break;
          case LOG_LEVEL.ERROR:
            // tslint:disable-next-line:no-console
            console.error(`[RevenueCat] ${message}`);
            break;
          default:
            // tslint:disable-next-line:no-console
            console.log(`[RevenueCat] ${message}`);
        }
      });
    }

    if (apiKey === undefined || typeof apiKey !== "string") {
      throw new Error(
        'Invalid API key. It must be called with an Object: configure({apiKey: "key"})'
      );
    }

    if (
      appUserID !== null &&
      typeof appUserID !== "undefined" &&
      typeof appUserID !== "string"
    ) {
      throw new Error("appUserID needs to be a string");
    }

    let purchasesCompletedByToUse: PURCHASES_ARE_COMPLETED_BY_TYPE =
      PURCHASES_ARE_COMPLETED_BY_TYPE.REVENUECAT;
    let storeKitVersionToUse = storeKitVersion;

    if (Purchases.isPurchasesAreCompletedByMyApp(purchasesAreCompletedBy)) {
      purchasesCompletedByToUse = PURCHASES_ARE_COMPLETED_BY_TYPE.MY_APP;
      storeKitVersionToUse = purchasesAreCompletedBy.storeKitVersion;

      if (
        storeKitVersion !== STOREKIT_VERSION.DEFAULT &&
        storeKitVersionToUse !== storeKitVersion
      ) {
        // Typically, console messages aren't used in TS libraries, but in this case it's worth calling out the difference in
        // StoreKit versions, and since the difference isn't possible farther down the call chain, we should go ahead
        // and log it here.
        // tslint:disable-next-line:no-console
        console.warn(
          "Warning: The storeKitVersion in purchasesAreCompletedBy does not match the function's storeKitVersion parameter. We will use the value found in purchasesAreCompletedBy."
        );
      }

      if (storeKitVersionToUse === STOREKIT_VERSION.DEFAULT) {
        // tslint:disable-next-line:no-console
        console.warn(
          "Warning: You should provide the specific StoreKit version you're using in your implementation when configuring PURCHASES_ARE_COMPLETED_BY_TYPE.MY_APP, and not rely on the DEFAULT."
        );
      }
    }

    RNPurchases.setupPurchases(
      apiKey,
      appUserID,
      purchasesCompletedByToUse,
      userDefaultsSuiteName,
      storeKitVersionToUse,
      useAmazon,
      store,
      galaxyBillingMode,
      shouldShowInAppMessagesAutomatically,
      entitlementVerificationMode,
      pendingTransactionsForPrepaidPlansEnabled,
      diagnosticsEnabled,
      automaticDeviceIdentifierCollectionEnabled,
      preferredUILocaleOverride,
      useExternalPurchaseCustomLinks,
      enableExternalPurchasesInSimulator,
    );
  }

  /**
   * @deprecated, configure behavior through the RevenueCat dashboard (app.revenuecat.com) instead.
   * If an user tries to purchase a product that is active on the current app store account,
   * we will treat it as a restore and alias the new ID with the previous id.
   * If you have configured the Legacy restore behavior in the RevenueCat dashboard
   * and are currently setting this to true, keep this setting active.
   * @param {boolean} allowSharing Set this to true if you are passing in an appUserID but it is anonymous,
   * this is true by default if you didn't pass an appUserID
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet.
   */
  public static async setAllowSharingStoreAccount(
    allowSharing: boolean
  ): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setAllowSharingStoreAccount(allowSharing);
  }

  /**
   * iOS only.
   * @param {boolean} simulatesAskToBuyInSandbox Set this property to true *only* when testing the ask-to-buy / SCA
   * purchases flow. More information: http://errors.rev.cat/ask-to-buy
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet.
   */
  public static async setSimulatesAskToBuyInSandbox(
    simulatesAskToBuyInSandbox: boolean
  ): Promise<void> {
    if (Platform.OS === "ios") {
      RNPurchases.setSimulatesAskToBuyInSandbox(simulatesAskToBuyInSandbox);
    }
  }

  /**
   * Sets a function to be called on updated customer info
   * @param {CustomerInfoUpdateListener} customerInfoUpdateListener CustomerInfo update listener
   */
  public static addCustomerInfoUpdateListener(
    customerInfoUpdateListener: CustomerInfoUpdateListener
  ): void {
    if (typeof customerInfoUpdateListener !== "function") {
      throw new Error("addCustomerInfoUpdateListener needs a function");
    }
    customerInfoUpdateListeners.push(customerInfoUpdateListener);
  }

  /**
   * Removes a given CustomerInfoUpdateListener
   * @param {CustomerInfoUpdateListener} listenerToRemove CustomerInfoUpdateListener reference of the listener to remove
   * @returns {boolean} True if listener was removed, false otherwise
   */
  public static removeCustomerInfoUpdateListener(
    listenerToRemove: CustomerInfoUpdateListener
  ): boolean {
    if (customerInfoUpdateListeners.includes(listenerToRemove)) {
      customerInfoUpdateListeners = customerInfoUpdateListeners.filter(
        (listener) => listenerToRemove !== listener
      );
      return true;
    }
    return false;
  }

  /**
   * Sets a function to be called on purchases initiated on the Apple App Store. This is only used in iOS.
   * @param {ShouldPurchasePromoProductListener} shouldPurchasePromoProductListener Called when a user initiates a
   * promotional in-app purchase from the App Store. If your app is able to handle a purchase at the current time, run
   * the deferredPurchase function. If the app is not in a state to make a purchase: cache the deferredPurchase, then
   * call the deferredPurchase when the app is ready to make the promotional purchase.
   * If the purchase should never be made, you don't need to ever call the deferredPurchase and the app will not
   * proceed with promotional purchases.
   */
  public static addShouldPurchasePromoProductListener(
    shouldPurchasePromoProductListener: ShouldPurchasePromoProductListener
  ): void {
    if (typeof shouldPurchasePromoProductListener !== "function") {
      throw new Error("addShouldPurchasePromoProductListener needs a function");
    }
    shouldPurchasePromoProductListeners.push(
      shouldPurchasePromoProductListener
    );
  }

  /**
   * Removes a given ShouldPurchasePromoProductListener
   * @param {ShouldPurchasePromoProductListener} listenerToRemove ShouldPurchasePromoProductListener reference of
   * the listener to remove
   * @returns {boolean} True if listener was removed, false otherwise
   */
  public static removeShouldPurchasePromoProductListener(
    listenerToRemove: ShouldPurchasePromoProductListener
  ): boolean {
    if (shouldPurchasePromoProductListeners.includes(listenerToRemove)) {
      shouldPurchasePromoProductListeners =
        shouldPurchasePromoProductListeners.filter(
          (listener) => listenerToRemove !== listener
        );
      return true;
    }
    return false;
  }

  /**
   * Gets the map of entitlements -> offerings -> products
   * @returns {Promise<PurchasesOfferings>} Promise of entitlements structure. The promise will be rejected if configure
   * has not been called yet.
   */
  public static async getOfferings(): Promise<PurchasesOfferings> {
    await throwIfNotConfigured();
    return RNPurchases.getOfferings();
  }

  /**
   * Retrieves a current offering for a placement identifier, use this to access offerings defined by targeting
   * placements configured in the RevenueCat dashboard.
   * @param {String} placementIdentifier The placement identifier to fetch a current offeringn for
   * @returns {Promise<PurchasesOffering | null>} Promise of an optional offering. The promise will be rejected if configure
   * has not been called yet.
   */
  public static async getCurrentOfferingForPlacement(
    placementIdentifier: string
  ): Promise<PurchasesOffering | null> {
    await throwIfNotConfigured();
    return RNPurchases.getCurrentOfferingForPlacement(placementIdentifier);
  }

  /**
   * Syncs subscriber attributes and then fetches the configured offerings for this user. This method is intended to
   * be called when using Targeting Rules with Custom Attributes. Any subscriber attributes should be set before
   * calling this method to ensure the returned offerings are applied with the latest subscriber attributes.
   * @returns {Promise<PurchasesOfferings>} Promise of entitlements structure. The promise will be rejected if configure
   * has not been called yet.
   */
  public static async syncAttributesAndOfferingsIfNeeded(): Promise<PurchasesOfferings> {
    await throwIfNotConfigured();
    return RNPurchases.syncAttributesAndOfferingsIfNeeded();
  }

  /**
   * Sets attribution data from Appstack's attribution params, then syncs subscriber attributes and fetches
   * fresh offerings so that Appstack-based targeting is applied before the promise resolves.
   *
   * Pass the object received from the Appstack Attribution SDK's `getAttributionParams()` directly.
   * The SDK extracts relevant attribution info and sets the appropriate subscriber attributes.
   *
   * @param {object} data The attribution params from the Appstack Attribution SDK.
   * @returns {Promise<PurchasesOfferings>} Promise of offerings targeted with Appstack data.
   */
  public static async setAppstackAttributionParams(
    data: Record<string, any>
  ): Promise<PurchasesOfferings> {
    await throwIfNotConfigured();
    return RNPurchases.setAppstackAttributionParams(data);
  }

  /**
   * Fetch the product info
   * @param {String[]} productIdentifiers Array of product identifiers
   * @param {String} type Optional type of products to fetch, can be SUBSCRIPTION or NON_SUBSCRIPTION. SUBSCRIPTION by default
   * @returns {Promise<PurchasesStoreProduct[]>} A promise containing an array of products. The promise will be rejected
   * if the products are not properly configured in RevenueCat or if there is another error retrieving them.
   * Rejections return an error code, and a userInfo object with more information. The promise will also be rejected
   * if configure has not been called yet.
   */
  public static async getProducts(
    productIdentifiers: string[],
    type: PURCHASE_TYPE | PRODUCT_CATEGORY = PRODUCT_CATEGORY.SUBSCRIPTION
  ): Promise<PurchasesStoreProduct[]> {
    await throwIfNotConfigured();
    return RNPurchases.getProductInfo(productIdentifiers, type);
  }

  /**
   * Make a purchase
   *
   * @param {String} productIdentifier The product identifier of the product you want to purchase
   * @param {UpgradeInfo} upgradeInfo Android only. Optional UpgradeInfo you wish to upgrade from containing the oldSKU
   * and the optional prorationMode.
   * @param {String} type Optional type of product, can be inapp or subs. Subs by default
   * @deprecated, use purchaseStoreProduct instead
   */
  public static async purchaseProduct(
    productIdentifier: string,
    upgradeInfo?: UpgradeInfo | null,
    type: PURCHASE_TYPE = PURCHASE_TYPE.SUBS
  ): Promise<MakePurchaseResult> {
    await throwIfNotConfigured();
    return RNPurchases.purchaseProduct(
      productIdentifier,
      upgradeInfo,
      type,
      null,
      null,
      null
    );
  }

  /**
   * Make a purchase
   *
   * @param {PurchasesStoreProduct} product The product you want to purchase
   * @param {GoogleProductChangeInfo | StoreProductChangeInfo} productChangeInfo Android only. Optional product change info you
   * wish to upgrade from containing the oldProductIdentifier and the optional prorationMode or replacementMode.
   * @param {boolean} googleIsPersonalizedPrice Android and Google only. Optional boolean indicates personalized pricing on products available for purchase in the EU.
   * For compliance with EU regulations. User will see "This price has been customized for you" in the purchase dialog when true.
   * See https://developer.android.com/google/play/billing/integrate#personalized-price for more info.
   * @returns {Promise<{ productIdentifier: string, customerInfo:CustomerInfo }>} A promise of an object containing
   * a customer info object and a product identifier. Rejections return an error code,
   * a boolean indicating if the user cancelled the purchase, and an object with more information. The promise will
   * also be rejected if configure has not been called yet.
   */
  public static async purchaseStoreProduct(
    product: PurchasesStoreProduct,
    productChangeInfo?: GoogleProductChangeInfo | StoreProductChangeInfo | null,
    googleIsPersonalizedPrice?: boolean | null
  ): Promise<MakePurchaseResult> {
    await throwIfNotConfigured();
    return RNPurchases.purchaseProduct(
      product.identifier,
      productChangeInfo,
      product.productCategory,
      null,
      googleIsPersonalizedPrice == null
        ? null
        : { isPersonalizedPrice: googleIsPersonalizedPrice },
      product.presentedOfferingContext
    );
  }

  /**
   * iOS only. Purchase a product applying a given discount.
   *
   * @param {PurchasesStoreProduct} product The product you want to purchase
   * @param {PurchasesPromotionalOffer} discount Discount to apply to this package. Retrieve this discount using getPromotionalOffer.
   * @param {boolean} googleIsPersonalizedPrice Android and Google only. Optional boolean indicates personalized pricing on products available for purchase in the EU.
   * For compliance with EU regulations. User will see "This price has been customize for you" in the purchase dialog when true.
   * See https://developer.android.com/google/play/billing/integrate#personalized-price for more info.
   * @returns {Promise<{ productIdentifier: string, customerInfo:CustomerInfo }>} A promise of an object containing
   * a customer info object and a product identifier. Rejections return an error code,
   * a boolean indicating if the user cancelled the purchase, and an object with more information. The promise will be
   * rejected if configure has not been called yet.
   */
  public static async purchaseDiscountedProduct(
    product: PurchasesStoreProduct,
    discount: PurchasesPromotionalOffer
  ): Promise<MakePurchaseResult> {
    await throwIfNotConfigured();
    if (typeof discount === "undefined" || discount == null) {
      throw new Error("A discount is required");
    }
    return RNPurchases.purchaseProduct(
      product.identifier,
      null,
      null,
      discount.timestamp.toString(),
      null,
      product.presentedOfferingContext
    );
  }

  /**
   * Make a purchase
   *
   * @param {PurchasesPackage} aPackage The Package you wish to purchase. You can get the Packages by calling getOfferings
   * @param {UpgradeInfo} upgradeInfo DEPRECATED. Use productChangeInfo.
   * @param {GoogleProductChangeInfo | StoreProductChangeInfo} productChangeInfo Android only. Optional product change info you
   * wish to upgrade from containing the oldProductIdentifier and the optional prorationMode or replacementMode.
   * @param {boolean} googleIsPersonalizedPrice Android and Google only. Optional boolean indicates personalized pricing on products available for purchase in the EU.
   * For compliance with EU regulations. User will see "This price has been customized for you" in the purchase dialog when true.
   * See https://developer.android.com/google/play/billing/integrate#personalized-price for more info.
   * @returns {Promise<{ productIdentifier: string, customerInfo: CustomerInfo }>} A promise of an object containing
   * a customer info object and a product identifier. Rejections return an error code, a boolean indicating if the
   * user cancelled the purchase, and an object with more information. The promise will be also be rejected if configure
   * has not been called yet.
   */
  public static async purchasePackage(
    aPackage: PurchasesPackage,
    upgradeInfo?: UpgradeInfo | null,
    productChangeInfo?: GoogleProductChangeInfo | StoreProductChangeInfo | null,
    googleIsPersonalizedPrice?: boolean | null
  ): Promise<MakePurchaseResult> {
    await throwIfNotConfigured();
    return RNPurchases.purchasePackage(
      aPackage.identifier,
      aPackage.presentedOfferingContext,
      productChangeInfo || upgradeInfo,
      null,
      googleIsPersonalizedPrice == null
        ? null
        : { isPersonalizedPrice: googleIsPersonalizedPrice }
    );
  }

  /**
   * Google only. Make a purchase of a subscriptionOption
   *
   * @param {SubscriptionOption} subscriptionOption The SubscriptionOption you wish to purchase. You can get the SubscriptionOption from StoreProducts by calling getOfferings
   * @param {GoogleProductChangeInfo | StoreProductChangeInfo} productChangeInfo Android only. Optional product change info you
   * wish to upgrade from containing the oldProductIdentifier and the optional prorationMode or replacementMode.
   * @param {boolean} googleIsPersonalizedPrice Android and Google only. Optional boolean indicates personalized pricing on products available for purchase in the EU.
   * For compliance with EU regulations. User will see "This price has been customized for you" in the purchase dialog when true.
   * See https://developer.android.com/google/play/billing/integrate#personalized-price for more info.
   * @returns {Promise<{ productIdentifier: string, customerInfo: CustomerInfo }>} A promise of an object containing
   * a customer info object and a product identifier. Rejections return an error code, a boolean indicating if the
   * user cancelled the purchase, and an object with more information. The promise will be also be rejected if configure
   * has not been called yet.
   */
  public static async purchaseSubscriptionOption(
    subscriptionOption: SubscriptionOption,
    productChangeInfo?: GoogleProductChangeInfo | StoreProductChangeInfo | null,
    googleIsPersonalizedPrice?: boolean
  ): Promise<MakePurchaseResult> {
    await throwIfNotConfigured();
    await Purchases.throwIfIOSPlatform();
    return RNPurchases.purchaseSubscriptionOption(
      subscriptionOption.productId,
      subscriptionOption.id,
      productChangeInfo,
      null,
      googleIsPersonalizedPrice == null
        ? null
        : { isPersonalizedPrice: googleIsPersonalizedPrice },
      subscriptionOption.presentedOfferingContext
    );
  }

  /**
   * iOS only. Purchase a package applying a given discount.
   *
   * @param {PurchasesPackage} aPackage The Package you wish to purchase. You can get the Packages by calling getOfferings
   * @param {PurchasesPromotionalOffer} discount Discount to apply to this package. Retrieve this discount using getPromotionalOffer.
   * @returns {Promise<{ productIdentifier: string, customerInfo: CustomerInfo }>} A promise of an object containing
   * a customer info object and a product identifier. Rejections return an error code, a boolean indicating if the
   * user cancelled the purchase, and an object with more information. The promise will be also be rejected if configure
   * has not been called yet.
   */
  public static async purchaseDiscountedPackage(
    aPackage: PurchasesPackage,
    discount: PurchasesPromotionalOffer
  ): Promise<MakePurchaseResult> {
    await throwIfNotConfigured();
    if (typeof discount === "undefined" || discount == null) {
      throw new Error("A discount is required");
    }
    return RNPurchases.purchasePackage(
      aPackage.identifier,
      aPackage.presentedOfferingContext,
      null,
      discount.timestamp.toString(),
      null
    );
  }

  /**
   * Restores a user's previous purchases and links their appUserIDs to any user's also using those purchases.
   * @returns {Promise<CustomerInfo>} A promise of a customer info object. Rejections return an error code, and an
   * userInfo object with more information. The promise will be also be rejected if configure has not been called yet.
   */
  public static async restorePurchases(): Promise<CustomerInfo> {
    await throwIfNotConfigured();
    return RNPurchases.restorePurchases();
  }

  /**
   * Get the appUserID
   * @returns {Promise<string>} The app user id in a promise
   */
  public static async getAppUserID(): Promise<string> {
    await throwIfNotConfigured();
    return RNPurchases.getAppUserID();
  }

  /**
   * Gets the storefront for the current store account.
   * @returns {Promise<Storefront | null>} The storefront for the current store account, or null if the storefront is not available.
   */
    public static async getStorefront(): Promise<Storefront | null> {
      await throwIfNotConfigured();
      return RNPurchases.getStorefront();
    }

  /**
   * This function will logIn the current user with an appUserID. Typically this would be used after a log in
   * to identify a user without calling configure.
   * @param {String} appUserID The appUserID that should be linked to the currently user
   * @returns {Promise<LogInResult>} A promise of an object that contains the customerInfo after logging in, as well
   * as a boolean indicating whether the user has just been created for the first time in the RevenueCat backend. The
   * promise will be rejected if configure has not been called yet or if there's an issue logging in.
   */
  public static async logIn(appUserID: string): Promise<LogInResult> {
    await throwIfNotConfigured();
    // noinspection SuspiciousTypeOfGuard
    if (typeof appUserID !== "string") {
      throw new Error("appUserID needs to be a string");
    }
    return RNPurchases.logIn(appUserID);
  }

  /**
   * Logs out the Purchases client clearing the saved appUserID. This will generate a random user id and save it in the cache.
   * @returns {Promise<CustomerInfo>} A promise of a customer info object. Rejections return an error code,
   * and a userInfo object with more information. The promise will be rejected if configure has not been called yet or if
   * there's an issue logging out.
   */
  public static async logOut(): Promise<CustomerInfo> {
    await throwIfNotConfigured();
    return RNPurchases.logOut();
  }

  /**
   * Enables/Disables debugs logs
   * @param {boolean} enabled Enable or not debug logs
   * @deprecated, use setLogLevel instead
   */
  public static async setDebugLogsEnabled(enabled: boolean): Promise<void> {
    RNPurchases.setDebugLogsEnabled(enabled);
  }

  /**
   * Used to set the log level. Useful for debugging issues with the lovely team @RevenueCat.
   * The default is {LOG_LEVEL.INFO} in release builds and {LOG_LEVEL.DEBUG} in debug builds.
   * @param {LOG_LEVEL} level
   */
  public static async setLogLevel(level: LOG_LEVEL): Promise<void> {
    RNPurchases.setLogLevel(level);
  }

  /**
   * Set a custom log handler for redirecting logs to your own logging system.
   * By default, this sends info, warning, and error messages.
   * If you wish to receive Debug level messages, see [setLogLevel].
   * @param {LogHandler} logHandler It will get called for each log event.
   * Use this function to redirect the log to your own logging system
   */
  public static setLogHandler(logHandler: LogHandler): void {
    customLogHandler = logHandler;
    if (usingBrowserMode) {
      RNPurchases.setLogHandler(logHandler);
    } else {
      RNPurchases.setLogHandler();
    }
  }

  /**
   * Sets a function to be called when a feature event is tracked by RevenueCatUI.
   * This is a debug API for monitoring paywall and customer center events not meant for public use.
   * Currently only works on Android and iOS.
   * @internal
   * @param {TrackedEventListener} trackedEventListener TrackedEvent listener
   */
  public static async addTrackedEventListener(
    trackedEventListener: TrackedEventListener
  ): Promise<void> {
    await throwIfNotConfigured();
    if (Platform.OS === "android" || Platform.OS === "ios") {
      if (typeof trackedEventListener !== "function") {
        throw new Error("addTrackedEventListener needs a function");
      }
      const isFirstListener = trackedEventListeners.length === 0;
      trackedEventListeners.push(trackedEventListener);
      if (isFirstListener && !usingBrowserMode) {
        RNPurchases.setTrackedEventListener();
      }
    }
  }

  /**
   * Removes a given TrackedEventListener.
   * This is a debug API not meant for public use.
   * @internal
   * @param trackedEventListener TrackedEvent listener to remove
   */
  public static removeTrackedEventListener(
    trackedEventListener: TrackedEventListener
  ): void {
    trackedEventListeners = trackedEventListeners.filter((listener) => listener !== trackedEventListener);
  }

  /**
   * Sets a function to be called when a debug event is tracked by RevenueCat.
   * This is a debug API for monitoring debug events not meant for public use.
   * Currently only works on Android.
   * @internal
   * @param {DebugEventListener} debugEventListener DebugEvent listener
   */
  public static async addDebugEventListener(
    debugEventListener: DebugEventListener
  ): Promise<void> {
    await throwIfNotConfigured();
    if (Platform.OS === "android") {
      if (typeof debugEventListener !== "function") {
        throw new Error("addDebugEventListener needs a function");
      }
      const isFirstListener = debugEventListeners.length === 0;
      debugEventListeners.push(debugEventListener);
      if (isFirstListener && !usingBrowserMode) {
        RNPurchases.setDebugEventListener();
      }
    }
  }

  /**
   * Removes a given DebugEventListener.
   * This is a debug API not meant for public use.
   * @internal
   * @param debugEventListener DebugEventListener listener to remove
   */
  public static removeDebugEventListener(
    debugEventListener: DebugEventListener
  ): void {
    debugEventListeners = debugEventListeners.filter((listener) => listener !== debugEventListener);
  }

  /**
   * Gets current customer info
   * @returns {Promise<CustomerInfo>} A promise of a customer info object. Rejections return an error code, and an
   * userInfo object with more information. The promise will be rejected if configure has not been called yet or if
   * there's an issue getting the customer information.
   */
  public static async getCustomerInfo(): Promise<CustomerInfo> {
    await throwIfNotConfigured();
    return RNPurchases.getCustomerInfo();
  }

  /**
   * This method will send all the purchases to the RevenueCat backend. Call this when using your own implementation
   * for subscriptions anytime a sync is needed, like after a successful purchase.
   *
   * @deprecated Use {@link syncPurchasesForResult} instead, which returns the updated CustomerInfo.
   * @warning This function should only be called if you're not calling purchaseProduct/purchaseStoreProduct/purchasePackage/purchaseSubscriptionOption.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * syncing purchases.
   */
  public static async syncPurchases(): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.syncPurchases();
  }

  /**
   * This method will send all the purchases to the RevenueCat backend. Call this when using your own implementation
   * for subscriptions anytime a sync is needed, like after a successful purchase.
   *
   * @warning This function should only be called if you're not calling purchaseProduct/purchaseStoreProduct/purchasePackage/purchaseSubscriptionOption.
   * @returns {Promise<SyncPurchasesResult>} A promise containing the sync result with customer info. The promise will
   * be rejected if configure has not been called yet or if there's an error syncing purchases.
   */
  public static async syncPurchasesForResult(): Promise<SyncPurchasesResult> {
    await throwIfNotConfigured();
    const customerInfo: CustomerInfo = await RNPurchases.syncPurchasesForResult();
    return { customerInfo };
  }

  /**
   * This method will send a purchase to the RevenueCat backend. This function should only be called if you are
   * in Amazon observer mode or performing a client side migration of your current users to RevenueCat.
   *
   * The receipt IDs are cached if successfully posted so they are not posted more than once.
   *
   * @param {string} productID Product ID associated to the purchase.
   * @param {string} receiptID ReceiptId that represents the Amazon purchase.
   * @param {string} amazonUserID Amazon's userID. This parameter will be ignored when syncing a Google purchase.
   * @param {(string|null|undefined)} isoCurrencyCode Product's currency code in ISO 4217 format.
   * @param {(number|null|undefined)} price Product's price.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * syncing purchases.
   */
  public static async syncAmazonPurchase(
    productID: string,
    receiptID: string,
    amazonUserID: string,
    isoCurrencyCode?: string | null,
    price?: number | null
  ): Promise<void> {
    await Purchases.throwIfIOSPlatform();
    await throwIfNotConfigured();
    RNPurchases.syncAmazonPurchase(
      productID,
      receiptID,
      amazonUserID,
      isoCurrencyCode,
      price
    );
  }

  /**
   * @deprecated, use syncAmazonPurchase instead.
   *
   * This method will send a purchase to the RevenueCat backend. This function should only be called if you are
   * in Amazon observer mode or performing a client side migration of your current users to RevenueCat.
   *
   * The receipt IDs are cached if successfully posted so they are not posted more than once.
   *
   * @param {string} productID Product ID associated to the purchase.
   * @param {string} receiptID ReceiptId that represents the Amazon purchase.
   * @param {string} amazonUserID Amazon's userID. This parameter will be ignored when syncing a Google purchase.
   * @param {(string|null|undefined)} isoCurrencyCode Product's currency code in ISO 4217 format.
   * @param {(number|null|undefined)} price Product's price.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * syncing purchases.
   */
  public static async syncObserverModeAmazonPurchase(
    productID: string,
    receiptID: string,
    amazonUserID: string,
    isoCurrencyCode?: string | null,
    price?: number | null
  ): Promise<void> {
    await Purchases.throwIfIOSPlatform();
    await throwIfNotConfigured();
    RNPurchases.syncObserverModeAmazonPurchase(
      productID,
      receiptID,
      amazonUserID,
      isoCurrencyCode,
      price
    );
  }

  /**
   * iOS only. Always returns an error on iOS < 15.
   *
   * Use this method only if you already have your own IAP implementation using StoreKit 2 and want to use
   * RevenueCat's backend. If you are using StoreKit 1 for your implementation, you do not need this method.
   *
   * You only need to use this method with *new* purchases. Subscription updates are observed automatically.
   *
   * Important: This should only be used if you have set PurchasesAreCompletedBy to MY_APP during SDK configuration.
   *
   * @warning You need to finish the transaction yourself after calling this method.
   *
   * @param {string} productID Product ID that was just purchased
   * @returns {Promise<PurchasesStoreTransaction>} If there was a transacton found and handled for the provided product ID.
   */
  public static async recordPurchase(
    productID: string
  ): Promise<PurchasesStoreTransaction> {
    await Purchases.throwIfAndroidPlatform();
    await throwIfNotConfigured();
    return RNPurchases.recordPurchaseForProductID(productID);
  }

  /**
   * Enable automatic collection of Apple Search Ad attribution on iOS. Disabled by default
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet.
   */
  public static async enableAdServicesAttributionTokenCollection(): Promise<void> {
    if (Platform.OS === "ios") {
      await throwIfNotConfigured();
      RNPurchases.enableAdServicesAttributionTokenCollection();
    }
  }

  /**
   * @returns { Promise<boolean> } If the `appUserID` has been generated by RevenueCat or not.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet.
   */
  public static async isAnonymous(): Promise<boolean> {
    await throwIfNotConfigured();
    return RNPurchases.isAnonymous();
  }

  /**
   * iOS only. Computes whether or not a user is eligible for the introductory pricing period of a given product.
   * You should use this method to determine whether or not you show the user the normal product price or the
   * introductory price. This also applies to trials (trials are considered a type of introductory pricing).
   *
   * @note Subscription groups are automatically collected for determining eligibility. If RevenueCat can't
   * definitively compute the eligibility, most likely because of missing group information, it will return
   * `INTRO_ELIGIBILITY_STATUS_UNKNOWN`. The best course of action on unknown status is to display the non-intro
   * pricing, to not create a misleading situation. To avoid this, make sure you are testing with the latest version of
   * iOS so that the subscription group can be collected by the SDK. Android always returns INTRO_ELIGIBILITY_STATUS_UNKNOWN.
   *
   * @param productIdentifiers Array of product identifiers for which you want to compute eligibility
   * @returns { Promise<[productId: string]: IntroEligibility> } A map of IntroEligility per productId. The promise
   * will be rejected if configure has not been called yet or if there's in an error checking eligibility.
   */
  public static async checkTrialOrIntroductoryPriceEligibility(
    productIdentifiers: string[]
  ): Promise<{ [productId: string]: IntroEligibility }> {
    await throwIfNotConfigured();
    return RNPurchases.checkTrialOrIntroductoryPriceEligibility(
      productIdentifiers
    );
  }

  /**
   * iOS only. Use this function to retrieve the `PurchasesPromotionalOffer` for a given `PurchasesPackage`.
   *
   * @param product The `PurchasesStoreProduct` the user intends to purchase.
   * @param discount The `PurchasesStoreProductDiscount` to apply to the product.
   * @returns { Promise<PurchasesPromotionalOffer> } Returns when the `PurchasesPaymentDiscount` is returned.
   * Null is returned for Android and incompatible iOS versions. The promise will be rejected if configure has not been
   * called yet or if there's an error getting the payment discount.
   */
  public static async getPromotionalOffer(
    product: PurchasesStoreProduct,
    discount: PurchasesStoreProductDiscount
  ): Promise<PurchasesPromotionalOffer | undefined> {
    await throwIfNotConfigured();
    if (Platform.OS === "android") {
      return Promise.resolve(undefined);
    }
    if (typeof discount === "undefined" || discount == null) {
      throw new Error("A discount is required");
    }
    return RNPurchases.getPromotionalOffer(
      product.identifier,
      discount.identifier
    );
  }

  /**
   * iOS only. Use this function to retrieve the eligible `PurchasesWinBackOffer`s that a subscriber
   * is eligible for for a given `PurchasesProduct`.
   *
   * @param product The `PurchasesStoreProduct` the user intends to purchase.
   * @returns { Promise<[PurchasesWinBackOffer]> } Returns an array of win-back offers that the subscriber is eligible for.
   * Null is returned for Android and incompatible iOS versions. The promise will be rejected if configure has not been
   * called yet or if there's an error getting the payment discount.
   */
  public static async getEligibleWinBackOffersForProduct(
    product: PurchasesStoreProduct
  ): Promise<[PurchasesWinBackOffer] | undefined> {
    await throwIfNotConfigured();
    if (Platform.OS === "android") {
      return Promise.resolve(undefined);
    }

    return RNPurchases.eligibleWinBackOffersForProductIdentifier(
      product.identifier
    );
  }

  /**
   * iOS only. Use this function to retrieve the eligible `PurchasesWinBackOffer`s that a subscriber
   * is eligible for for a given `PurchasesPackage`.
   *
   * @param aPackage The `PurchasesPackage` the user intends to purchase.
   * @returns { Promise<[PurchasesWinBackOffer]> } Returns an array of win-back offers that the subscriber is eligible for.
   * Null is returned for Android and incompatible iOS versions. The promise will be rejected if configure has not been
   * called yet or if there's an error getting the payment discount.
   */
  public static async getEligibleWinBackOffersForPackage(
    aPackage: PurchasesPackage
  ): Promise<[PurchasesWinBackOffer] | undefined> {
    await throwIfNotConfigured();
    if (Platform.OS === "android") {
      return Promise.resolve(undefined);
    }

    return RNPurchases.eligibleWinBackOffersForProductIdentifier(
      aPackage.product.identifier
    );
  }

  /**
   * iOS only. Purchase a product applying a given win-back offer.
   *
   * Only available on iOS 18.0+ when StoreKit 2 is enabled.
   *
   * @param {PurchasesStoreProduct} product The product you want to purchase
   * @param {PurchasesWinBackOffer} winBackOffer Win-back offer to apply to this package. Retrieve this offer using getEligibleWinBackOffers.
   * @returns {Promise<{ productIdentifier: string, customerInfo:CustomerInfo }>} A promise of an object containing
   * a customer info object and a product identifier. Rejections return an error code,
   * a boolean indicating if the user cancelled the purchase, and an object with more information. The promise will be
   * rejected if configure has not been called yet.
   */
  public static async purchaseProductWithWinBackOffer(
    product: PurchasesStoreProduct,
    winBackOffer: PurchasesWinBackOffer
  ): Promise<MakePurchaseResult> {
    await throwIfNotConfigured();
    if (typeof winBackOffer === "undefined" || winBackOffer == null) {
      throw new Error("A win-back offer is required");
    }
    if (Platform.OS === "android") {
      throw new UnsupportedPlatformError();
    }
    return RNPurchases.purchaseProductWithWinBackOffer(
      product.identifier,
      winBackOffer.identifier
    );
  }

  /**
   * iOS only. Purchase a package applying a given win-back offer.
   *
   * Only available on iOS 18.0+ when StoreKit 2 is enabled.
   *
   * @param {PurchasesStoreProduct} product The product you want to purchase
   * @param {PurchasesWinBackOffer} winBackOffer Win-back offer to apply to this package. Retrieve this offer using getEligibleWinBackOffers.
   * @returns {Promise<{ productIdentifier: string, customerInfo:CustomerInfo }>} A promise of an object containing
   * a customer info object and a product identifier. Rejections return an error code,
   * a boolean indicating if the user cancelled the purchase, and an object with more information. The promise will be
   * rejected if configure has not been called yet.
   */
  public static async purchasePackageWithWinBackOffer(
    aPackage: PurchasesPackage,
    winBackOffer: PurchasesWinBackOffer
  ): Promise<MakePurchaseResult> {
    await throwIfNotConfigured();
    if (typeof winBackOffer === "undefined" || winBackOffer == null) {
      throw new Error("A win-back offer is required");
    }
    if (Platform.OS === "android") {
      throw new UnsupportedPlatformError();
    }
    return RNPurchases.purchasePackageWithWinBackOffer(
      aPackage.identifier,
      aPackage.presentedOfferingContext,
      winBackOffer.identifier
    );
  }

  /**
   * Invalidates the cache for customer information.
   *
   * Most apps will not need to use this method; invalidating the cache can leave your app in an invalid state.
   * Refer to https://docs.revenuecat.com/docs/customer-info#section-get-user-information for more information on
   * using the cache properly.
   *
   * This is useful for cases where customer information might have been updated outside of the app, like if a
   * promotional subscription is granted through the RevenueCat dashboard.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or there's an error
   * invalidating the customer info cache.
   */
  public static async invalidateCustomerInfoCache(): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.invalidateCustomerInfoCache();
  }

  /** iOS only. Presents a code redemption sheet, useful for redeeming offer codes
   * Refer to https://docs.revenuecat.com/docs/ios-subscription-offers#offer-codes for more information on how
   * to configure and use offer codes
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or there's an error
   * presenting the code redemption sheet.
   */
  public static async presentCodeRedemptionSheet(): Promise<void> {
    if (Platform.OS === "ios") {
      await throwIfNotConfigured();
      RNPurchases.presentCodeRedemptionSheet();
    }
  }

  /**
   * Subscriber attributes are useful for storing additional, structured information on a user.
   * Since attributes are writable using a public key they should not be used for
   * managing secure or sensitive information such as subscription status, coins, etc.
   *
   * Key names starting with "$" are reserved names used by RevenueCat. For a full list of key
   * restrictions refer to our guide: https://docs.revenuecat.com/docs/subscriber-attributes
   *
   * @param attributes Map of attributes by key. Set the value as an empty string to delete an attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or there's an error
   * setting the subscriber attributes.
   */
  public static async setAttributes(attributes: {
    [key: string]: string | null;
  }): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setAttributes(attributes);
  }

  /**
   * Subscriber attribute associated with the email address for the user
   *
   * @param email Empty String or null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting the email.
   */
  public static async setEmail(email: string | null): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setEmail(email);
  }

  /**
   * Subscriber attribute associated with the phone number for the user
   *
   * @param phoneNumber Empty String or null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting the phone number.
   */
  public static async setPhoneNumber(
    phoneNumber: string | null
  ): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setPhoneNumber(phoneNumber);
  }

  /**
   * Subscriber attribute associated with the display name for the user
   *
   * @param displayName Empty String or null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting the display name.
   */
  public static async setDisplayName(
    displayName: string | null
  ): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setDisplayName(displayName);
  }

  /**
   * Subscriber attribute associated with the push token for the user
   *
   * @param pushToken null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting the push token.
   */
  public static async setPushToken(pushToken: string | null): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setPushToken(pushToken);
  }

  /**
   * Set this property to your proxy URL before configuring Purchases *only* if you've received a proxy key value
   * from your RevenueCat contact.
   * @returns {Promise<void>} The promise to be returned after setting the proxy has been completed.
   */
  public static async setProxyURL(url: string): Promise<void> {
    return RNPurchases.setProxyURLString(url);
  }

  /**
   * Automatically collect subscriber attributes associated with the device identifiers.
   * $idfa, $idfv, $ip on iOS
   * $gpsAdId, $androidId, $ip on Android
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting collecting the device identifiers.
   */
  public static async collectDeviceIdentifiers(): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.collectDeviceIdentifiers();
  }

  /**
   * Subscriber attribute associated with the Adjust Id for the user
   * Required for the RevenueCat Adjust integration
   *
   * @param adjustID Adjust ID to use in Adjust integration. Empty String or null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting Adjust ID.
   */
  public static async setAdjustID(adjustID: string | null): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setAdjustID(adjustID);
  }

  /**
   * Subscriber attribute associated with the AppsFlyer Id for the user
   * Required for the RevenueCat AppsFlyer integration
   * @param appsflyerID Appsflyer ID to use in Appsflyer integration. Empty String or null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting the Appsflyer ID.
   */
  public static async setAppsflyerID(
    appsflyerID: string | null
  ): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setAppsflyerID(appsflyerID);
  }

  /**
   * Subscriber attribute associated with the Facebook SDK Anonymous Id for the user
   * Recommended for the RevenueCat Facebook integration
   *
   * @param fbAnonymousID Facebook Anonymous ID to use in Mparticle integration. Empty String or null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting the Facebook Anonymous ID.
   */
  public static async setFBAnonymousID(
    fbAnonymousID: string | null
  ): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setFBAnonymousID(fbAnonymousID);
  }

  /**
   * Subscriber attribute associated with the mParticle Id for the user
   * Recommended for the RevenueCat mParticle integration
   *
   * @param mparticleID Mparticle ID to use in Mparticle integration. Empty String or null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting the Mparticle ID.
   */
  public static async setMparticleID(
    mparticleID: string | null
  ): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setMparticleID(mparticleID);
  }

  /**
   * Subscriber attribute associated with the CleverTap Id for the user
   * Required for the RevenueCat CleverTap integration
   *
   * @param cleverTapID CleverTap user ID to use in CleverTap integration. Empty String or null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting the CleverTap ID.
   */
  public static async setCleverTapID(
    cleverTapID: string | null
  ): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setCleverTapID(cleverTapID);
  }

  /**
   * Subscriber attribute associated with the Mixpanel Distinct Id for the user
   * Required for the RevenueCat Mixpanel integration
   *
   * @param mixpanelDistinctID Mixpanel Distinct ID to use in Mixpanel integration. Empty String or null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting the Mixpanel Distinct ID.
   */
  public static async setMixpanelDistinctID(
    mixpanelDistinctID: string | null
  ): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setMixpanelDistinctID(mixpanelDistinctID);
  }

  /**
   * Subscriber attribute associated with the Firebase App Instance ID for the user
   * Required for the RevenueCat Firebase integration
   *
   * @param firebaseAppInstanceID Firebase App Instance ID to use in Firebase integration. Empty String or null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting the Firebase App Instance ID.
   */
  public static async setFirebaseAppInstanceID(
    firebaseAppInstanceID: string | null
  ): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setFirebaseAppInstanceID(firebaseAppInstanceID);
  }

  /**
   * Subscriber attribute associated with the Tenjin Analytics Installation ID for the user.
   * Required for the RevenueCat Tenjin integration.
   *
   * @param tenjinAnalyticsInstallationID Tenjin analytics installation ID to use in the Tenjin integration. Empty String or null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting the Tenjin Analytics Installation ID.
   */
  public static async setTenjinAnalyticsInstallationID(
    tenjinAnalyticsInstallationID: string | null
  ): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setTenjinAnalyticsInstallationID(tenjinAnalyticsInstallationID);
  }

  /**
   * Subscriber attribute associated with the Kochava Device ID for the user.
   * Required for the RevenueCat Kochava integration.
   *
   * @param kochavaDeviceID Kochava device ID to use in the Kochava integration. Empty String or null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting the Kochava Device ID.
   */
  public static async setKochavaDeviceID(
    kochavaDeviceID: string | null
  ): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setKochavaDeviceID(kochavaDeviceID);
  }

  /**
   * Subscriber attribute associated with the Singular Device ID (SDID) for the user.
   * Required for the RevenueCat Singular integration when using Singular's Event
   * Endpoint V2.
   *
   * The SDID is generated by the Singular SDK and cannot be collected by
   * collectDeviceIdentifiers, so it has to be forwarded by the app.
   *
   * @param singularDeviceID Singular device ID to use in the Singular integration. Empty String or null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting the Singular Device ID.
   */
  public static async setSingularDeviceID(
    singularDeviceID: string | null
  ): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setSingularDeviceID(singularDeviceID);
  }

  /**
   * Subscriber attribute associated with the OneSignal Player Id for the user
   * Required for the RevenueCat OneSignal integration with OneSignal SDK v4.0 and below
   * (OneSignal API v9). For OneSignal SDK v5.0 and above, use {@link setOnesignalUserID} instead.
   *
   * @param onesignalID OneSignal Player ID to use in OneSignal integration. Empty String or null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting the OneSignal ID.
   */
  public static async setOnesignalID(
    onesignalID: string | null
  ): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setOnesignalID(onesignalID);
  }

  /**
   * Subscriber attribute associated with the OneSignal User ID for the user
   * Required for the RevenueCat OneSignal integration with OneSignal SDK v5.0
   * and above (OneSignal API v11+).
   *
   * @param onesignalUserID OneSignal User ID to use in OneSignal integration. Empty String or null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting the OneSignal user ID.
   */
  public static async setOnesignalUserID(
    onesignalUserID: string | null
  ): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setOnesignalUserID(onesignalUserID);
  }

  /**
   * Subscriber attribute associated with the Airship Channel Id for the user
   * Required for the RevenueCat Airship integration
   *
   * @param airshipChannelID Airship Channel ID to use in Airship integration. Empty String or null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting the Airship Channel ID.
   */
  public static async setAirshipChannelID(
    airshipChannelID: string | null
  ): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setAirshipChannelID(airshipChannelID);
  }

  /**
   * Subscriber attribute associated with the install media source for the user
   *
   * @param mediaSource Empty String or null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting the media source.
   */
  public static async setMediaSource(
    mediaSource: string | null
  ): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setMediaSource(mediaSource);
  }

  /**
   * Subscriber attribute associated with the install campaign for the user
   *
   * @param campaign Empty String or null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting the campaign.
   */
  public static async setCampaign(campaign: string | null): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setCampaign(campaign);
  }

  /**
   * Subscriber attribute associated with the install ad group for the user
   *
   * @param adGroup Empty String or null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting ad group.
   */
  public static async setAdGroup(adGroup: string | null): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setAdGroup(adGroup);
  }

  /**
   * Subscriber attribute associated with the install ad for the user
   *
   * @param ad Empty String or null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting the ad subscriber attribute.
   */
  public static async setAd(ad: string | null): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setAd(ad);
  }

  /**
   * Subscriber attribute associated with the install keyword for the user
   *
   * @param keyword Empty String or null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting the keyword.
   */
  public static async setKeyword(keyword: string | null): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setKeyword(keyword);
  }

  /**
   * Subscriber attribute associated with the install ad creative for the user
   *
   * @param creative Empty String or null will delete the subscriber attribute.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or if there's an error
   * setting the creative subscriber attribute.
   */
  public static async setCreative(creative: string | null): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.setCreative(creative);
  }

  /**
   * Sets conversion data from AppsFlyer's onInstallConversionData callback. This extracts the
   * relevant attribution fields from the AppsFlyer conversion data and sets the corresponding
   * RevenueCat subscriber attributes ($mediaSource, $campaign, $adGroup, $ad, $keyword, $creative).
   * Note that this method will never unset any attributes.
   *
   * Pass the object received in AppsFlyer's onInstallConversionData listener directly; the nested
   * `data` field holds the conversion data that is forwarded to RevenueCat. The data is only
   * forwarded when `status` is `"success"`; otherwise it is ignored.
   *
   * @param conversionData The object from AppsFlyer's onInstallConversionData callback.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet.
   */
  public static async setAppsFlyerConversionData(conversionData: {
    status: string;
    data: { [key: string]: any };
  }): Promise<void> {
    await throwIfNotConfigured();
    if (conversionData?.status !== 'success') {
      // tslint:disable-next-line:no-console
      console.warn(
        `[RevenueCat] Ignoring AppsFlyer conversion data with status "${conversionData?.status}". ` +
          `Conversion data is only forwarded when status is "success".`,
      );
      return;
    }
    RNPurchases.setAppsFlyerConversionData(conversionData.data ?? null);
  }

  /**
   * Overrides the preferred UI locale used by RevenueCat UI components.
   * Pass null to clear the override and use the device's locale.
   *
   * @param locale A BCP 47 locale identifier (e.g., "en-US") or null to clear.
   * @returns {Promise<void>}
   */
  public static async overridePreferredLocale(
    locale: string | null
  ): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.overridePreferredLocale(locale);
  }

  /**
   * Check if billing is supported for the current user (meaning IN-APP purchases are supported)
   * and optionally, whether a list of specified feature types are supported.
   *
   * Note: Billing features are only relevant to Google Play Android users.
   * For other stores and platforms, billing features won't be checked.
   *
   * @param features An array of feature types to check for support. Feature types must be one of
   *       [BILLING_FEATURE]. By default, is an empty list and no specific feature support will be checked.
   * @returns {Promise<boolean>} promise with boolean response. True if billing is supported, false otherwise.
   */
  public static canMakePayments(
    features: BILLING_FEATURE[] = []
  ): Promise<boolean> {
    if (!RNPurchases) {
      // Native module not available, so payments cannot be made
      return Promise.resolve(false);
    }
    return RNPurchases.canMakePayments(features);
  }

  /**
   * iOS 15+ only. Presents a refund request sheet in the current window scene for
   * the latest transaction associated with the active entitlement.
   *
   * If the request was unsuccessful, no active entitlements could be found for
   * the user, or multiple active entitlements were found for the user,
   * the promise will return an error.
   * If called in an unsupported platform (Android or iOS < 15), an `UnsupportedPlatformException` will be thrown.
   *
   * Important: This method should only be used if your user can only have a single active entitlement at a given time.
   * If a user could have more than one entitlement at a time, use `beginRefundRequestForEntitlement` instead.
   *
   * @returns {Promise<REFUND_REQUEST_STATUS>} Returns REFUND_REQUEST_STATUS: The status of the
   *  refund request. Keep in mind the status could be REFUND_REQUEST_STATUS.USER_CANCELLED
   */
  public static async beginRefundRequestForActiveEntitlement(): Promise<REFUND_REQUEST_STATUS> {
    await throwIfNotConfigured();
    await Purchases.throwIfAndroidPlatform();
    const refundRequestStatusInt =
      await RNPurchases.beginRefundRequestForActiveEntitlement();
    if (refundRequestStatusInt == null) {
      throw new UnsupportedPlatformError();
    }
    return Purchases.convertIntToRefundRequestStatus(refundRequestStatusInt);
  }

  /**
   * iOS 15+ only. Presents a refund request sheet in the current window scene for
   * the latest transaction associated with the `entitlement`.
   *
   * If the request was unsuccessful, the promise will return an error.
   * If called in an unsupported platform (Android or iOS < 15), an `UnsupportedPlatformException` will be thrown.
   *
   * @param entitlementInfo The entitlement to begin a refund request for.
   * @returns {Promise<REFUND_REQUEST_STATUS>} Returns REFUND_REQUEST_STATUS: The status of the
   *  refund request. Keep in mind the status could be REFUND_REQUEST_STATUS.USER_CANCELLED
   */
  public static async beginRefundRequestForEntitlement(
    entitlementInfo: PurchasesEntitlementInfo
  ): Promise<REFUND_REQUEST_STATUS> {
    await throwIfNotConfigured();
    await Purchases.throwIfAndroidPlatform();
    const refundRequestStatusInt =
      await RNPurchases.beginRefundRequestForEntitlementId(
        entitlementInfo.identifier
      );
    if (refundRequestStatusInt == null) {
      throw new UnsupportedPlatformError();
    }
    return Purchases.convertIntToRefundRequestStatus(refundRequestStatusInt);
  }

  /**
   * iOS 15+ only. Presents a refund request sheet in the current window scene for
   * the latest transaction associated with the `product`.
   *
   * If the request was unsuccessful, the promise will return an error.
   * If called in an unsupported platform (Android or iOS < 15), an `UnsupportedPlatformException` will be thrown.
   *
   * @param storeProduct The StoreProduct to begin a refund request for.
   * @returns {Promise<REFUND_REQUEST_STATUS>} Returns a REFUND_REQUEST_STATUS: The status of the
   *  refund request. Keep in mind the status could be REFUND_REQUEST_STATUS.USER_CANCELLED
   */
  public static async beginRefundRequestForProduct(
    storeProduct: PurchasesStoreProduct
  ): Promise<REFUND_REQUEST_STATUS> {
    await throwIfNotConfigured();
    await Purchases.throwIfAndroidPlatform();
    const refundRequestStatusInt =
      await RNPurchases.beginRefundRequestForProductId(storeProduct.identifier);
    if (refundRequestStatusInt == null) {
      throw new UnsupportedPlatformError();
    }
    return Purchases.convertIntToRefundRequestStatus(refundRequestStatusInt);
  }

  /**
   * Presents the App Store sheet for managing subscriptions. Only available in iOS 13+ devices.
   */
  public static async showManageSubscriptions(): Promise<void> {
    await throwIfNotConfigured();
    await Purchases.throwIfAndroidPlatform();
    return RNPurchases.showManageSubscriptions();
  }

  /**
   * Shows in-app messages available from the App Store or Google Play. You need to disable messages from showing
   * automatically using [PurchasesConfiguration.shouldShowInAppMessagesAutomatically].
   *
   * Note: In iOS, this requires version 16+. In older versions the promise will be resolved successfully
   * immediately.
   *
   * @param messageTypes An array of message types that the stores can display inside your app. Must be one of
   *       [IN_APP_MESSAGE_TYPE]. By default, is undefined and all message types will be shown.
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet.
   */
  public static async showInAppMessages(
    messageTypes?: IN_APP_MESSAGE_TYPE[]
  ): Promise<void> {
    await throwIfNotConfigured();
    return RNPurchases.showInAppMessages(messageTypes);
  }

  /**
   * Parses the given URL into a [WebPurchaseRedemption] object that can be used to redeem web purchases
   * @param urlString The Redemption Link URL as a string
   * @returns {Promise<WebPurchaseRedemption>} A WebPurchaseRedemption object that can be used to redeem the link using [redeemWebPurchase].
   */
  public static async parseAsWebPurchaseRedemption(
    urlString: string
  ): Promise<WebPurchaseRedemption | null> {
    if (await RNPurchases.isWebPurchaseRedemptionURL(urlString)) {
      return { redemptionLink: urlString };
    }
    return null;
  }

  /**
   * Redeems the web purchase associated with the Redemption Link obtained with [parseAsWebPurchaseRedemption].
   * @param webPurchaseRedemption The WebPurchaseRedemption object obtained from [parseAsWebPurchaseRedemption].
   * @returns {Promise<WebPurchaseRedemptionResult>} The result of the redemption process. Can throw if an invalid
   * WebPurchaseRedemption parameter is passed or Purchases is not configured.
   */
  public static async redeemWebPurchase(
    webPurchaseRedemption: WebPurchaseRedemption
  ): Promise<WebPurchaseRedemptionResult> {
    await throwIfNotConfigured();
    const result = await RNPurchases.redeemWebPurchase(webPurchaseRedemption.redemptionLink);
    normalizePurchasesError(result?.error);
    return result;
  }

  /**
   * Fetches the virtual currencies for the current subscriber.
   *
   * @returns {Promise<PurchasesVirtualCurrencies>} A PurchasesVirtualCurrencies object containing the subscriber's virtual currencies.
   * The promise will be rejected if configure has not been called yet or if an error occurs.
   */
  public static async getVirtualCurrencies(): Promise<PurchasesVirtualCurrencies> {
    await throwIfNotConfigured();
    return RNPurchases.getVirtualCurrencies();
  }

  /**
   * Invalidates the cache for virtual currencies.
   *
   * This is useful for cases where a virtual currency's balance might have been updated
   * outside of the app, like if you decreased a user's balance from the user spending a virtual currency,
   * or if you increased the balance from your backend using the server APIs.
   *
   * @returns {Promise<void>} The promise will be rejected if configure has not been called yet or there's an error
   * invalidating the virtual currencies cache.
   */
  public static async invalidateVirtualCurrenciesCache(): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.invalidateVirtualCurrenciesCache();
  }

  /**
   * The currently cached [PurchasesVirtualCurrencies] if one is available.
   * This value will remain null until virtual currencies have been fetched at
   * least once with [Purchases.getVirtualCurrencies] or an equivalent function.
   *
   * @returns {Promise<PurchasesVirtualCurrencies | null>} The currently cached virtual currencies for the current subscriber.
   * The promise will be rejected if configure has not been called yet or there's an error.
   */
  public static async getCachedVirtualCurrencies(): Promise<PurchasesVirtualCurrencies | null> {
    await throwIfNotConfigured();
    const result = await RNPurchases.getCachedVirtualCurrencies();
    return result ?? null;
  }

  /**
   * Check if configure has finished and Purchases has been configured.
   *
   * @returns {Promise<Boolean>} promise with boolean response
   */
  public static isConfigured(): Promise<boolean> {
    if (!RNPurchases) {
      // Native module not available, so SDK cannot be configured
      // tslint:disable-next-line:no-console
      console.warn(`[RevenueCat] isConfigured() returning false: Native module not available`);
      return Promise.resolve(false);
    }
    return RNPurchases.isConfigured();
  }

  /**
   * Provides access to ad lifecycle tracking methods.
   */
  public static get adTracker(): PurchasesAdTracker {
    if (!adTrackerSingleton) {
      adTrackerSingleton = new PurchasesAdTracker();
    }
    return adTrackerSingleton;
  }

  /**
   * Tracks an impression of a custom (non-RevenueCat) paywall.
   * Call this method when your custom paywall is displayed to a user.
   * This enables RevenueCat to track paywall impressions for analytics.
   *
   * @param params - Optional parameters for the impression event.
   * @param params.paywallId - Optional identifier for the custom paywall being shown.
   * @param params.offering - Optional offering associated with the custom paywall.
   * @param params.offeringId - Deprecated. Prefer passing `offering` when available.
   *   Optional identifier for the offering associated with the custom paywall. If not provided,
   *   the SDK will use the current offering identifier from the cache.
   */
  public static async trackCustomPaywallImpression(
    params?: TrackCustomPaywallImpressionOptions
  ): Promise<void> {
    await throwIfNotConfigured();

    const options: TrackCustomPaywallImpressionOptions = params ?? {};
    const presentedOfferingContext =
      options.offering?.availablePackages?.[0]?.presentedOfferingContext;
    const offeringId =
      options.offering?.identifier ??
      options.offeringId;
    RNPurchases.trackCustomPaywallImpression({
      paywallId: options.paywallId ?? null,
      offeringId: offeringId ?? null,
      presentedOfferingContext: presentedOfferingContext ?? null,
    });
  }

  /**
   * Generates a reward verification token for a rewarded ad impression.
   *
   * Pass the returned `clientTransactionId` to the ad network as the
   * server-side verification custom data. After the ad completes, pass the same
   * id to {@link Purchases.pollRewardVerification} to await the reward.
   *
   * @param impressionId - The impression identifier of the rewarded ad.
   * @returns {Promise<RewardVerificationToken>} promise with the generated token.
   */
  public static async generateRewardVerificationToken(
    impressionId: string
  ): Promise<RewardVerificationToken> {
    await throwIfNotConfigured();
    return RNPurchases.generateRewardVerificationToken(impressionId);
  }

  /**
   * Polls RevenueCat for the reward verification result of a rewarded ad.
   *
   * The returned promise stays pending while the native poller runs (up to
   * ~10-30s) and resolves once verification completes or times out. A timed-out
   * or rejected verification resolves with `failed: true` rather than rejecting.
   *
   * @param clientTransactionId - The `clientTransactionId` from
   *   {@link Purchases.generateRewardVerificationToken}.
   * @param trackingMetadata - Pass to have the SDK automatically track
   *   reward-verification events for the ad it belongs to; omit to poll
   *   without tracking.
   * @returns {Promise<RewardVerificationResult>} promise with the verification result.
   */
  public static async pollRewardVerification(
    clientTransactionId: string,
    trackingMetadata?: RewardedAdTrackingMetadata
  ): Promise<RewardVerificationResult> {
    await throwIfNotConfigured();
    return RNPurchases.pollRewardVerification(
      clientTransactionId,
      trackingMetadata
    );
  }

  private static async throwIfAndroidPlatform() {
    if (Platform.OS === "android") {
      throw new UnsupportedPlatformError();
    }
  }

  private static async throwIfIOSPlatform() {
    if (Platform.OS === "ios") {
      throw new UnsupportedPlatformError();
    }
  }

  private static isPurchasesAreCompletedByMyApp(
    obj: PurchasesAreCompletedBy
  ): obj is PurchasesAreCompletedByMyApp {
    return (
      typeof obj === "object" &&
      obj !== null &&
      (obj as PurchasesAreCompletedByMyApp).type ===
        PURCHASES_ARE_COMPLETED_BY_TYPE.MY_APP
    );
  }

  private static convertIntToRefundRequestStatus(
    refundRequestStatusInt: number
  ): REFUND_REQUEST_STATUS {
    switch (refundRequestStatusInt) {
      case 0:
        return REFUND_REQUEST_STATUS.SUCCESS;
      case 1:
        return REFUND_REQUEST_STATUS.USER_CANCELLED;
      default:
        return REFUND_REQUEST_STATUS.ERROR;
    }
  }

}

let adTrackerSingleton: PurchasesAdTracker | undefined;

/**
 * Provides methods for tracking ad lifecycle events.
 * Access via {@link Purchases.adTracker}.
 */
export class PurchasesAdTracker {
  public async trackAdDisplayed(data: AdDisplayedData): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.trackAdDisplayed(data);
  }

  public async trackAdOpened(data: AdOpenedData): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.trackAdOpened(data);
  }

  public async trackAdLoaded(data: AdLoadedData): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.trackAdLoaded(data);
  }

  public async trackAdRevenue(data: AdRevenueData): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.trackAdRevenue(data);
  }

  public async trackAdFailedToLoad(data: AdFailedToLoadData): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.trackAdFailedToLoad(data);
  }

  public async trackAdRewardEarnedUnverified(data: AdRewardEarnedUnverifiedData): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.trackAdRewardEarnedUnverified(data);
  }

  public async trackRewardedAdPromptShown(data: AdRewardPromptShownData): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.trackRewardedAdPromptShown(data);
  }

  public async trackRewardedAdPromptAccepted(data: AdRewardPromptAcceptedData): Promise<void> {
    await throwIfNotConfigured();
    RNPurchases.trackRewardedAdPromptAccepted(data);
  }
}
